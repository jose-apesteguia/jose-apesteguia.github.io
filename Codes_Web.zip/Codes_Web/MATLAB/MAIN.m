% Codes to estimate the Random Parameter Model following Apesteguia & Ballester:
% MONOTONE STOCHASTIC CHOICE MODELS: THE CASE OF RISK AND TIME PREFERENCES
% Journal of Political Economy, Forthcoming
%
% Written by Jose Apesteguia, Miguel A. Ballester and Angelo Gutierrez-Daza
% November 2016
%
% Tested on Matlab 2016b.
% Requires Matlab's Optimization and Statistics Toolboxes

% Initialize
clear all; close all; clc;

% Uncomment and change the following line to change current directory
% cd('C:\Users\agutieda\Desktop\MSCM_CODES_WEBSITE\CodesRPM\Matlab')

% Add follder containing the log-likelihood functions to the path
addpath([pwd,'\AuxiliaryFunctions'])

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% The Data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% For illustrative purposes, we use data from Andersen et. al.(2008) field experiment on a 
% representative sample of the adult Danish population comprised of 253 subjects. In the experiment,
% there were four different risk-aversion choice tasks in the style of the multiple-price lists of 
% Holt and Laury (2002). Each task comprised of ten pairs of nested gambles. For every pair of
% gambles, subjects could either choose one of the gambles, or express indifference between the two.
% In the latter case, they were told that the experimenter would settle indifferences by tossing a
% fair coin. We pool all observations from all individuals to get a sample of approximately
% 8000 observations.

% Load Excel file
[data,variables] = xlsread('TestData.xls');

% Get the variables from the dataset
id     = data(:,1); % Individual identifier
OLD    = data(:,2); % Dummy variable equal to one if indivudal's age is a
X1     = data(:,3); % Payoff of lottery X in outcome 1
X2     = data(:,4); % Payoff of lottery X in outcome 2
Y1     = data(:,5); % Payoff of lottery Y in outcome 1
Y2     = data(:,6); % Payoff of lottery Y in outcome 2
P      = data(:,7); % Probability of outcome 1 in both lotteries
CHOICE = data(:,8); % Chosen lottery (1 if choose Y, 0 if choose X)

% Delete unused variables
clearvars data raw;

% Define number of observations in the dataset
N = length(id);

%% Computing the risk aversion level that makes and individual indifferent between the two lotteries 
% Estimation of the RPM model requires computation of the risk aversion level that makes an individual
% indifferent between the two lotteries considered in each observation (omega, following the notation 
% in our paper). 
% 
% The following lines compute omega by solving numerically the non-linear equation implied by the 
% equalization of the expected utilities of each lottery. 

% Scale factor for the payoffs
% This doesn't affect the final estimates both makes easier to solve the equations numerically 
scale = 1/1000;

% Define an auxiliary function that computes expected utility of a lottery
EU_L = @(r,m1,m2,p) ( (scale.*m1).^(1-r)./(1-r) ).*p + ( (scale.*m2).^(1-r)./(1-r) ).*(1-p);

% Define an auxiliary function that computes the difference of the expected utility between two lotteries
EU_DIFF = @(r,x1,x2,y1,y2,p) EU_L(r,x1,x2,p) - EU_L(r,y1,y2,p) ;

% Set the options for the numerical solver
options_fzero  = optimset('TolX',1e-10,'Display','off');
options_fsolve = optimoptions('fsolve','Display','none','OptimalityTolerance',1e-10,'StepTolerance',1e-10);

% Initial value for the numerical solver
X0 = -2;

% Loop over each lottery and compute the value of risk aversion that equalizes the 
% expected value of both lotteries 
OMEGA = zeros(N,1); OMEGA_2 = zeros(N,1);
for i = 1:N        
    EU_DIFF_i = @(r_i) EU_DIFF(r_i,X1(i),X2(i),Y1(i),Y2(i),P(i)); 
    
    % Using the fsolve function (requires Matlab's Optimization Toolbox)
    OMEGA(i) = fsolve(EU_DIFF_i,X0,options_fsolve);
    
    % Using the fzerp function
    OMEGA_2(i) = fzero(EU_DIFF_i,X0,options_fzero);
    
    % Display iterations
    [i,OMEGA(i),OMEGA_2(i)]
   
end

% Notice that in some cases, the fzero function fails to find a risk aversion value that equalizes
% the expected value of the two lotteries. This is the case when one of the lotteries is stochastically
% dominated by the other. In those cases, the function fsolve (and Stata) assign an arbitrarily large
% value of omega to these lotteries. This guarantees that the probability of choosing the dominated 
% lottery goes to zero in the log-likelihood function and avoids any potential problems in the estimation

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%% Estimate the RPM using Logit %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% We now use Matlab optimization routines to estimate the model parameters by maximizing the 
% the log-likelihood function of the model, given our data

% Define the objective function to optimize 
% (notice fminunc minimizes this function and must receie a vector)
obj_fun = @(x) - loglike_RPM_logit(x,OMEGA,CHOICE);

% Set the options for the numerical optimization routine
options_fminunc = optimoptions('fminunc','Display','none','Algorithm','quasi-newton', ...
    'OptimalityTolerance',1e-10,'StepTolerance',1e-10);

% Initial values for the optimization routine
X0 = [0.7;0.9;0.1];

% Use the function "fminunc" to find the parameters that minimize the objective function
[theta_hat,~,~,~,~,hessian] = fminunc(obj_fun,X0,options_fminunc);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%% Compute the standard deviations %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% We use an asymptotic approximation to the standard deviation of the estimated parameters that takes
% into account clustering across individuals, following the notation in the accompanying pdf

cluster_var = id;
Cov_theta_hat = RobustVarCov(@loglike_RPM_logit,theta_hat,OMEGA,CHOICE,hessian,cluster_var);

% 4) Get the standard deviations from the Covariance matrix
std_theta_hat=diag(sqrt(Cov_theta_hat));


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Report %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Point Estimates
r = theta_hat(1); LNlambda = theta_hat(2); kappa = theta_hat(3); 

% Standard Deviation of Estimates
std_r = std_theta_hat(1); std_LNlambda = std_theta_hat(2); std_kappa = std_theta_hat(3);

% Use delta method to recover estimates for lambda and corresponding std. dev. 
lambda     = exp(LNlambda);
std_lambda = sqrt( (std_LNlambda^2)*(lambda^2) );

% Table
disp(' ')
disp(' ')
disp('************** Results: RPM Model (Logit) ****************')
Col_Names = {'beta', 'lambda', 'kappa'};
Row_Names = {'Point Estimate', 'Std. Dev.'};
table([r;std_r],[lambda;std_lambda],[kappa;std_kappa],'RowNames',Row_Names,'VariableNames',Col_Names)
disp(' ')
disp('**********************************************************')


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%% Estimate the RPM using Probit %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Same steps as above but using a different log-likelohood function
obj_fun = @(x) - loglike_RPM_probit(x,OMEGA,CHOICE);

% Initial values for the optimization routine
X0 = [0.7;0.9;0.1];

% Use the function "fminunc" to find the parameters that minimize the objective function
[theta_hat,fval,exitflag,output,grad,hessian] = fminunc(obj_fun,X0,options_fminunc);

% Use our function to compute robust variance-covariance matrix of estimators
Cov_theta_hat = RobustVarCov(@loglike_RPM_probit,theta_hat,OMEGA,CHOICE,hessian,cluster_var);

% Get the standard deviations from the Covariance matrix
std_theta_hat=diag(sqrt(Cov_theta_hat));

% Recover point estimates
r = theta_hat(1); LNlambda = theta_hat(2); kappa = theta_hat(3); 

% Standard deviation of estimates
std_r = std_theta_hat(1); std_LNlambda = std_theta_hat(2); std_kappa = std_theta_hat(3);

% Use delta method to recover estimates for lambda and corresponding std. dev. 
lambda     = exp(LNlambda); std_lambda = sqrt( (std_LNlambda^2)*(lambda^2) );

% Table
disp(' ')
disp(' ')
disp('************** Results: RPM Model (Probit) ****************')
Col_Names = {'beta', 'lambda', 'kappa'};
Row_Names = {'Point Estimate', 'Std. Dev.'};
table([r;std_r],[lambda;std_lambda],[kappa;std_kappa],'RowNames',Row_Names,'VariableNames',Col_Names)
disp(' ')
disp('**********************************************************')

