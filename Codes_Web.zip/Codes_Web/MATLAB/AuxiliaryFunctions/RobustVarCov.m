function CovMat_theta_hat = RobustVarCov(loglikeRPM,theta_hat,OMEGA,CHOICE,hessian,cluster_var)
% Function to compute the covariance matrix of the estimator obtained using maximum likelihood

% Number of clusters
N      = length(OMEGA);
Groups = unique(cluster_var);
M      = length(Groups);

%% 1) Compute J1

% We get M1 from the Hessian matrix obtained after estimation, multiplied by a minus
J1 = -hessian./N;

%% 2) Compute J2

% Gradient of the log-likelihood function for each individual
J2_i = nan(3,M);
for k=1:M
    
    % Find the individuals in a group
    group_idx = (cluster_var == Groups(k));
    
    % Define likelihood of indiividuals in that group;
    loglike_RPM_k = @(x) loglikeRPM(x,OMEGA(group_idx),CHOICE(group_idx));
    
    % Compute Jacobian of the log-likelihood evaluated at estimated parameter values
    J2_i(:,k) = jacob_fun(loglike_RPM_k,theta_hat,1e-5);
    
end

% Compute J2 as the sum of the Jacobians of each group
J2 = zeros(3,3);
for k=1:M
    J2 = J2 + J2_i(:,k)*J2_i(:,k)';
end
J2 = J2./N;

%% 3) Use J1 and J2 to get the covariance matrix of the estimators
Asympt_VarMat = J1\J2/J1;

% Divide by N to get finite sample approximation
CovMat_theta_hat = Asympt_VarMat./N;

end

%% Auxiliary Function 
function jac_vec = jacob_fun(func,x,step)
% Compute the Jacobian numerically using forward differences
f0 = feval(func,x); n = size(x,1); m = size(f0,1); x0  = x;
jac_vec = zeros(m,n);
for i=1:n
    step2 = step*max(1,x0(i));
    x = x0;
    x(i) = x0(i) + step2;
    jac_vec(1:m,i) = (feval(func,x) - f0)/step2;
end
end

