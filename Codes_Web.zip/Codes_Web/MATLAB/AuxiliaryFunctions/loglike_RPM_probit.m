function log_like = loglike_RPM_probit(parameters,OMEGA,CHOICE)
% Loglikelihood function of the RPM model with Probit

% Recover parameters
r         = parameters(1); % Risk Aversion Coefficient
LN_lambda = parameters(2); % Precision Parameter
kappa     = parameters(3); % Tremble Parameter

% Transform model parameters to restrict their domains
lambda = exp(LN_lambda);

% Compute probability of choosing lottery X (0) over lottery  Y (1)
ps = (1-2*kappa).*normcdf( (r-OMEGA).*lambda ) + kappa;

% Create indicators for each case
iX = CHOICE == 0 ; % Indicator vector: Equal to 1 when X is chosen
iY = CHOICE == 1 ; % Indicator vector: Equal to 1 when Y is chosen
iI = CHOICE ==-1 ; % Indicator vector: Equal to 1 when indifference is reported

% Compute the log-likelihood
log_like = sum( log(ps).*iX + log(1-ps).*iY + (1/2).*(log(ps)+ log(1-ps)).*iI );

end

