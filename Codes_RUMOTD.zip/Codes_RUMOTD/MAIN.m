% RANDOM UTILITY MODELS WITH ORDERED TYPES AND DOMAINS
% by Jose Apesteguia and Miguel A. Ballester
%
% This file replicates the table2 of the empirical illustration in section 8 of
% the paper.
%
% Written by Angelo Gutierrez-Daza
% April 2020
%
% Tested using Matlab 2020a

close all; clear; clc;
addpath('AuxiliaryFunctions')

% Optimization algorithm options
option_vec = optimset('Display','iter',...
    'MaxFunEvals',100000,...
    'MaxIter',5000,...
    'TolX',1e-8,...
    'TolFun',1e-8,...
    'TolCon',1e-8);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 0) Compute the threshold values of risk aversion under CRRA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% The lotteries
lotteryList{1} = 17;
lotteryList{2} = [50,0];
lotteryList{3} = [40,5];
lotteryList{4} = [30,10];
lotteryList{5} = [20,15];
lotteryList{6} = [50,12,0];
lotteryList{7} = [40,12,5];
lotteryList{8} = [30,12,10];
lotteryList{9} = [20,12,15];

% Compute preference order consistent with each interval of risk aversion levels
% and the endpoints of each interval
[P_order,RA_min,RA_max] = computeThresholds(lotteryList);

% Export to excel
nP = length(RA_max);
xlswrite('output/results.xlsx',RA_min,'table2','B3');
xlswrite('output/results.xlsx',RA_max,'table2','C3');
xlswrite('output/results.xlsx',P_order,'table2','D3');

save('output/results.mat','RA_max');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 1) Estimate using all observations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Load the dataset
load('input/experimentData.mat');
dataset   = experimentData.allSubjectsPooled;
crossTab  = table2array(dataset.crossTab);
rhoTab    = dataset.freqMat;
domainTab = dataset.menuMat;

% Create a table with input used for estimation. This includes the the chosen
% alternative in each menu under each alternative and preference ordering, the
% corresponding number of observations in the data, the number of alternatives
% in each menu and an indicator of the alternative being dominated in that menu
[inputMatrix,menuMatrix] = computeInput(rhoTab,domainTab,crossTab,P_order);

% Estimate
obj_fun = @(x) -logLikeFun(x,inputMatrix,menuMatrix);
f0 = ones(nP,1)./nP;
lambda0 = 0.5;
x0 = [f0;lambda0];
x_hat = fmincon(obj_fun,x0,[],[],[ones(1,nP),0],1,...
    zeros(nP+1,1),ones(nP+1,1),[],option_vec);
logLike = round(logLikeFun(x_hat,inputMatrix,menuMatrix),4);
f_hat = round(x_hat(1:nP),4);
lambda_hat = round(x_hat(end),4);

% Export
xlswrite('output/results.xlsx',f_hat,'table2','N3');
xlswrite('output/results.xlsx',lambda_hat,'table2','N35');
xlswrite('output/results.xlsx',logLike,'table2','N38');
f_AllObs = f_hat;
lambda_AllObs = lambda_hat;
logLike_AllObs = logLike;
save('output/results.mat','-append',...
    'f_AllObs','lambda_AllObs','logLike_AllObs');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 2) Estimate using treated observations only
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Load the dataset
load('input/experimentData.mat');
dataset   = experimentData.byTreatment.TL;
crossTab  = table2array(dataset.crossTab);
rhoTab    = dataset.freqMat;
domainTab = dataset.menuMat;

% Input table
[inputMatrix,menuMatrix] = computeInput(rhoTab,domainTab,crossTab,P_order);

% Estimate
obj_fun = @(x) -logLikeFun(x,inputMatrix,menuMatrix);
f0 = ones(nP,1)./nP;
lambda0 = 0.5;
x0 = [f0;lambda0];
x_hat = fmincon(obj_fun,x0,[],[],[ones(1,nP),0],1,...
    zeros(nP+1,1),ones(nP+1,1),[],option_vec);
logLike = round(logLikeFun(x_hat,inputMatrix,menuMatrix),4);
f_hat = round(x_hat(1:nP),4);
lambda_hat = round(x_hat(end),4);

% Export
xlswrite('output/results.xlsx',f_hat,'table2','O3');
xlswrite('output/results.xlsx',lambda_hat,'table2','O35');
xlswrite('output/results.xlsx',logLike,'table2','O38');
f_TL = f_hat;
lambda_TL = lambda_hat;
logLike_TL = logLike;
save('output/results.mat','-append',...
    'f_TL','lambda_TL','logLike_TL');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 3) Estimate using non-treated observations only
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Load the dataset
load('output/results.mat');
dataset   = experimentData.byTreatment.NTL;
crossTab  = table2array(dataset.crossTab);
rhoTab    = dataset.freqMat;
domainTab = dataset.menuMat;

% Input Table
[inputMatrix,menuMatrix] = computeInput(rhoTab,domainTab,crossTab,P_order);

% Estimate
obj_fun = @(x) -logLikeFun(x,inputMatrix,menuMatrix);
f0 = ones(nP,1)./nP;
lambda0 = 0.5;
x0 = [f0;lambda0];
x_hat = fmincon(obj_fun,x0,[],[],[ones(1,nP),0],1,...
    zeros(nP+1,1),ones(nP+1,1),[],option_vec);
logLike = round(logLikeFun(x_hat,inputMatrix,menuMatrix),4);
f_hat = round(x_hat(1:nP),4);
lambda_hat = round(x_hat(end),4);

% Export
xlswrite('output/results.xlsx',f_hat,'table2','P3');
xlswrite('output/results.xlsx',lambda_hat,'table2','P35');
xlswrite('output/results.xlsx',logLike,'table2','P38');
f_NTL = f_hat;
lambda_NTL = lambda_hat;
logLike_NTL = logLike;
save('output/results.mat','-append',...
    'f_NTL','lambda_NTL','logLike_NTL');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 4) Estimate using observations with binary menus only
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Load the dataset
load('input/experimentData.mat');
dataset   = experimentData.allSubjectsPooled;
crossTab  = table2array(dataset.crossTab);
rhoTab    = dataset.freqMat;
domainTab = dataset.menuMat;

% Drop all menus with more than 2 alternatives
nAltsInMenu = sum(domainTab,2);
dropIDX = nAltsInMenu > 2 ;
rhoTab(dropIDX,:)   = [];
domainTab(dropIDX,:)  = [];
crossTab(dropIDX,:)  = [];

% Input Table
[inputMatrix,menuMatrix] = computeInput(rhoTab,domainTab,crossTab,P_order);

% Estimate
obj_fun = @(x) -logLikeFun(x,inputMatrix,menuMatrix);
f0 = ones(nP,1)./nP;
lambda0 = 0.5;
x0 = [f0;lambda0];
x_hat = fmincon(obj_fun,x0,[],[],[ones(1,nP),0],1,...
    zeros(nP+1,1),ones(nP+1,1),[],option_vec);
logLike = round(logLikeFun(x_hat,inputMatrix,menuMatrix),4);
f_hat = round(x_hat(1:nP),4);
lambda_hat = round(x_hat(end),4);

% Export
xlswrite('output/results.xlsx',f_hat,'table2','Q3');
xlswrite('output/results.xlsx',lambda_hat,'table2','Q35');
xlswrite('output/results.xlsx',logLike,'table2','Q38');
f_Binary = f_hat;
lambda_Binary = lambda_hat;
logLike_Binary = logLike;
save('output/results.mat','-append',...
    'f_Binary','lambda_Binary','logLike_Binary');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% 5) Print Figure 1 and Table 2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Load table2
close all; clear; clc;
load('output/results.mat');

% Create tables
fTable = table(RA_max,f_AllObs,f_TL,f_NTL,f_Binary,...
    'VariableNames',{'omega','AllObs','TL','NTL','Binary'});
lambdaTable = table(lambda_AllObs,lambda_TL,lambda_NTL,lambda_Binary,...
    'VariableNames',{'AllObs','TL','NTL','Binary'});
logLikeTable = table(logLike_AllObs,logLike_TL,logLike_NTL,logLike_Binary,...
    'VariableNames',{'AllObs','TL','NTL','Binary'});

% Print Tables
fTable
lambdaTable
logLikeTable

% Print Figure 2
F_TL  = cumsum(f_TL);
F_NTL = cumsum(f_NTL);
figure1 = figure;
axes1 = axes('Parent',figure1);
hold(axes1,'on');
plot1 = plot([F_TL,F_NTL],'LineWidth',1);
set(plot1(2),'LineStyle','--');
box(axes1,'on');
hold(axes1,'off');
set(axes1,'XGrid','on','YGrid','on');
legend1 = legend(axes1,'show',["Treated","Non-Treated"]);
set(legend1,'Location','best');
print('output/figure1','-depsc')
print('output/figure1','-dpng')
print('output/figure1','-dpdf')
