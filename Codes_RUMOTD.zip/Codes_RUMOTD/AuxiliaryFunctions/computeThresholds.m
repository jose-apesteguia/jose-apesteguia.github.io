function [P_order,RA_min,RA_max] = computeThresholds(lotteryList)
% Compute value of thresholds of risk aversion consistent with each preference
% order under CRRA prefereces

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create a matrix with the chosen alternative in each menu under each preference
% ordering and the corresponding numnber of observations of that choice
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Range of risk-aversion coefficients considered
riskAversion = -5:0.0001:5;
riskAversion(riskAversion==1) = 1+1e-5;

% Background consumption to prevent numerical errors
c_bar = 0.0001;

% Number of lotteries and risk aversion points considered
nLottery = length(lotteryList);
nRA = length(riskAversion);

% Find thresholds by checking levels of risk aversion at which there is a
% switch in the preference order
P_old = (1:nLottery)';
P_order = [];
RA_threshold = [];
for i = 1:nRA
    % Compute expected utility of this lottery for a given value of omega
    EU = nan(nLottery,2);
    for j = 1:nLottery
        c_ij  = lotteryList{j};
        u_ij  = ( (c_ij+c_bar).^(1-riskAversion(i)) )./(1-riskAversion(i));
        EU_ij = mean(u_ij); % All payoffs have same probability
        EU(j,1) = j;
        EU(j,2) = EU_ij;
    end
    % Sort by EU to get order of lotteries by preference
    EU_new = sortrows(EU,2,'descend');
    P_new = EU_new(:,1);
    % Check if there is a change in preferences
    checkP = sum(abs(P_new - P_old));
    if checkP~=0
        P_order = [P_order,P_new];
        RA_threshold = [RA_threshold,riskAversion(i)];
        P_old = P_new;
    end
end

% Endpoints of each interval
RA_min  = RA_threshold';
RA_max  = [RA_threshold(2:end)';riskAversion(end)];
P_order = P_order';

end