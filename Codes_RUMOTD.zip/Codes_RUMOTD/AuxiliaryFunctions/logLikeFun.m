function logLike = logLikeFun(X,inputMatrix,menuMatrix)
% Log-likelihood function

% Probability mass of each interval and tremble probability
f = X(1:end-1);
lambda = X(end);

% Input
nP = length(f);
l_Limit = inputMatrix(:,1);
r_Limit = inputMatrix(:,2);
nObsInP = inputMatrix(:,3);
nAltsInMenu = inputMatrix(:,4);
isDominated = inputMatrix(:,5);

% Auxiliary menu information
menuID = menuMatrix(:,1);
altID = menuMatrix(:,2);
menuList = unique(menuID);
nMenu = length(menuList);
nObs = length(menuMatrix);

% Loop across menus and alternatives
logLike=nan(nObs,1);
k = 1;
for iMenu = 1:nMenu
    
    % Information of alternatives in this menu
    menu_idx  = menuID == menuList(iMenu);
    altList_i = altID(menu_idx);
    nAltsInMenu_i = length(altList_i);
    l_Limit_i = l_Limit(menu_idx);
    r_Limit_i = r_Limit(menu_idx);
    isDominated_i = isDominated(menu_idx);
    
    % Check if there are dominated alternatives
    anyDominated = any(isDominated_i==1);
    
    % If there are no dominated alternatives in menu, use F to compute logLike
    if anyDominated == 0
        
        % Compute log-likelohood of each alternative in this menu
        for jAlt = 1:nAltsInMenu_i
            
            % Compute idx of first and last preference in set consistent with
            % this choice in this menu
            idx1 = l_Limit_i(jAlt);
            idx2 = r_Limit_i(jAlt);
            
            % Cumulative probability of preferences
            F_i1 = sum(f(1:idx1));
            F_i2 = sum(f(1:idx2));
            
            if idx1 == nP % If preference set consists on last P only
                diff_F = f(end);
            elseif idx2 == 1 % If preference set consists on first P only
                diff_F = f(1);
            else % Otherwise
                diff_F = F_i2-F_i1+f(idx1);
            end
            
            % Compute log-likelihood of this observation
            logLike(k) = log(diff_F);
            k = k + 1;
            
        end
        
        % If there are dominated alternatives, use model with tremble
    else
        
        % Number of dominated alternatives
        nAltsDominated = sum(isDominated_i);
        
        % Compute log-likelihood of each alternative in this menu
        for jAlt = 1:nAltsInMenu_i
            
            if isDominated_i(jAlt) == 0 % If the alternative is not dominated
                
                % Compute idx of first and last preference in set consistent with
                % this choice in this menu
                idx1 = l_Limit_i(jAlt);
                idx2 = r_Limit_i(jAlt);
                
                % Cumulative probability of preferences
                F_i1 = sum(f(1:idx1));
                F_i2 = sum(f(1:idx2));
                
                if idx1 == nP % If preference set consists on last P only
                    diff_F = f(end);
                elseif idx2 == 1 % If preference set consists on first P only
                    diff_F = f(1);
                else % Otherwise
                    diff_F = F_i2-F_i1+f(idx1);
                end
                
                % Compute log-likelihood of this observation
                logLike(k) = log((1-lambda)*diff_F);
                k = k + 1;
                
            else % If the alternative is dominated
                
                % Choose with same probability any of the dominated alternatives
                logLike(k) = log(lambda/nAltsDominated);
                k = k + 1;
                
            end
            
            
        end
        
    end
    
end

% Weight logLike of each observation by number of times observed in data
logLike = mean( nObsInP.*logLike );

end
