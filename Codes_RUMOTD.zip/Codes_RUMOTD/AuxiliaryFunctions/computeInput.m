function [inputMatrix,menuMatrix] = computeInput(rhoTab,domainTab,crossTab,P_order)
% Compute number of times each interval of cutoffs is revealed as preferred

%% 1) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create a matrix with the chosen alternative in each menu under each preference
% ordering and the corresponding numnber of observations of that choice
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

nAlt  = size(rhoTab,2);
nMenu = size(rhoTab,1);
nP    = size(P_order,1);
alternativeID = (1:nAlt)';
nObs_chosen_hat = nan(nMenu,nP);
chosen_hat = nan(nMenu,nP);

for jPreference = 1:nP
    
    % Pick a preference from the list
    P_hat = P_order(jPreference,:);
    
    % Compute an auxiliary vector of utilities consistent with the rankings
    % implied by the preference
    auxVec  = (nAlt:-1:1)'+10;
    utility = nan(nAlt,1);
    for iAlt = 1:nAlt
        if sum(P_hat==iAlt)==1
            utility(iAlt) = auxVec( P_hat==iAlt );
        else
            utility(iAlt) = 0;
        end
    end
    
    % Compute vector with the maximal alternative under P_hat for each menu in
    % the domain D
    mP_hat = nan(nMenu,1);
    for iMenu = 1:nMenu
        S = domainTab(iMenu,:)==1;
        aInS = alternativeID(S);
        [~,idx_mP] = max( utility(aInS) );
        mP_hat(iMenu) = aInS(idx_mP);
    end
    
    % Store the number of observations consistent with each set of preferences
    chosenIDX = sub2ind([nMenu,nAlt],(1:nMenu)',mP_hat);
    nObs_chosen_hat(:,jPreference) = crossTab(chosenIDX);
    chosen_hat(:,jPreference) = mP_hat;
    
end

%% 2) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute the intervals of risk aversion associated to each choice in each menu
% and the number of corresponding observations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

idx_M = nan(nMenu,2);
val_M = nan(nMenu,1);
menuVec = nan(nMenu,1);
altVec = nan(nMenu,5);
nAltsInMenu = nan(nMenu,1);
altConsidered = nan(nMenu,1);
dom_M = nan(nMenu,1);

k=1;
for iMenu = 1:nMenu
    
    % Number of observations for that menu
    n_chosen_i = nObs_chosen_hat(iMenu,:);
    chosen_i   = chosen_hat(iMenu,:);
    
    % Alternatives in that menu
    S = domainTab(iMenu,:)==1;
    aInS = alternativeID(S);
    nS = length(aInS);
    
    % Compute number of observations consistent with each preference set
    for jAlt = 1:nS
        
        % Particular alternative in this menu
        a_j = aInS(jAlt);
        aux_idx_vec = find(chosen_i == a_j);
        
        % If it is dominated, it is never chosen and aux_idx_vec is empty
        if isempty(aux_idx_vec)
            % Index of lower bound of interval
            idx_M(k,1) = nan;
            % Index of upper bound of interval
            idx_M(k,2) = nan;
            % Number of times this choice is observed
            val_M(k,1) = crossTab(iMenu,a_j);
            % Indicator that this alternative is dominated in this menu
            dom_M(k,1) = 1;
        else
            % Index of lower bound of interval
            idx_M(k,1) = aux_idx_vec(1);
            % Index of upper bound of interval
            idx_M(k,2) = aux_idx_vec(end);
            % Number of obs revealed to be in this preference set
            val_M(k,1) = n_chosen_i(aux_idx_vec(1));
            % Indicator that this alternative is dominated in this menu
            dom_M(k,1) = 0;
        end
        
        % Store menu information
        menuVec(k,1) = iMenu;
        altVec(k,1:nS) = aInS;
        nAltsInMenu(k,1) = length(aInS);
        altConsidered(k,1) = a_j;
        
        % Update
        k = k+1;
        
    end
    
end

% Matrix summarizing information needed in estimation
inputMatrix = [idx_M,val_M,nAltsInMenu,dom_M];
menuMatrix = [menuVec,altConsidered,altVec];

end