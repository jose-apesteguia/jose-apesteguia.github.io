### RANDOM UTILITY MODELS WITH ORDERED TYPES AND DOMAINS
#### By Jose Apesteguia and Miguel A. Ballester

This folder contains the code to replicate the results reported in section 7
of the paper. The folder is structured as follows:

- The script “MAIN.m” carries the estimation for each subset of data in the
  empirical exercise and produces Table 2 and Figure 1 in the paper. The output
  of this exercise is automatically stored in the "output" folder.  
- The folder “input” has the MAT file with the experimental dataset used in the
  empirical exercise.
- The folder “AuxiliaryFunctions” includes some routines used in the estimation.

This code was tested using Matlab R2020a.