%% Spearman Rank Correlation Coefficient

clear all;

A = csvread('Indices.csv');
A = [A(:,5),A(:,1:4)];

%Compute a rank-correlation index

[I] = find(A(:,1));
X = A(I,:);


%Order: WARP, HM, SWAPs, GARP, Afriat
[RHO_v] = corr(X,'type','Spearman'); 

xlswrite('IndexCorrelation',RHO_v);




