% Menus
% 1. column Juice Box, 2. column Chips

Menu1 = [6,0;3,1;0,2];

Menu2 = [9,0;6,1;3,2;0,3];

Menu3 = [6,0;4,1;2,2;0,3];

Menu4 = [8,0;6,1;4,2;2,3;0,4];

Menu5 = [4,0;3,1;2,2;1,3;0,4];

Menu6 = [5,0;4,1;3,2;2,3;1,4;0,5];

Menu7 = [6,0;5,1;4,2;3,3;2,4;1,5;0,6];

Menu8 = [3,0;2,2;1,4;0,6];

Menu9 = [2,0;1,3;0,6];

Menu10 = [4,0;3,2;2,4;1,6;0,8];

Menu11 = [3,0;2,3;1,6;0,9];

All_Menus{1} = Menu1;All_Menus{2} = Menu2;All_Menus{3} = Menu3;
All_Menus{4} = Menu4;All_Menus{5} = Menu5;All_Menus{6} = Menu6;
All_Menus{7} = Menu7;All_Menus{8} = Menu8;All_Menus{9} = Menu9;
All_Menus{10} = Menu10;All_Menus{11} = Menu11;