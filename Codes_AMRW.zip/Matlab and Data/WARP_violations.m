%% File Counts Number of WARP violations


clc
clear



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%% File Starts
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

data = importdata('Data_sorted.csv',',');
Menus;


[nr,nc] = size(data); nr_ch_per_ind= 11;


act_choices = cell(nr,nc/2);
for i=1:nr
    for j=1:nc/2
        act_choices{i,j} = data(i,j*2-1:j*2);    
    end
end



Total_vio = nan(nr,1);
case_1_vio = cell(128,1);
case_2_vio = cell(128,1);


for i = 1:nr 

    
A = unique(vertcat(act_choices{i,:}),'rows');
B = vertcat(All_Menus{:}); B = unique(B,'rows');

C = setdiff(B,A,'rows');





WARP_vio = 0;

  
   f = 1;
   v = 1;
   
   
 case_1_vio{i} = nan(1,2);    
 case_2_vio{i} = nan(1,2);   
   
       
        for k2 = 1:nr_ch_per_ind
           
            
            
            
            option = All_Menus{k2}; 
            choice = act_choices{i,k2}; 
            [test1,test2] = size(option); alter = nan(test1,test2);
            
            
           
            for l = 1:test1
                if option(l,:)-choice ~= 0; %
                    
                    alter(l,:) = option(l,:);
                    
                end
            end
            
           
            
            
            for k3=1:size(alter,1)
                
                
                if ismember(alter(k3,:),vertcat(act_choices{i,:}),'rows') == 1
                    
                    
                    
                   TF = ismember(vertcat(act_choices{i,:}),alter(k3,:),'rows');
                 
                    
                    act_Loc = find(TF == 1);
                    
                    for k5=1:length(act_Loc)
                        
                        D = setdiff(All_Menus{act_Loc(k5)},act_choices{i,act_Loc(k5)},'rows');
                       
                        
                        if  max(sum([choice(1,1) <= D(:,1),choice(1,2) <= D(:,2)],2)) > 1
                            
                            WARP_vio = WARP_vio+1;
                            
                            case_1_vio{i}(v,:) = [k2,act_Loc(k5)];
                            v = v+1;
                            
                        end
                        
                    end
                    
                    
                 end
                
               
               
            end
            
            
            
            
            
            
            
            
%%%%%%%%%%%%%% SECOND LOOP OVER ALTERNATIVES %%%%%%%%%%%%%%%%%%%%%%%%%            

            
   
            
for l=1:size(alter,1)
    
    
    
    if max(sum([alter(l,1) >= B(:,1),(alter(l,2) >= B(:,2))],2)) > 1
        
     
        
        Loc = sum([sum([alter(l,1) >= B(:,1),(alter(l,2) > B(:,2))],2) == 2,sum([alter(l,1) > B(:,1),(alter(l,2) >= B(:,2))],2) == 2],2) >=1;
   
        
        
        
        
        act_Loc = find(Loc == 1);
        
        for  k5 = 1:length(act_Loc)
            
            if sum(ismember(B(act_Loc(k5),:),vertcat(act_choices{i,:}),'rows')) >= 1
                
                TF2 = ismember(vertcat(act_choices{i,:}),B(act_Loc(k5),:),'rows');
                
                
                act_Loc2 = find(TF2 == 1);
                
                
                for k6= 1:length(act_Loc2)
                    
                    G = setdiff(All_Menus{act_Loc2(k6)},act_choices{i,act_Loc2(k6)},'rows');
                    G = setdiff(G,choice,'rows');
                    
                    if  any(sum([G(:,1)>= choice(1,1),G(:,2) >= choice(1,2)],2) == 2) > 0 && ismember([k2,act_Loc2(k6)],case_2_vio{i},'rows') == 0 && ismember([act_Loc2(k6),k2],case_2_vio{i},'rows') == 0
                        
                        case_2_vio{i}(f,:) = [k2,act_Loc2(k6)];
                        
                        WARP_vio = WARP_vio+1;
                        f = f+1;
                        
                    end
                    
                end
                
                
                
            end
            
        end
        

            
    end
    
    
end 
             
            
            
        
        
        
        
        
        
        
        
        
        end 
        
        
        
        
        
        
        
        
       
    

    
    clear Loc
    Total_vio(i,1) = WARP_vio;
    

end

save Total_vio Total_vio
Violations = Total_vio;
disptable([(1:128)',Total_vio] , 'Individual|Violations')








