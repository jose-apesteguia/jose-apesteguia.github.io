%% File Checks for Violations of Linear Order Preference and Computes SWAPs and HMs indices
%% Monotonicity Imposed


clc
clear



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%% File starts
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

data = importdata('Data_sorted.csv',',');
Menus;


[nr,nc] = size(data); nr_ch_per_ind= 11;


act_choices = cell(nr,nc/2);
for i=1:nr
    for j=1:nc/2
        act_choices{i,j} = data(i,j*2-1:j*2);    
    end
end

SWAPs_rankings_all = []; HMs_rankings_all = [];
SWAPs_index_all = nan(nr,2); HMs_index_all = nan(nr,2);
final_Completion_SWAPs = cell(nr);final_Completion_HMs = cell(nr);


for i = 1:nr
i
    
A = unique(vertcat(act_choices{i,:}),'rows');
B = vertcat(All_Menus{:}); B = unique(B,'rows');

C = setdiff(B,A,'rows'); 



x1= length(A);
x2= length(C);

H = nextperm(x1,x1);


perms = factorial(x1);    


current_min_swaps_new = [];
current_min_SWAPs = 100;
current_min_HMs = 11;
min_Completion = nan(2*28,perms);
SWAPs_ind = nan(perms,1);
HMs_ind = nan(perms,1);
  
   
    
    
    
    for k = 1:perms 
        
            linear = [];
         linear_order = H(); 
    
    
    for i2=1:x1
        linear(i2,:) = A(linear_order(i2),:);
    end
    
    
    summ3 = 0; summ4 = [];
    for i4=1:length(linear)-1
        
        if max(sum([linear(i4,1) <= linear(i4+1:end,1),linear(i4,2) <= linear(i4+1:end,2)],2)) > 1
            summ4 = 1;
            
        else 
            summ4 = 0;
            
        end
            
        summ3 = summ3+summ4;
        
    end
        
        
        
        if summ3 > 0
            continue
            
        end
        
        
        
        SWAPs = 0; HMs = 0;
        num_swap = 0; num_HM = 0;
       
        
        
        Completion = nan(28,2); Completion(1:length(linear),:) = linear(:,:);
        
        for i5=1:length(C)
        
            if max(sum([C(i5,1) >= Completion(:,1),C(i5,2) >= Completion(:,2)],2))>1
                [Y,I] = max(sum([C(i5,1) >= Completion(:,1),C(i5,2) >= Completion(:,2)],2));
                Completion(I+1:end,:) = Completion(I:end-1,:);
                Completion(I,:) = C(i5,:);
                
            else
                Completion(i5+length(linear),:) = C(i5,:);
               
            end
 
        end
        
       
        
        tic
        for k2 = 1:nr_ch_per_ind 
            
            
            
            
            
            option = All_Menus{k2}; 
            choice = act_choices{i,k2};
            [test1,test2] = size(option); alter = nan(test1,test2);
            
            for l = 1:test1
                if option(l,:)-choice ~= 0; %
                    
                    alter(l,:) = option(l,:);
                    
                end
            end
           
          
            
            
            for j = 1:28
                
                if Completion(j,:) == choice;
                    
                    order_choice = j;
                    
                end
            end
            
            
            
            order_alter = ones(28,2).*100;
            for k3 = 1:size(alter,1)
                for j = 1:28
                    
                    if  (Completion(j,:) == alter(k3,:))
                        
                        order_alter(k3) = j;
                        
                    end
                end
                
            end
            
            num_swap_old = num_swap;
            num_swap = 0;
            for j = 1:28
                
                if (order_choice > order_alter(j))
                    
                    num_swap = num_swap + 1;
                    
                    
                end
            end
            
            
            num_HM = 0;
            if num_swap > 0 ;
                num_HM = num_HM + 1;
            end
            
            
            
            SWAPs = [SWAPs; num_swap];
            HMs = [HMs; num_HM];
            
            
            if sum(sum(SWAPs)) > current_min_SWAPs && sum(HMs)> current_min_HMs;
                
                break
                            
            end
            
            
        end 
        loopoverchoices= toc;
                
        
        SWAPs_ind(k) = sum(SWAPs);
        HMs_ind(k) = sum(HMs);
        min_Completion(:,k) = reshape(Completion,length(Completion)*2,1);
        
        
        
        current_min_SWAPs_new = min([current_min_SWAPs,sum(SWAPs)]);current_min_HMs_new = min([current_min_HMs,sum(HMs)]);
        
        if  current_min_SWAPs_new < current_min_SWAPs
            current_min_SWAPs = current_min_SWAPs_new;            
        end
        
        
        if  current_min_HMs_new < current_min_HMs
            current_min_HMs = current_min_HMs_new;
        end
        
        
        
        
    end
    

    
    v1 = current_min_SWAPs;
    v2 = current_min_HMs;
    
    SWAPs_collect = min_Completion(:,v1 == SWAPs_ind);
    HMs_collect = min_Completion(:,v2 == HMs_ind);
    
    SWAPs_index = current_min_SWAPs;
    HMs_index = current_min_HMs;

    SWAPs_index_all(i,:) = [i,SWAPs_index];
    HMs_index_all(i,:) = [i,HMs_index];
    final_Completion_SWAPs{i} = reshape(SWAPs_collect,28,size(SWAPs_collect,2)*2);
    final_Completion_HMs{i} = reshape(HMs_collect,28,size(HMs_collect,2)*2);
    
    rankings_SWAPs = []; rankings_HMs = [];

    SWAPs_rankings_all = [SWAPs_rankings_all]; 

    HMs_rankings_all = [HMs_rankings_all];
end

disptable([SWAPs_index_all] , 'Individual|SWAP Violations')
disptable([HMs_index_all] , 'Individual|HM Violations')

save SWAPs_index_all_Mono SWAPs_index_all
save HMs_index_all_Mono HMs_index_all
save final_Completion_SWAPs final_Completion_SWAPs
save final_Completion_HMs final_Completion_HMs

