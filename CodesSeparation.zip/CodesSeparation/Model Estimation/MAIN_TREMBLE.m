% SEPARATING PREDICTED RANDOMNESS FROM NOISE
% by Jose Apesteguia and Miguel A. Ballester
%
% This file computes:
%
% 1) The Delta-Maximal Separation and maximal fraction of the experimental dataset
% explained by a tremble model (TREMBLE)
%
% 2) The corresponding model estimated using Least Squares and Maximum Likelihood
%
% Written by Angelo Gutierrez
% October 2017
%
% Tested using Matlab 2017b
% Requires Matlab's Optimization, Statistics and Machine Learning Toolbox

close all; clear all; clc;

addpath([pwd,'/AuxiliaryFiles']);

% Load dataset
load experimentDataBinaryMenus.mat


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%% Model 2: Deterministic Rationality + Tremble (TREMBLE) %%%%%%%

tic;

%%%% Maximum Delta-Separation

% Compute the maximal Delta-separation and the maximal fraction of data explained by TREMBLE
[lambdaTREMBLE,deltaTREMBLE,epsilonTREMBLE,P_TREMBLE,gammaTREMBLE] = MDS_TREMBLE(rhoTab,domainTab);

%%%% Least Squares %%%%

% Estimate the model using LS loss function
[deltaTREMBLE_LS,P_TREMBLE_LS,gammaTREMBLE_LS] = LS_TREMBLE(rhoTab,domainTab);

%%%% Maximum Likelihood %%%%

% Estimate the model using ML loss function
[deltaTREMBLE_ML,P_TREMBLE_ML,gammaTREMBLE_ML] = ML_TREMBLE(rhoTab,domainTab);


%%%% Check the output %%%%

%%% MDS Output
lambdaTREMBLE
% deltaTREMBLE
% epsilonTREMBLE
% P_TREMBLE
% gammaTREMBLE

%%% Compare estimated delta
% deltaTREMBLE
% deltaTREMBLE_LS
% deltaTREMBLE_ML

%%% Compare the estimated preferences
disp(' ');
disp('P:  MDS    LS    ML');
[P_TREMBLE', P_TREMBLE_LS', P_TREMBLE_ML']

%%% Compare the estimated gamma
disp(' ');
disp('gamma:  MDS    LS    ML');
round([gammaTREMBLE', gammaTREMBLE_LS', gammaTREMBLE_ML'],2)

% Time
toc

% Store
save ExperimentResults_TREMBLE.mat;


%% Write results in columns for tables in the paper

load ExperimentResults_TREMBLE.mat;

nMenus = size(rhoTab,1);
auxVec = [1:9];

for iMenu = 1:nMenus  
    
    iMenu
    
    % Lotteries in the menu
    menu_i = domainTab(iMenu,:);
    altsInMenu(iMenu,:) = auxVec(menu_i==1);    
        
    %%% Observed probabilities for this menu
    rho_OBS(iMenu,:) = rhoTab(iMenu,altsInMenu(iMenu,:));
  
    %%% Predicted probabilities (delta) for each menu under each method
    delta_MDS(iMenu,:) = deltaTREMBLE(iMenu,altsInMenu(iMenu,:));
    delta_LS(iMenu,:)  = deltaTREMBLE_LS(iMenu,altsInMenu(iMenu,:));
    delta_ML(iMenu,:)  = deltaTREMBLE_ML(iMenu,altsInMenu(iMenu,:));
    
    %%% Predicted error (epsilon) for each menu under MDS
    eps_MDS(iMenu,:) = epsilonTREMBLE(iMenu,altsInMenu(iMenu,:));   
         
end

% Alternatives in each menu
altsInMenu

% Observed probabilities
rho_OBS

% Table 1: Predicted delta and eps under MDS
table1 = [delta_MDS(:,1),eps_MDS(:,1)]

% Table 2: Predicted delta in each method
table2 = [delta_MDS(:,1),delta_LS(:,1),delta_ML(:,1)]

