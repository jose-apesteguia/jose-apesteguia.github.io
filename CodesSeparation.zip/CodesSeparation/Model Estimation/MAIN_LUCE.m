% SEPARATING PREDICTED RANDOMNESS FROM NOISE
% by Jose Apesteguia and Miguel A. Ballester
%
% This file computes:
%
% 1) The Delta-Maximal Separation and maximal fraction of the experimental dataset
% explained by a Luce model (LUCE)
%
% 2) The corresponding model estimated using Least Squares and Maximum Likelihood
%
% Written by Angelo Gutierrez
% October 2017
%
% Tested using Matlab 2017b
% Requires Matlab's Optimization, Statistics and Machine Learning Toolbox

close all; clear all; clc;

addpath([pwd,'/AuxiliaryFiles']);

% Load dataset
load experimentDataBinaryMenus.mat


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%% Model 3: Luce Stochastic Choice Model (LUCE) %%%%%%%

tic;

%%%% Maximum Delta-Separation

%%% Compute the maximal Delta-separation and the maximal fraction of data explained by LUCE
u0 = [1 5 9 8 4 7 3 6 2]; % Initial value for algorithm
fix_rng = 1  ; % Set to 1 to fix seed of rng in the algorithm
[lambdaLUCE, deltaLUCE, epsilonLUCE, u_LUCE] = MDS_LUCE(rhoTab,domainTab,u0,fix_rng);

%%%% Least Squares %%%%

% Estimate the model using LS loss function
[deltaLUCE_LS,u_LUCE_LS] = LS_LUCE(rhoTab,domainTab);

%%%% Maximum Likelihood %%%%

% Estimate the model using ML loss function
[deltaLUCE_ML,u_LUCE_ML] = ML_LUCE(rhoTab,domainTab);

%%%% Check the output %%%%

%%% MDS Output
lambdaLUCE
% deltaLUCE
% epsilonLUCE
% u_LUCE

%%% Compare estimated delta
% deltaLUCE
% deltaLUCE_LS
% deltaLUCE_ML

%%% Compare the estimated preferences
disp(' ');
disp('u:        MDS          LS           ML');
round([u_LUCE', u_LUCE_LS', u_LUCE_ML'],2)

% Time
toc

% Store
save ExperimentResults_LUCE.mat;

%% Write results in columns for tables in the paper

nMenus = size(rhoTab,1);
auxVec = [1:9];

for iMenu = 1:nMenus  
    
    % Lotteries in the menu
    menu_i = domainTab(iMenu,:);
    altsInMenu(iMenu,:) = auxVec(menu_i==1);    
        
    %%% Observed probabilities for this menu
    rho_OBS(iMenu,:) = rhoTab(iMenu,altsInMenu(iMenu,:));
  
    %%% Predicted probabilities (delta) for each menu under each method
    delta_MDS(iMenu,:) = deltaLUCE(iMenu,altsInMenu(iMenu,:));
    delta_LS(iMenu,:)  = deltaLUCE_LS(iMenu,altsInMenu(iMenu,:));
    delta_ML(iMenu,:)  = deltaLUCE_ML(iMenu,altsInMenu(iMenu,:));
    
    %%% Predicted error (epsilon) for each menu under MDS
    eps_MDS(iMenu,:) = epsilonLUCE(iMenu,altsInMenu(iMenu,:));   
         
end

% Alternatives in each menu
altsInMenu

% Observed probabilities
rho_OBS

% Table 1: Predicted delta and eps under MDS
table1 = [delta_MDS(:,1),eps_MDS(:,1)]

% Table 2: Predicted delta in each method
table2 = [delta_MDS(:,1),delta_LS(:,1),delta_ML(:,1)]



