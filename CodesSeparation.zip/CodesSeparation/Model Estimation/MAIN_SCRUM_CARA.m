% SEPARATING PREDICTED RANDOMNESS FROM NOISE
% by Jose Apesteguia and Miguel A. Ballester
%
% This file computes:
%
% 1) The Delta-Maximal Separation and maximal fraction of the experimental dataset
% explained by a Stochastic Choice Random Utility Model (SCRUM) with CARA preferences
%
% 2) The corresponding model estimated using Least Squares and Maximum Likelihood
%
% Written by Angelo Gutierrez
% October 2017
%
% Tested using Matlab 2017b
% Requires Matlab's Optimization, Statistics and Machine Learning Toolbox

close all; clear all; clc;

addpath([pwd,'/AuxiliaryFiles']);

% Load dataset
load experimentDataBinaryMenus.mat


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%% Model 4b: Stochastic Choice Random Utility Model (SCRUM), CARA Preferences %%%%

tic;

% Preference path analyzed
P_CARA =[
    2   6   3   7   4   8   5   9   1
    2   6   3   7   4   8   5   1   9
    2   3   6   7   4   8   5   1   9
    2   3   6   4   7   8   5   1   9
    2   3   6   4   7   5   8   1   9
    2   3   4   6   7   5   8   1   9
    2   3   4   6   7   5   1   8   9
    2   3   4   6   5   7   1   8   9
    2   3   4   5   6   7   1   8   9
    3   2   4   5   7   6   1   8   9
    3   2   4   5   7   1   6   8   9
    3   2   4   5   1   7   6   8   9
    3   4   2   5   1   7   8   6   9
    4   3   2   5   1   8   7   6   9
    4   3   5   2   1   8   7   9   6
    4   3   5   1   2   8   7   9   6
    4   3   5   1   8   2   7   9   6
    4   3   5   1   8   7   2   9   6
    4   3   5   1   8   7   9   2   6
    4   5   3   1   8   9   7   2   6
    4   5   1   3   8   9   7   2   6
    4   5   1   8   3   9   7   2   6
    4   5   1   8   3   9   7   6   2
    4   5   1   8   9   3   7   6   2
    5   4   1   9   8   3   7   6   2
    5   1   4   9   8   3   7   6   2
    5   1   4   9   8   7   3   6   2
    5   1   9   4   8   7   3   6   2
    1   5   9   4   8   7   3   6   2
    1   5   9   8   4   7   3   6   2
    ];

%%%% Maximum Delta-Separation

% Compute the maximal Delta-separation and the maximal fraction of data explained by DET
[lambdaSCRUM_CARA, deltaSCRUM_CARA, epsilonSCRUM_CARA,muSCRUM_CARA] = MDS_SCRUM(rhoTab,domainTab,P_CARA);

%%%% Least Squares %%%%

% Estimate the model using LS loss function
[deltaSCRUM_CARA_LS,muSCRUM_CARA_LS] = LS_SCRUM(rhoTab,domainTab,P_CARA);

%%%% Maximum Likelihood %%%%

% Estimate the model using ML loss function
[deltaSCRUM_CARA_ML,muSCRUM_CARA_ML] = ML_SCRUM(rhoTab,domainTab,P_CARA);


%%%% Check the output %%%%

%%% MDS Output
lambdaSCRUM_CARA
% deltaSCRUM_CARA
% epsilonSCRUM_CARA
% muSCRUM_CARA

%%% Compare estimated delta
% deltaSCRUM_CARA
% deltaSCRUM_CARA_LS
% deltaSCRUM_CARA_ML

%%%% Compare the estimated preferences
disp(' ');
disp('mu:      MDS           LS           ML');
round([muSCRUM_CARA, muSCRUM_CARA_LS', muSCRUM_CARA_ML'],2)

% Time
toc

% Store
save ExperimentResults_SCRUM_CARA.mat;



%% Write results in columns for tables in the paper

nMenus = size(rhoTab,1);
auxVec = [1:9];

for iMenu = 1:nMenus  
    
    % Lotteries in the menu
    menu_i = domainTab(iMenu,:);
    altsInMenu(iMenu,:) = auxVec(menu_i==1);    
        
    %%% Observed probabilities for this menu
    rho_OBS(iMenu,:) = rhoTab(iMenu,altsInMenu(iMenu,:));
  
    %%% Predicted probabilities (delta) for each menu under each method
    delta_MDS(iMenu,:) = deltaSCRUM_CARA(iMenu,altsInMenu(iMenu,:));
    delta_LS(iMenu,:)  = deltaSCRUM_CARA_LS(iMenu,altsInMenu(iMenu,:));
    delta_ML(iMenu,:)  = deltaSCRUM_CARA_ML(iMenu,altsInMenu(iMenu,:));
    
    %%% Predicted error (epsilon) for each menu under MDS
    eps_MDS(iMenu,:) = epsilonSCRUM_CARA(iMenu,altsInMenu(iMenu,:));   
         
end

% Alternatives in each menu
altsInMenu

% Observed probabilities
rho_OBS

% Table 1: Predicted delta and eps under MDS
table1 = [delta_MDS(:,1),eps_MDS(:,1)]

% Table 2: Predicted delta in each method
table2 = [delta_MDS(:,1),delta_LS(:,1),delta_ML(:,1)]
