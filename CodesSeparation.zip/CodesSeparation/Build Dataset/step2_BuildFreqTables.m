% SEPARATING PREDICTED RANDOMNESS FROM NOISE
% by Jose Apesteguia and Miguel A. Ballester
%
% Script to build frequency tables with the observations from the experiment
%
% Written by Angelo Gutierrez
% October 2017
%
% Tested using Matlab 2017b

clear all; close all; clc;

% Uncomment following line to avoid message about new sheets added to Excel files
warning off;

% Create a folder to store results
try
    !mkdir FrequencyTables
end

%% Load raw excel files and put in table format

% Path to excel file
filePath = [pwd,'\cleanData.xlsx'];

% Import data with observations of experiment
obsTable = readtable(filePath,'Sheet','cleanTable','Range','A1:J9361');

% Import data with information about menus
menuTable = readtable(filePath,'Sheet','menuTable','Range','A1:K513');
menuPowerMat = table2array(menuTable(:,3:end));

% Import data with information about subjects
subjectTable = readtable(filePath,'Sheet','subjectTable','Range','A1:G88');

%% Table 1: Pool all observations

dataMenu_All   = obsTable.idMenu;
dataChoice_All = obsTable.idChoice;

% Cross-tabulate
[crossMat_All,~,~,menuLabels]= crosstab(dataMenu_All,dataChoice_All);

% Compute table of frequencies
freqMat_All = crossMat_All./sum(crossMat_All,2);

% Get information about the menu in each row and alternative in each column
menusInData = menuLabels(:,1);
menusInData = cellfun(@str2num,menusInData);
alterInData = menuLabels(:,2);
alterInData = alterInData(~cellfun('isempty',alterInData));
alterInData = cellfun(@str2num,alterInData);
menuMat_All = menuPowerMat(menusInData,:);

%%% Uncomment following lines to double check
% menuTab = tabulate(dataMenu_All);
% menusInData2     = menuTab( menuTab(:,2)>0  , 1);
% frequencyInData2 = menuTab( menuTab(:,2)>0  , 2);
% all(menusInData==menusInData2)
% all(sum(crossTab_All,2)==frequencyInData2)

% Create table and export it to Excel for analysis
rowLabels =  menuTable.alternativesInMenu(menusInData,:);
colLabels = {'Alt1', 'Alt2', 'Alt3', 'Alt4', 'Alt5', 'Alt6', 'Alt7', 'Alt8', 'Alt9'};

dataTable_All  = array2table(freqMat_All,'RowNames',rowLabels,'VariableNames',colLabels);
crossTable_All = array2table(crossMat_All,'RowNames',rowLabels,'VariableNames',colLabels);

cd([pwd,'\FrequencyTables']);
writetable(dataTable_All,'freqTable_allSubjectsPooled.xlsx','Sheet',1,'WriteRowNames',true,'Range','A1');
writetable(crossTable_All,'freqTable_allSubjectsPooled.xlsx','Sheet',1,'WriteRowNames',true,'Range','M1');
cd ..

% Store in data structrue
experimentData.allSubjectsPooled.freqMat  = freqMat_All;
experimentData.allSubjectsPooled.menuMat  = menuMat_All;
experimentData.allSubjectsPooled.dataTab  = dataTable_All;
experimentData.allSubjectsPooled.crossTab = crossTable_All;


%% Table 2: Pool observations by subject

nSubjects = size(subjectTable,1);

for iSubject = 1:nSubjects
    
    dataMenu_i   = obsTable.idMenu(  obsTable.subjectID == iSubject );
    dataChoice_i = obsTable.idChoice( obsTable.subjectID == iSubject );
    
    % Cross-tabulate
    [crossMat_i,~,~,menuLabels]= crosstab(dataMenu_i,dataChoice_i);
    
    % Compute table of frequencies
    freqMat_i = crossMat_i./sum(crossMat_i,2);
    
    % Get information about the menu in each row
    menusInData = menuLabels(:,1);
    menusInData = cellfun(@str2num,menusInData);
    menuMat_i   = menuPowerMat(menusInData,:);
    
    % Get information about the alternative in each column
    alterInData = menuLabels(:,2);
    alterInData = alterInData(~cellfun('isempty',alterInData));
    alterInData = cellfun(@str2num,alterInData);
    
    % Check if an alternative was never selected, in which case, fill the corresponding column with zeros
    neverChosen = setdiff(1:9,alterInData);
    if ~isempty(neverChosen)
        tempMat1 = zeros(length(menusInData),9);
        tempMat2 = zeros(length(menusInData),9);
        tempMat1(:,alterInData) = freqMat_i;
        tempMat2(:,alterInData) = crossMat_i;
        freqMat_i  = tempMat1;
        crossMat_i = tempMat2;
    end
    
    % Create table and export it to Excel for analysis
    rowLabels =  menuTable.alternativesInMenu(menusInData,:);
    colLabels = {'Alt1', 'Alt2', 'Alt3', 'Alt4', 'Alt5', 'Alt6', 'Alt7', 'Alt8', 'Alt9'};
    
    dataTable_i  = array2table(freqMat_i,'RowNames',rowLabels,'VariableNames',colLabels);
    crossTable_i = array2table(crossMat_i,'RowNames',rowLabels,'VariableNames',colLabels);
    
    cd([pwd,'\FrequencyTables']);
    writetable(dataTable_i,'freqTable_bySubject.xlsx','Sheet', ['subject_',num2str(iSubject)] ,'WriteRowNames',true,'Range','A1');
    writetable(crossTable_i,'freqTable_bySubject.xlsx','Sheet', ['subject_',num2str(iSubject)] ,'WriteRowNames',true,'Range','M1');
    cd ..
    
    % Store in data structrue
    eval(['experimentData.bySubject.subject' , num2str(iSubject), '.freqMat  = freqMat_i;   '] );
    eval(['experimentData.bySubject.subject' , num2str(iSubject), '.menuMat  = menuMat_i;   '] );
    eval(['experimentData.bySubject.subject' , num2str(iSubject), '.dataTab  = dataTable_i; '] );
    eval(['experimentData.bySubject.subject' , num2str(iSubject), '.crossTab = crossTable_i;'] );
    
    iSubject
    
end

%% Table 3: Pool observations by gender

% Check distribution of gender in the subject pool
genderTab = tabulate(subjectTable.Gender)
experimentData.byGender.genderTab = genderTab;


genderLabels    = {'Female','Male'};
genderIndicator = [0,1];

for iGender = [1,2]
    
    dataMenu_i   = obsTable.idMenu(  obsTable.gender == genderIndicator(iGender)  );
    dataChoice_i = obsTable.idChoice( obsTable.gender == genderIndicator(iGender) );
    
    % Cross-tabulate
    [crossMat_i,~,~,menuLabels]= crosstab(dataMenu_i,dataChoice_i);
    
    % Compute table of frequencies
    freqMat_i = crossMat_i./sum(crossMat_i,2);
    
    % Get information about the menu in each row
    menusInData = menuLabels(:,1);
    menusInData = cellfun(@str2num,menusInData);
    menuMat_i   = menuPowerMat(menusInData,:);
    
    % Get information about the alternative in each column
    alterInData = menuLabels(:,2);
    alterInData = alterInData(~cellfun('isempty',alterInData));
    alterInData = cellfun(@str2num,alterInData);
    
    % Check if an alternative was never selected, in which case, fill the corresponding column with zeros
    neverChosen = setdiff(1:9,alterInData);
    if ~isempty(neverChosen)
        tempMat1 = zeros(length(menusInData),9);
        tempMat2 = zeros(length(menusInData),9);
        tempMat1(:,alterInData) = freqMat_i;
        tempMat2(:,alterInData) = crossMat_i;
        freqMat_i  = tempMat1;
        crossMat_i = tempMat2;
    end
    
    % Create table and export it to Excel for analysis
    rowLabels =  menuTable.alternativesInMenu(menusInData,:);
    colLabels = {'Alt1', 'Alt2', 'Alt3', 'Alt4', 'Alt5', 'Alt6', 'Alt7', 'Alt8', 'Alt9'};
    
    dataTable_i  = array2table(freqMat_i,'RowNames',rowLabels,'VariableNames',colLabels);
    crossTable_i = array2table(crossMat_i,'RowNames',rowLabels,'VariableNames',colLabels);
    
    cd([pwd,'\FrequencyTables']);
    writetable(dataTable_i,'freqTable_byGender.xlsx','Sheet', genderLabels{iGender} ,'WriteRowNames',true,'Range','A1');
    writetable(crossTable_i,'freqTable_byGender.xlsx','Sheet', genderLabels{iGender} ,'WriteRowNames',true,'Range','M1');
    cd ..
    
    % Store in data structrue
    eval(['experimentData.byGender.' , genderLabels{iGender} , '.freqMat  = freqMat_i;   '] );
    eval(['experimentData.byGender.' , genderLabels{iGender} , '.menuMat  = menuMat_i;   '] );
    eval(['experimentData.byGender.' , genderLabels{iGender} , '.dataTab  = dataTable_i; '] );
    eval(['experimentData.byGender.' , genderLabels{iGender} , '.crossTab = crossTable_i;'] );
    
    iGender
    
end



%% Table 4: Pool observations by treatment

% Check distribution of treatment in the subject pool
treatmentTab = tabulate(subjectTable.Treatment)
experimentData.byTreatment.treatmentTab = treatmentTab;

treatmentLabels    = {'NTL','TL'};
treatmentIndicator = [0,1];

for iTreatment = [1,2]
    
    dataMenu_i   = obsTable.idMenu(  obsTable.treatment == treatmentIndicator(iTreatment)  );
    dataChoice_i = obsTable.idChoice( obsTable.treatment == treatmentIndicator(iTreatment) );
    
    % Cross-tabulate
    [crossMat_i,~,~,menuLabels]= crosstab(dataMenu_i,dataChoice_i);
    
    % Compute table of frequencies
    freqMat_i = crossMat_i./sum(crossMat_i,2);
    
    % Get information about the menu in each row
    menusInData = menuLabels(:,1);
    menusInData = cellfun(@str2num,menusInData);
    menuMat_i   = menuPowerMat(menusInData,:);
    
    % Get information about the alternative in each column
    alterInData = menuLabels(:,2);
    alterInData = alterInData(~cellfun('isempty',alterInData));
    alterInData = cellfun(@str2num,alterInData);
    
    % Check if an alternative was never selected, in which case, fill the corresponding column with zeros
    neverChosen = setdiff(1:9,alterInData);
    if ~isempty(neverChosen)
        tempMat1 = zeros(length(menusInData),9);
        tempMat2 = zeros(length(menusInData),9);
        tempMat1(:,alterInData) = freqMat_i;
        tempMat2(:,alterInData) = crossMat_i;
        freqMat_i  = tempMat1;
        crossMat_i = tempMat2;
    end
    
    % Create table and export it to Excel for analysis
    rowLabels =  menuTable.alternativesInMenu(menusInData,:);
    colLabels = {'Alt1', 'Alt2', 'Alt3', 'Alt4', 'Alt5', 'Alt6', 'Alt7', 'Alt8', 'Alt9'};
    
    dataTable_i  = array2table(freqMat_i,'RowNames',rowLabels,'VariableNames',colLabels);
    crossTable_i = array2table(crossMat_i,'RowNames',rowLabels,'VariableNames',colLabels);
    
    cd([pwd,'\FrequencyTables']);
    writetable(dataTable_i,'freqTable_byTreatment.xlsx','Sheet', treatmentLabels{iTreatment} ,'WriteRowNames',true,'Range','A1');
    writetable(crossTable_i,'freqTable_byTreatment.xlsx','Sheet', treatmentLabels{iTreatment} ,'WriteRowNames',true,'Range','M1');
    cd ..
    
    % Store in data structrue
    eval(['experimentData.byTreatment.' , treatmentLabels{iTreatment} , '.freqMat  = freqMat_i;   '] );
    eval(['experimentData.byTreatment.' , treatmentLabels{iTreatment} , '.menuMat  = menuMat_i;   '] );
    eval(['experimentData.byTreatment.' , treatmentLabels{iTreatment} , '.dataTab  = dataTable_i; '] );
    eval(['experimentData.byTreatment.' , treatmentLabels{iTreatment} , '.crossTab = crossTable_i;'] );
    
    iTreatment
    
end



%% Table 5: Pool observations by age

% Check distribution of age in the subject pool
ageTab = tabulate(subjectTable.Age)
experimentData.byAge.ageTab = ageTab;

% I pick the age groups where there is more than one individual in the group
ageLabels    = {'age18','age19','age20','age21','age22','age23'};
ageIndicator = [18,19,20,21,22,23];

for iAge = 1:length(ageIndicator)
    
    dataMenu_i   = obsTable.idMenu(  obsTable.age == ageIndicator(iAge)  );
    dataChoice_i = obsTable.idChoice( obsTable.age == ageIndicator(iAge) );
    
    % Cross-tabulate
    [crossMat_i,~,~,menuLabels]= crosstab(dataMenu_i,dataChoice_i);
    
    % Compute table of frequencies
    freqMat_i = crossMat_i./sum(crossMat_i,2);
    
    % Get information about the menu in each row
    menusInData = menuLabels(:,1);
    menusInData = cellfun(@str2num,menusInData);
    menuMat_i   = menuPowerMat(menusInData,:);
    
    % Get information about the alternative in each column
    alterInData = menuLabels(:,2);
    alterInData = alterInData(~cellfun('isempty',alterInData));
    alterInData = cellfun(@str2num,alterInData);
    
    % Check if an alternative was never selected, in which case, fill the corresponding column with zeros
    neverChosen = setdiff(1:9,alterInData);
    if ~isempty(neverChosen)
        tempMat1 = zeros(length(menusInData),9);
        tempMat2 = zeros(length(menusInData),9);
        tempMat1(:,alterInData) = freqMat_i;
        tempMat2(:,alterInData) = crossMat_i;
        freqMat_i  = tempMat1;
        crossMat_i = tempMat2;
    end
    
    % Create table and export it to Excel for analysis
    rowLabels =  menuTable.alternativesInMenu(menusInData,:);
    colLabels = {'Alt1', 'Alt2', 'Alt3', 'Alt4', 'Alt5', 'Alt6', 'Alt7', 'Alt8', 'Alt9'};
    
    dataTable_i  = array2table(freqMat_i,'RowNames',rowLabels,'VariableNames',colLabels);
    crossTable_i = array2table(crossMat_i,'RowNames',rowLabels,'VariableNames',colLabels);
    
    cd([pwd,'\FrequencyTables']);
    writetable(dataTable_i,'freqTable_byAge.xlsx','Sheet', ageLabels{iAge} ,'WriteRowNames',true,'Range','A1');
    writetable(crossTable_i,'freqTable_byAge.xlsx','Sheet', ageLabels{iAge} ,'WriteRowNames',true,'Range','M1');
    cd ..
    
    % Store in data structrue
    eval(['experimentData.byAge.' , ageLabels{iAge} , '.freqMat  = freqMat_i;   '] );
    eval(['experimentData.byAge.' , ageLabels{iAge} , '.menuMat  = menuMat_i;   '] );
    eval(['experimentData.byAge.' , ageLabels{iAge} , '.dataTab  = dataTable_i; '] );
    eval(['experimentData.byAge.' , ageLabels{iAge} , '.crossTab = crossTable_i;'] );
    
    iAge
    
end


%% Table 6: Pool observations by number of years in upper education

% Check distribution of edu in the subject pool
eduTab = tabulate(subjectTable.Educ)
experimentData.byEdu.eduTab = eduTab;

% I pick the edu groups where there is more than one individual in the group
eduLabels    = {'edu1','edu2','edu3','edu4'};
eduIndicator = [1,2,3,4];

for iEdu = 1:length(eduIndicator)
    
    dataMenu_i   = obsTable.idMenu(  obsTable.studies_year == eduIndicator(iEdu)  );
    dataChoice_i = obsTable.idChoice( obsTable.studies_year == eduIndicator(iEdu) );
    
    % Cross-tabulate
    [crossMat_i,~,~,menuLabels]= crosstab(dataMenu_i,dataChoice_i);
    
    % Compute table of frequencies
    freqMat_i = crossMat_i./sum(crossMat_i,2);
    
    % Get information about the menu in each row
    menusInData = menuLabels(:,1);
    menusInData = cellfun(@str2num,menusInData);
    menuMat_i   = menuPowerMat(menusInData,:);
    
    % Get information about the alternative in each column
    alterInData = menuLabels(:,2);
    alterInData = alterInData(~cellfun('isempty',alterInData));
    alterInData = cellfun(@str2num,alterInData);
    
    % Check if an alternative was never selected, in which case, fill the corresponding column with zeros
    neverChosen = setdiff(1:9,alterInData);
    if ~isempty(neverChosen)
        tempMat1 = zeros(length(menusInData),9);
        tempMat2 = zeros(length(menusInData),9);
        tempMat1(:,alterInData) = freqMat_i;
        tempMat2(:,alterInData) = crossMat_i;
        freqMat_i  = tempMat1;
        crossMat_i = tempMat2;
    end
    
    % Create table and export it to Excel for analysis
    rowLabels =  menuTable.alternativesInMenu(menusInData,:);
    colLabels = {'Alt1', 'Alt2', 'Alt3', 'Alt4', 'Alt5', 'Alt6', 'Alt7', 'Alt8', 'Alt9'};
    
    dataTable_i  = array2table(freqMat_i,'RowNames',rowLabels,'VariableNames',colLabels);
    crossTable_i = array2table(crossMat_i,'RowNames',rowLabels,'VariableNames',colLabels);
    
    cd([pwd,'\FrequencyTables']);
    writetable(dataTable_i,'freqTable_byEdu.xlsx','Sheet', eduLabels{iEdu} ,'WriteRowNames',true,'Range','A1');
    writetable(crossTable_i,'freqTable_byEdu.xlsx','Sheet', eduLabels{iEdu} ,'WriteRowNames',true,'Range','M1');
    cd ..
    
    % Store in data structrue
    eval(['experimentData.byEdu.' , eduLabels{iEdu} , '.freqMat  = freqMat_i;   '] );
    eval(['experimentData.byEdu.' , eduLabels{iEdu} , '.menuMat  = menuMat_i;   '] );
    eval(['experimentData.byEdu.' , eduLabels{iEdu} , '.dataTab  = dataTable_i; '] );
    eval(['experimentData.byEdu.' , eduLabels{iEdu} , '.crossTab = crossTable_i;'] );
    
    iEdu
    
end


%% Table 7: Pool observations by IQ score

% Check distribution of iqScore in the subject pool
iqScoreTab = tabulate(subjectTable.IqScore)
experimentData.byIqScore.iqScoreTab = iqScoreTab;

% Classify subjects according to quantile in the iqScore
iqQuantiles=quantile(subjectTable.IqScore,[0.25,0.5,0.75]);
idxg1 = subjectTable.IqScore <= iqQuantiles(1);
idxg2 = subjectTable.IqScore >  iqQuantiles(1) & subjectTable.IqScore <= iqQuantiles(2);
idxg3 = subjectTable.IqScore >  iqQuantiles(2) & subjectTable.IqScore <= iqQuantiles(3);
idxg4 = subjectTable.IqScore >  iqQuantiles(3);

iqGroup = nan(size(subjectTable,1),1);
iqGroup(idxg1) = 1;
iqGroup(idxg2) = 2;
iqGroup(idxg3) = 3;
iqGroup(idxg4) = 4;

% I pick the iqScore groups where there is more than one individual in the group
iqScoreLabels    = {'q1','q2','q3','q4'};
iqScoreIndicator = [1,2,3,4];

for iIQ = 1:length(iqScoreIndicator)
    
    dataMenu_i   = obsTable.idMenu(  obsTable.studies_year == iqScoreIndicator(iIQ)  );
    dataChoice_i = obsTable.idChoice( obsTable.studies_year == iqScoreIndicator(iIQ) );
    
    % Cross-tabulate
    [crossMat_i,~,~,menuLabels]= crosstab(dataMenu_i,dataChoice_i);
    
    % Compute table of frequencies
    freqMat_i = crossMat_i./sum(crossMat_i,2);
    
    % Get information about the menu in each row
    menusInData = menuLabels(:,1);
    menusInData = cellfun(@str2num,menusInData);
    menuMat_i   = menuPowerMat(menusInData,:);
    
    % Get information about the alternative in each column
    alterInData = menuLabels(:,2);
    alterInData = alterInData(~cellfun('isempty',alterInData));
    alterInData = cellfun(@str2num,alterInData);
    
    % Check if an alternative was never selected, in which case, fill the corresponding column with zeros
    neverChosen = setdiff(1:9,alterInData);
    if ~isempty(neverChosen)
        tempMat1 = zeros(length(menusInData),9);
        tempMat2 = zeros(length(menusInData),9);
        tempMat1(:,alterInData) = freqMat_i;
        tempMat2(:,alterInData) = crossMat_i;
        freqMat_i  = tempMat1;
        crossMat_i = tempMat2;
    end
    
    % Create table and export it to Excel for analysis
    rowLabels =  menuTable.alternativesInMenu(menusInData,:);
    colLabels = {'Alt1', 'Alt2', 'Alt3', 'Alt4', 'Alt5', 'Alt6', 'Alt7', 'Alt8', 'Alt9'};
    
    dataTable_i  = array2table(freqMat_i,'RowNames',rowLabels,'VariableNames',colLabels);
    crossTable_i = array2table(crossMat_i,'RowNames',rowLabels,'VariableNames',colLabels);
    
    cd([pwd,'\FrequencyTables']);
    writetable(dataTable_i,'freqTable_byIqScore.xlsx','Sheet', iqScoreLabels{iIQ} ,'WriteRowNames',true,'Range','A1');
    writetable(crossTable_i,'freqTable_byIqScore.xlsx','Sheet', iqScoreLabels{iIQ} ,'WriteRowNames',true,'Range','M1');
    cd ..
    
    % Store in data structrue
    eval(['experimentData.byIqScore.' , iqScoreLabels{iIQ} , '.freqMat  = freqMat_i;   '] );
    eval(['experimentData.byIqScore.' , iqScoreLabels{iIQ} , '.menuMat  = menuMat_i;   '] );
    eval(['experimentData.byIqScore.' , iqScoreLabels{iIQ} , '.dataTab  = dataTable_i; '] );
    eval(['experimentData.byIqScore.' , iqScoreLabels{iIQ} , '.crossTab = crossTable_i;'] );
    
    iIQ
    
end


%% Store data in .mat file for later use 

save experimentData.mat experimentData obsTable menuTable subjectTable;
