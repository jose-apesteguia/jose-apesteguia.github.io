% SEPARATING PREDICTED RANDOMNESS FROM NOISE
% by Jose Apesteguia and Miguel A. Ballester
%
% Script to process raw data from the experiments and write a clean Excel file with the database
% used to build the frequency tables
%
% Written by Angelo Gutierrez
% October 2017
%
% Tested using Matlab 2017b

clear all; close all; clc; 

% Uncomment following line to avoid message about new sheets added to Excel files
warning off;

%% Load raw excel files and put in table format

% Path to excel file
filePath = [pwd,'\RawData\RawData.xlsx'];

% Import data and build table with observations from experiment
obs_Table = readtable(filePath,'Sheet','data','Range','A1:M9397');

% Import data and build table with information of subjects from session 1 of NTL group
ntl1_Table = readtable(filePath,'Sheet','NTL_IQ_s1','Range','A1:AI22');

% Import data and build table with information of subjects from session 2 of NTL group
ntl2_Table = readtable(filePath,'Sheet','NTL_IQ_s2','Range','A1:AI23');

% Import data and build table with information of subjects from session 1 of TL group
tl1_Table = readtable(filePath,'Sheet','TL_IQ_s1','Range','A1:AI22');

% Import data and build table with information of subjects from session 2 of TL group
tl2_Table = readtable(filePath,'Sheet','TL_IQ_s2','Range','A1:AI24');

%% Create a table consolidating subjects information

%%% Add session and treatment identifiers as well as participant ID

% Session 1, No Treatment
nParticipants =  size(ntl1_Table,1);
subjectID  = [1:nParticipants]';
session    = zeros(nParticipants,1) + 1  ;
treatment  = zeros(nParticipants,1) + 0  ;
subjectID2 = cellstr([repmat('NTL',nParticipants,1),num2str(session),num2str(ntl1_Table.Subject)]);
subjectID2 = regexprep(subjectID2, '\s+', '');
ntl1_Table = [table(subjectID,subjectID2,session,treatment),ntl1_Table];

% Session 2, No Treatment
nParticipants =  size(ntl2_Table,1);
subjectID  = [subjectID(end)+1:subjectID(end)+nParticipants]';
session    = zeros(nParticipants,1) + 2  ;
treatment  = zeros(nParticipants,1) + 0  ;
subjectID2 = cellstr([repmat('NTL',nParticipants,1),num2str(session),num2str(ntl2_Table.Subject)]);
subjectID2 = regexprep(subjectID2, '\s+', '');
ntl2_Table = [table(subjectID,subjectID2,session,treatment),ntl2_Table];

% Session 1, Treatment
nParticipants =  size(tl1_Table,1);
subjectID  = [subjectID(end)+1:subjectID(end)+nParticipants]';
session    = zeros(nParticipants,1) + 1  ;
treatment  = zeros(nParticipants,1) + 1  ;
subjectID2 = cellstr([repmat('TL',nParticipants,1),num2str(session),num2str(tl1_Table.Subject)]);
subjectID2 = regexprep(subjectID2, '\s+', '');
tl1_Table  = [table(subjectID,subjectID2,session,treatment),tl1_Table];

% Session 2, Treatment
nParticipants =  size(tl2_Table,1);
subjectID  = [subjectID(end)+1:subjectID(end)+nParticipants]';
session    = zeros(nParticipants,1) + 2  ;
treatment  = zeros(nParticipants,1) + 1  ;
subjectID2 = cellstr([repmat('TL',nParticipants,1),num2str(session),num2str(tl2_Table.Subject)]);
subjectID2 = regexprep(subjectID2, '\s+', '');
tl2_Table  = [table(subjectID,subjectID2,session,treatment),tl2_Table];

%%% Consolidate in single table
subjectTable = [ntl1_Table; ntl2_Table; tl1_Table; tl2_Table];

%%% Add IQ score based on number of correct test answers
subjectTable.iqScore = 100.*subjectTable.correctAnswers./18;

%% Organize table with observations

%%% Change NaNs in forced variables for zero's
obs_Table.forced_choice(isnan(obs_Table.forced_choice))=0;

%%% Uncomment following line to drop forced choices (only 36 observations of 9396)
obs_Table(obs_Table.forced_choice==1,:)=[];

%%% Add identifier to merge with subject database
subjectID2 = cellstr([char(obs_Table.treatment),num2str(obs_Table.Session),num2str(obs_Table.subject)]);
subjectID2 = regexprep(subjectID2, '\s+', '');
obs_Table  = [table(subjectID2),obs_Table];

%%% Create indicator variables that denote the presence of each of the 9 alternatives in a menu 
%%% as well as a choice indicator and a 

% Vector of alternatives (as labeled in dataset)
altVector = unique( obs_Table.id_choice );
nObs = size(obs_Table,1);
nAlt = size(altVector,1);

% Power set of alternatives (used to index the menus)
[pset,setStr] = powerset(1:nAlt);
xSet = zeros(length(pset),nAlt);
for i=1:length(pset)
    xSet(i,pset{i})=1;
end

% Good old loop
idxMenu  = nan(nObs,nAlt);
idChoice = nan(nObs,1);
idMenu   = nan(nObs,1);
menuMat   = table2array(obs_Table(:,8:12));
choiceMat = table2array(obs_Table(:,13));
for iObs = 1:nObs    
    
    % Menu faced in this observation
    iMenu =  menuMat(iObs,:);   
    
    for jAlt = 1:nAlt
        
        % Alternative label
        theAlternative = altVector(jAlt);
        
        % Indicator that the j alternative is present in menu i
        jAltInMenu = any(iMenu==theAlternative);         
        
        % Store       
        idxMenu(iObs,jAlt) = jAltInMenu;                   
        
    end       
    
    % ID of alternatie chosen
    jAltID  = find( choiceMat(iObs)==altVector );
    
    % Find the position of this menu in the power set
    iMenuID = find( all( idxMenu(iObs,:)==xSet,2 ) );
    
    % Store 
    idChoice(iObs) = jAltID;
    idMenu(iObs)   = iMenuID;    
    
end

% Append index for menus
varNames = {'idxMenu0' 'idxMenu1' 'idxMenu2' 'idxMenu3' 'idxMenu4' 'idxMenu5' 'idxMenu6' 'idxMenu7' 'idxMenu8' };
idxTable = array2table(idxMenu,'VariableNames',varNames);
obs_Table = [obs_Table,idxTable];
obsID     = [1:nObs]';

% Append chosen alternative and menu ID
obs_Table = [table(obsID),obs_Table,table(idMenu,idChoice)];

%% Merge and export full table to Excel
fullTable = join(obs_Table,subjectTable,'Keys','subjectID2');

writetable(fullTable,'fullData.xlsx','Sheet','FullTable')
writetable(obs_Table,'fullData.xlsx','Sheet','obsTable')
writetable(subjectTable,'fullData.xlsx','Sheet','subjectTable')


%% Create a clean and simpler table and export clean table to Excel

% List of variables to include in table
theChosen = { 
    'obsID'
    'subjectID'
    'session'
    'treatment_subjectTable'
    'gender'
    'age'
    'studies_year'
    'iqScore'
    'idMenu'
    'idChoice'  % Notice that this variable is equal to id_choice+1 for this particular dataset
    };

% Build the table
cleanTable=[];
for iVar = 1:length(theChosen)
    
    eval(['tempVar=fullTable.',theChosen{iVar},';']);
    tempTable = table(tempVar,'VariableNames',theChosen(iVar));
    cleanTable = [cleanTable,tempTable];
    
end

% Minor adjustments
% Set gender=1 if gender=="Male" and zero otherwise
isMale = strcmp(cleanTable.gender,'Male'); 
cleanTable.gender = +isMale;

% Rename treatment variable
cleanTable.Properties.VariableNames{'treatment_subjectTable'} = 'treatment';

% Include table describing the menu IDs in second sheet
alternativesInMenu = setStr';
alternativeIDX = xSet;
menuID = [1:length(pset)]';
menuTable = table(menuID,alternativesInMenu,alternativeIDX);

% Include some subject characteristics in third sheet
subjectID = subjectTable.subjectID;
Gender = subjectTable.gender;
Age = subjectTable.age;
Educ = subjectTable.studies_year;
IqScore = subjectTable.iqScore;
Session = subjectTable.session;
Treatment = subjectTable.treatment;

CleanSubjectTable = table(subjectID,Gender,Age,Educ,IqScore,Session,Treatment);

% Export to Excel
writetable(cleanTable,'cleanData.xlsx','Sheet','cleanTable')
writetable(menuTable,'cleanData.xlsx','Sheet','menuTable')
writetable(CleanSubjectTable,'cleanData.xlsx','Sheet','subjectTable')


