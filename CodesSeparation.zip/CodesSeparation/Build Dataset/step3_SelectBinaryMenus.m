% SEPARATING PREDICTED RANDOMNESS FROM NOISE
% by Jose Apesteguia and Miguel A. Ballester
%
% Script to builld the database with binary choices used in the paper 
%
% Written by Angelo Gutierrez
% October 2017
%
% Tested using Matlab 2017b

close all; clear all; clc;

addpath([pwd,'/AuxiliaryFiles']);

%% Dataset of binary menus

% Load dataset
load experimentData.mat

% Create datasets for algorithm
dataset   = experimentData.allSubjectsPooled;
rhoTab    = dataset.freqMat;
domainTab = dataset.menuMat;

% Make all alternatives in menu selected with positive probability
rhoTab(domainTab==1 & rhoTab==0) = 1e-2;
rhoTab = max(min(rhoTab,1),0);
rhoTab = rhoTab./repmat(sum(rhoTab,2),1,size(rhoTab,2));

% Drop all menus with more than 2 alternatives
nAltsInMenu = sum(domainTab,2);
dropIDX = nAltsInMenu > 2 ;
rhoTab(dropIDX,:)   = [];
domainTab(dropIDX,:)  = [];

save experimentDataBinaryMenus.mat rhoTab domainTab;
