% SEPARATING PREDICTED RANDOMNESS FROM NOISE
% by Jose Apesteguia and Miguel A. Ballester
%
% Out-of-sample forecasts of the estimated models
% This file: Derteministic Model
% Written by Angelo Gutierrez
% October 2017
%
% Tested using Matlab 2017b
% Requires Matlab's Optimization, Statistics and Machine Learning Toolbox

close all; clear; clc;

% Load dataset
load experimentDataBinaryMenus.mat

nMenu = size(domainTab,1);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% Compute predicted and observed probabilities using subsamples of N-1 menus and predict delta for the droped menu


%%%%%%%%%%%%%%%%%%%%%% Choose the previous estimates to load %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% load ForecastResults_DET.mat
% load ForecastResults_TREMBLE.mat
load ForecastResults_LUCE.mat
% load ForecastResults_SCRUM_CRRA.mat
% load ForecastResults_SCRUM_CARA.mat
% load ForecastResults_SCRUM_MeanVar.mat

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

auxVec = [1:9]; rho_i = nan(nMenu,2);

for iSample = 1:nMenu
    
    %%% Crete sub-sample
    rhoTab_i    = rhoTab    ; rhoTab_i(iSample,:)    = [];
    domainTab_i = domainTab ; domainTab_i(iSample,:) = [];    
    
    %%% Predicted pribabilities using each method
    menu_i = domainTab(iSample,:);
    altsInMenu(iSample,:) = auxVec(menu_i==1);    
    predictedP_MDS(iSample,:) = deltaF_MDS{iSample}(altsInMenu(iSample,:));
    predictedP_LS(iSample,:)  = deltaF_LS{iSample}(altsInMenu(iSample,:));
    predictedP_ML(iSample,:)  = deltaF_ML{iSample}(altsInMenu(iSample,:));
    
    %%% Observed probabilities 
    rho_i(iSample,:) = rhoTab(iSample,altsInMenu(iSample,:));
    
    % Display iteration
    iSample    
    
end


%% Compare the forecast error of the three models
menuVec = [1:nMenu]';

% Observed probabilities
disp(' ');
disp('Observed Probabilities');
disp('           L1    L2    P1    P2');
[menuVec,round([altsInMenu, rho_i])]

% Probabilities predicted by MDS
disp(' ');
disp('Probabilities Predicted by MDS');
disp('           L1    L2    P1    P2');
[menuVec,round([altsInMenu, predictedP_MDS])]

% Probabilities predicted by ML
disp(' ');
disp('Probabilities Predicted by ML');
disp('           L1    L2    P1    P2');
[menuVec,round([altsInMenu, predictedP_ML])]

% Probabilities predicted by LS
disp(' ');
disp('Probabilities Predicted by LS');
disp('           L1    L2    P1    P2');
[menuVec,round([altsInMenu, predictedP_LS])]




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Repeat using only those observations where both methods overpredict
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rhoVecALL = rhoVec;

%%% Tremble

chosenObs_TREMBLE = tremble_MS-rhoVecALL>=0 & tremble_ML-rhoVecALL>=0;

% Vectors
menuVec = predictionMat(chosenObs_TREMBLE,1);
altVec  = predictionMat(chosenObs_TREMBLE,2);
rhoVec  = predictionMat(chosenObs_TREMBLE,3);
tremble_MS = predictionMat(chosenObs_TREMBLE,4);
tremble_ML = predictionMat(chosenObs_TREMBLE,5);
altsInMenuVec_TREMBLE = altsInMenu(predictionMat(chosenObs_TREMBLE,1));

% Compute % of times MS is better up to that observation
indMS_tremble = abs(rhoVec-tremble_MS)<abs(rhoVec-tremble_ML);
indMS_tremble(tremble_MS==tremble_ML) = 0.5;
xMS_tremble   = cumsum(indMS_tremble)./cumsum(ones(length(rhoVec),1));
xrMS_tremble  = cumsum(indMS_tremble,'reverse')./cumsum(ones(length(rhoVec),1),'reverse');

table_tremble = [rhoVec, tremble_MS, tremble_ML, xMS_tremble , xrMS_tremble ];

% Print
writematrix((1:length(menuVec))','Results_Predictions_Binary.xlsx','Sheet','Subsample_TREMBLE','Range','A3');
writematrix(menuVec,'Results_Predictions_Binary.xlsx','Sheet','Subsample_TREMBLE','Range','B3');
writecell(altsInMenuVec_TREMBLE,'Results_Predictions_Binary.xlsx','Sheet','Subsample_TREMBLE','Range','C3');
writematrix(altVec ,'Results_Predictions_Binary.xlsx','Sheet','Subsample_TREMBLE','Range','D3');
writematrix(table_tremble,'Results_Predictions_Binary.xlsx','Sheet','Subsample_TREMBLE','Range','F3');


%%% Luce

chosenObs_LUCE = luce_MS-rhoVecALL>=0 & luce_ML-rhoVecALL>=0;

% Vectors
menuVec = predictionMat(chosenObs_LUCE,1);
altVec  = predictionMat(chosenObs_LUCE,2);
rhoVec  = predictionMat(chosenObs_LUCE,3);
luce_MS = predictionMat(chosenObs_LUCE,6);
luce_ML = predictionMat(chosenObs_LUCE,7);
altsInMenuVec_LUCE = altsInMenu(predictionMat(chosenObs_LUCE,1));

% Compute % of times MS is better up to that observation
indMS_luce = abs(rhoVec-luce_MS)<abs(rhoVec-luce_ML);
indMS_luce(luce_MS==luce_ML) = 0.5;
xMS_luce   = cumsum(indMS_luce)./cumsum(ones(length(rhoVec),1));
xrMS_luce  = cumsum(indMS_luce,'reverse')./cumsum(ones(length(rhoVec),1),'reverse');

table_luce = [rhoVec, luce_MS, luce_ML, xMS_luce , xrMS_luce ];

% Print
writematrix((1:length(menuVec))','Results_Predictions_Binary.xlsx','Sheet','Subsample_LUCE','Range','A3');
writematrix(menuVec,'Results_Predictions_Binary.xlsx','Sheet','Subsample_LUCE','Range','B3');
writecell(altsInMenuVec_LUCE,'Results_Predictions_Binary.xlsx','Sheet','Subsample_LUCE','Range','C3');
writematrix(altVec ,'Results_Predictions_Binary.xlsx','Sheet','Subsample_LUCE','Range','D3');
writematrix(table_luce,'Results_Predictions_Binary.xlsx','Sheet','Subsample_LUCE','Range','F3');

%%% SCRUM

chosenObs_SCRUM = scrum_MS-rhoVecALL>=0 & scrum_ML-rhoVecALL>=0;

% Vectors
menuVec = predictionMat(chosenObs_SCRUM,1);
altVec  = predictionMat(chosenObs_SCRUM,2);
rhoVec  = predictionMat(chosenObs_SCRUM,3);
scrum_MS = predictionMat(chosenObs_SCRUM,8);
scrum_ML = predictionMat(chosenObs_SCRUM,9);
altsInMenuVec_SCRUM = altsInMenu(predictionMat(chosenObs_SCRUM,1));

% Compute % of times MS is better up to that observation
indMS_scrum = abs(rhoVec-scrum_MS)<abs(rhoVec-scrum_ML);
indMS_scrum(scrum_MS==scrum_ML) = 0.5;
xMS_scrum   = cumsum(indMS_scrum)./cumsum(ones(length(rhoVec),1));
xrMS_scrum  = cumsum(indMS_scrum,'reverse')./cumsum(ones(length(rhoVec),1),'reverse');

table_scrum = [rhoVec, scrum_MS, scrum_ML, xMS_scrum , xrMS_scrum ];

% Print
writematrix((1:length(menuVec))','Results_Predictions_Binary.xlsx','Sheet','Subsample_SCRUM','Range','A3');
writematrix(menuVec,'Results_Predictions_Binary.xlsx','Sheet','Subsample_SCRUM','Range','B3');
writecell(altsInMenuVec_SCRUM,'Results_Predictions_Binary.xlsx','Sheet','Subsample_SCRUM','Range','C3');
writematrix(altVec ,'Results_Predictions_Binary.xlsx','Sheet','Subsample_SCRUM','Range','D3');
writematrix(table_scrum,'Results_Predictions_Binary.xlsx','Sheet','Subsample_SCRUM','Range','F3');




