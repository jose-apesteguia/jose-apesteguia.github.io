% SEPARATING PREDICTED RANDOMNESS FROM NOISE
% by Jose Apesteguia and Miguel A. Ballester
%
% Out-of-sample forecasts of the estimated models
% This file: LUCE Model
% Written by Angelo Gutierrez
% October 2017
%
% Tested using Matlab 2017b
% Requires Matlab's Optimization, Statistics and Machine Learning Toolbox

close all; clear all; clc;

addpath([pwd,'/AuxiliaryFiles']);

% Load dataset
load experimentDataBinaryMenus.mat

nMenu = size(domainTab,1);


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% Estimate the model using subsamples of N-1 menus and predict delta for the droped menu

tic;

u0 = [1 5 9 8 4 7 3 6 2]; % Initial value for algorithm
fix_rng = 1  ; % Set to 1 to fix seed of rng in the algorithm

for iSample = 1:nMenu
    
    %%% Crete sub-sample
    rhoTab_i    = rhoTab    ; rhoTab_i(iSample,:)    = [];
    domainTab_i = domainTab ; domainTab_i(iSample,:) = [];
    
    %%% Estimate model using sub-sample
    [lambdaLUCE(iSample), deltaLUCE{iSample}, epsilonLUCE{iSample}, u_LUCE{iSample}] = MDS_LUCE(rhoTab_i,domainTab_i,u0,fix_rng);
    [deltaLUCE_LS{iSample},u_LUCE_LS{iSample}] = LS_LUCE(rhoTab_i,domainTab_i);
    [deltaLUCE_ML{iSample},u_LUCE_ML{iSample}] = ML_LUCE(rhoTab_i,domainTab_i);
    
    %%% Predict decision of remaining menu using estimated models
    menu_i = domainTab(iSample,:);
    deltaF_MDS{iSample} = CHOICE_LUCE(u_LUCE{iSample}   , menu_i);
    deltaF_LS{iSample}  = CHOICE_LUCE(u_LUCE_LS{iSample}, menu_i);
    deltaF_ML{iSample}  = CHOICE_LUCE(u_LUCE_ML{iSample}, menu_i);
    
    %%% Compute measures of forecast loss from the prediction
    rho_i = rhoTab(iSample,:);
    [Loss_MDS(iSample,1), Loss_MDS(iSample,2), Loss_MDS(iSample,3)] = Loss_Compute(deltaF_MDS{iSample},rho_i);
    [Loss_LS(iSample,1) , Loss_LS(iSample,2) , Loss_LS(iSample,3) ] = Loss_Compute(deltaF_LS{iSample} ,rho_i);
    [Loss_ML(iSample,1) , Loss_ML(iSample,2) , Loss_ML(iSample,3) ] = Loss_Compute(deltaF_ML{iSample} ,rho_i);
    
    % Display iteration
    iSample
    
end


% Time
toc

% Store
save ForecastResults_LUCE.mat;

%% Compare the forecast error of the three models
menuVec = [1:nMenu]';

% Loss function implicit in MDS
disp(' ');
disp('Forecast Error: L1 Loss');
disp('          Menu        MDS          LS           ML');
[menuVec,round([Loss_MDS(:,1), Loss_LS(:,1), Loss_ML(:,1)],3)]
quick_plot_bar([Loss_MDS(:,1), Loss_LS(:,1), Loss_ML(:,1)],'L1');


% Loss function implicit in LS
disp(' ');
disp('Forecast Error: L2 Loss');
disp('          Menu        MDS          LS           ML');
[menuVec,round([Loss_MDS(:,2), Loss_LS(:,2), Loss_ML(:,2)],3)]
quick_plot_bar([Loss_MDS(:,2), Loss_LS(:,2), Loss_ML(:,2)],'L2');

% Loss function implicit in ML
disp(' ');
disp('Forecast Error: L3 Loss');
disp('          Menu        MDS          LS           ML');
[menuVec,round([Loss_MDS(:,3), Loss_LS(:,3), Loss_ML(:,3)],3)]
quick_plot_bar([Loss_MDS(:,3), Loss_LS(:,3), Loss_ML(:,3)],'L3');
