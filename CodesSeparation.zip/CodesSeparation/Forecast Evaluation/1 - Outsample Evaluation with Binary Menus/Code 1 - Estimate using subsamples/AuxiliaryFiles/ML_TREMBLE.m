function [delta_ML,P_hat_ML,gamma_hat_ML] = ML_TREMBLE(rhoTab1,domainTab1)
% Function to estimate the Tremble model (TREMBLE)
% from a dataset by minimizing the follosing loss function:
% LOSS = sum( rho.*(log(rho) - log(delta)) ) [Maximum Likelihood]
%
% Follows the algorithm described in:
% Apesteguia & Ballester (2017), "Separating Predicted Randomness From Noise"
%
% Written by Angelo Gutierrez
% October 2017
%
% INPUT:
%
% rhoTab: Matrix with M rows and N columns, where N is the number of alternatives under consideration
% and each row represents a menu of alternatives in S in the domain set D. Each element of the matrix
% represents the probability of choosing an alternative in the corresponding menu, similar to table 1 in the paper
%
% domainTab: Matrix with M rows and N columns, where each row corresponds to a menu S and each column
% contains a binary number that takes value 0 if the alternative is not present in the menu and 1
% otherwise
%
% OUTPUT:
%
% delta_ML: Best specification of the model under least squares loss function
%
% P_hat_ML: (1xN) vector describing the ordering of the preference relation implied by delta_ML
% As an example, with three alternatives a1, a2 and a3; P_hat = [2,3,1] implies a2 > a3 > a1
% gamma_hat_ML: Scalar with the tremble probability implied by delta_ML
% As an example, with three alternatives a1, a2 and a3; P_hat = [2,3,1] implies a2 > a3 > a1
%
% Tested using Matlab 2017b
% Requires Matlab's Optimization Toolbox

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


global nMenu nAlt rhoTab domainTab menuID alternativeID nP matP

% Small step to make this variable global without issues
rhoTab = rhoTab1;
domainTab = domainTab1;

%%%% Compute some objects that will be required in the algorithm

% Number of menus and alternatives in the dataset
[nMenu,nAlt] = size(domainTab);

% Create an indicator matrix with all possible menus formed with nAlt alternatives
X = 1:nAlt;

% Create identifier for each menu and alternative
menuID = [1:nMenu]';
alternativeID = [1:nAlt]';

% Create the collection of all possible linear orderings of X
matP = perms(X);
nP   = size(matP,1);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Estimate gamma_hat

% Initialize
LossFunction = nan(nP,1);
gammaVec     = nan(nP,1);

for jPreference = 1:nP
    
    % Pick a preference from the list
    P_j = matP(jPreference,:);
    
    % Compute an auxiliary vector of utilities consistent with the rankings implied by the preference
    auxVec  = [nAlt:-1:1]'+10;
    utility = nan(nAlt,1);
    for iAlt = 1:nAlt
        if sum(P_j==iAlt)==1
            utility(iAlt) = auxVec( P_j==iAlt );
        else
            utility(iAlt) = 0;
        end
    end
    
    % Compute vector with the maximal alternative under P_j for each menu in the domain D
    mP_j = nan(nMenu,1);
    rho_mP_j = nan(nMenu,1);
    nAltInS = nan(nMenu,1);
    not_mP_j = nan(nMenu,1);
    
    for iMenu = 1:nMenu
        S = domainTab(iMenu,:)==1;
        aInS = alternativeID(S);              % Check what alternatives are available in that menu
        nAltInS(iMenu) = length(aInS);        % Count number of alternatives in the menu
        [~,idx_mP] = max( utility(aInS) );
        mP_j(iMenu) = aInS(idx_mP);
        not_mP_j(iMenu) = setdiff(aInS,mP_j(iMenu));
        rho_mP_j(iMenu) = rhoTab(iMenu,mP_j(iMenu));
    end
    
    % Find the value of gamma that minimizes the log-likelihood
    gamma_j = 2*sum(1-rho_mP_j)/nMenu;
    
    % Compute the choice function delta_P implied by P and gamma
    delta_P = zeros(nMenu,nAlt);
    delta_P(sub2ind([nMenu,nAlt],[1:nMenu]',mP_j))     = 1-gamma_j.*(nAltInS-1)./nAltInS;
    delta_P(sub2ind([nMenu,nAlt],[1:nMenu]',not_mP_j)) = gamma_j./nAltInS;
    
    % Compute loss function
    % Auxiliary objects
    ratio_delta_rho = delta_P./rhoTab;
    ratio_delta_rho(isnan(ratio_delta_rho))=1;
    ratio_delta_rho(ratio_delta_rho==0) = 1e-8;
    log_ratio_delta_rho = log(ratio_delta_rho);
    log_ratio_rho_delta = -log_ratio_delta_rho;
    
    % Compute implied loss
    Loss_j = sum( sum( rhoTab.*log_ratio_rho_delta ) ) ;
    
    % Store loss and gamma associated to this P_j
    LossFunction(jPreference) =  Loss_j;
    gammaVec(jPreference)     =  gamma_j;
    
end

% Find the preferences that minimize loss function and compute the corresponding choice functions
minLoss = min(LossFunction);
idx_P_opt = find(minLoss==LossFunction,1,'last');
P_hat_ML =  matP(idx_P_opt,:);

% Use the estimated value of gamma and P to compute implied choice function and preference order

% Compute an auxiliary vector of utilities consistent with the rankings implied by the preference
auxVec  = [nAlt:-1:1]'+10;
utility = nan(nAlt,1);
for iAlt = 1:nAlt
    if sum(P_hat_ML==iAlt)==1
        utility(iAlt) = auxVec( P_hat_ML==iAlt );
    else
        utility(iAlt) = 0;
    end
end

% Compute vector with the maximal alternative under P_j for each menu in the domain D
mP_hat_ML = nan(nMenu,1);
rho_mP_ML = nan(nMenu,1);
nAltInS = nan(nMenu,1);
not_mP_ML = nan(nMenu,1);

for iMenu = 1:nMenu
    S = domainTab(iMenu,:)==1;
    aInS = alternativeID(S);              % Check what alternatives are available in that menu
    nAltInS(iMenu) = length(aInS);        % Count number of alternatives in the menu
    [~,idx_mP] = max( utility(aInS) );
    mP_hat_ML(iMenu) = aInS(idx_mP);
    not_mP_ML(iMenu) = setdiff(aInS,mP_hat_ML(iMenu));
    rho_mP_ML(iMenu) = rhoTab(iMenu,mP_hat_ML(iMenu));
end

% Find the value of gamma that minimizes the log-likelihood
gamma_hat_ML = 2*sum(1-rho_mP_ML)/nMenu;

% Compute the choice function delta_P implied by P and gamma
delta_ML = zeros(nMenu,nAlt);
delta_ML(sub2ind([nMenu,nAlt],[1:nMenu]',mP_hat_ML)) = 1-gamma_hat_ML.*(nAltInS-1)./nAltInS;
delta_ML(sub2ind([nMenu,nAlt],[1:nMenu]',not_mP_ML)) = gamma_hat_ML./nAltInS;

end
