function [delta_ML,mu_hat_ML] = ML_SCRUM(rhoTab1,domainTab1,pathP)
% Function to estimate the SCRUM model (SCRUM)
% from a dataset by minimizing the follosing loss function:
% LOSS = sum( rho.*(log(rho) - log(delta)) ) [Maximum Likelihood]
%
% Follows the algorithm described in:
% Apesteguia & Ballester (2017), "Separating Predicted Randomness From Noise"
%
% Written by Angelo Gutierrez
% October 2017
%
% INPUT:
%
% rhoTab: Matrix with M rows and N columns, where N is the number of alternatives under consideration
% and each row represents a menu of alternatives in S in the domain set D. Each element of the matrix
% represents the probability of choosing an alternative in the corresponding menu, similar to table 1 in the paper
%
% domainTab: Matrix with M rows and N columns, where each row corresponds to a menu S and each column
% contains a binary number that takes value 0 if the alternative is not present in the menu and 1 otherwise
%
% pathP: (MxN) matrix describing the peference path. Each row represents a ordering of the preference relation i
% in the path. As an example, with three alternatives a1, a2 and a3; pathP(i,:) = [2,3,1] implies a2 > a3 > a1 for preference i
%
% OUTPUT:
%
% delta_ML: Best specification of the model under least squares loss function
%
% mu_hat_ML: Vector with probability distribution on pathP implied by delta_ML
%
% Tested using Matlab 2017b
% Requires Matlab's Optimization Toolbox

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Compute some objects that will be required in the algorithm

global nMenu nAlt rhoTab domainTab mP

% Small step to make this variable global without issues
rhoTab = rhoTab1;
domainTab = domainTab1;

% Number of menus and alternatives
[nMenu,nAlt] = size(domainTab);

% Number of preferences in path
nP = size(pathP,1);

% Identifier for each menu and alternative
menuID = [1:nMenu]';
alternativeID = [1:nAlt]';

% Compute matrix of utilities consistent with the rankings implied by each preference
matU = nan(nP,nAlt);
auxVec = 10 + [nAlt:-1:1]';
for jPreference = 1:nP
    preferenceRank = nan(nAlt,1);
    Pj = pathP(jPreference,:)';
    for iAlt = 1:nAlt
        preferenceRank(iAlt) = find(Pj==iAlt);
    end
    matU(jPreference,:) =  auxVec(preferenceRank);
end

% Compute matrix with alternative chosen from each menu, for each preference in preference ordering
% and the data associated to the observation
mP = nan(nP,nMenu);
for iMenu = 1:nMenu
    aInA = alternativeID(domainTab(iMenu,:)==1);
    [~,argMax] = max(matU(:, aInA ),[],2);
    mP(:,iMenu) = aInA(argMax);
end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Estimate mu_hat

% Initial value for estimation
mu0 = ones(nP,1)./sum(ones(nP,1));

% Estimate mu_hat by minimizing the loss function
option_vec = optimset('Display','iter','MaxFunEvals',100000,'MaxIter',1000, 'TolX',1e-12, 'TolFun',1e-12,'TolCon',1e-12);
[mu_hat_ML,LossFunction]=fmincon(@(x) LossFun(x), mu0,[],[],ones(1,nP),1,zeros(nP,1),ones(nP,1),[],option_vec);

% Get the implied choice function
delta_ML = deltaFun(mu_hat_ML);

% Transpose and return
mu_hat_ML = mu_hat_ML';

end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% In this section, some of the auxiliary functions used above are defined

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Loss = LossFun(mu_vec)
% This function computes the loss associated to a given utility vector u_vec

global rhoTab

% Compute the implied choice function
deltaSCRUM = deltaFun(mu_vec);

% Auxiliary objects
ratio_delta_rho = deltaSCRUM./rhoTab;
ratio_delta_rho(isnan(ratio_delta_rho))=1;
ratio_delta_rho(ratio_delta_rho==0) = 1e-8;
log_ratio_delta_rho = log(ratio_delta_rho);
log_ratio_rho_delta = -log_ratio_delta_rho;

% Compute implied loss
Loss = sum( sum( rhoTab.*log_ratio_rho_delta ) ) ;

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function deltaSCRUM = deltaFun(mu_vec)
% This function computes the matrix of choice probabilities associated to mu_vec

global nMenu nAlt mP

deltaSCRUM = zeros(nMenu,nAlt);
for iMenu=1:nMenu
    for jAlt = 1:nAlt
        idx_mp_A = mP(:,iMenu) == jAlt ;  % Position of the preferences that choose jAlt in iMenu
        pSCRUM = sum( mu_vec(idx_mp_A) ); % Compute the probability implied by the SCRUM
        deltaSCRUM(iMenu,jAlt) = pSCRUM;
    end
end

end
