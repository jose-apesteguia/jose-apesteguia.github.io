function [lambdaLUCE,deltaLUCE,epsilonLUCE,u_hat] = MDS_LUCE(rhoTab1,domainTab1,u01,fix_rng)
% Function to compute maximal Delta-separations and maximal fraction of a dataset explained by
% a Luce model (LUCE)
%
% Follows the algorithm described in:
% Apesteguia & Ballester (2017), "Separating Predicted Randomness From Noise"
%
% Written by Angelo Gutierrez
% October 2017
%
% INPUT:
%
% rhoTab: Matrix with M rows and N columns, where N is the number of alternatives under consideration 
% and each row represents a menu of alternatives in S in the domain set D. Each element of the matrix 
% represents the probability of choosing an alternative in the corresponding menu, similar to table 1 in the paper
%
% domainTab: Matrix with M rows and N columns, where each row corresponds to a menu S and each column
% contains a binary number that takes value 0 if the alternative is not present in the menu and 1
% otherwise
%
% OUTPUT:
%
% lambdaLUCE: Fraction of data explained in the maximal Delta-separation
%
% deltaLUCE: SCF in the maximal Delta-separation consistent with a Luce model
%
% epsilonLUCE: SCF in the maximal Delta-separation consistent with residual noise
%
% u_hat: Utility vector of the model implied by the maximal Delta-separation
%
% Tested using Matlab 2017b
% Requires Matlab's Optimization Toolbox

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Step 0: Compute some objects that will be required in the algorithm

global nMenu nAlt rhoTab domainTab u0 menuID alternativeID

if fix_rng==1
    rng(1);
else
    rng('shuffle');
end

% Some tolerance criterion for the algorithm
displayIter = 0      ; % Set to 1 to display information of each iteration
maxIter     = 200000 ; % Maximum number of iterations
tolX        = 1e-6   ; % Tolerance criterion to determine minimums

% Small step to make this variable global without issues
rhoTab = rhoTab1;
domainTab = domainTab1;
u0 = u01;

%%%% Build matrix identifying subsets and proper subsets of each set in domainTab

% Number of menus and alternatives
[nMenu,nAlt] = size(domainTab);

% Identifier for each menu and alternative
menuID = [1:nMenu]';
alternativeID = [1:nAlt]';

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% First iteration to find the Luce utilities

% Normalize
u0 = u0./sum(u0);

% Compute the implied consistency value lambdaLUCE and associated minimizers
deltaU0 = deltaUfun(u0);
objRatio = rhoTab./deltaU0;
objRatio(isnan(objRatio))=1;
lambdaLUCE_0 = min(objRatio(:));
minimizerIdx = find(objRatio==lambdaLUCE_0);
[menuA0idx,alternativeA0idx]=ind2sub([nMenu,nAlt],minimizerIdx);

% Compute union of set alternatives that belong to the set of minimizers
unionAlternatives = [];
for k = 1:length(alternativeA0idx)
    alternativeK = alternativeA0idx(k);
    unionAlternatives = union(unionAlternatives,alternativeK);
end

% Union of set of menus that belong to the set of minimizers
unionMenus = [];
for k = 1:length(menuA0idx)
    menuKidx = domainTab(menuA0idx(k),:);
    menuK    = menuID(menuKidx==1);
    unionMenus = union(unionMenus,menuK);
end

% Check if the two sets coincide
if length(unionMenus)>length(unionAlternatives)
    setDifference = setdiff(unionMenus,unionAlternatives);
else
    setDifference = setdiff(unionAlternatives,unionMenus);
end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Main Loop with remaining iterations to find the Luce utilities

if isempty(setDifference) % If sets are equal, stop here
    
    lambdaLUCE_1  = lambdaLUCE_0;
    u1 = u0;
    deltaU1 = deltaU0;    
    convergenceFlag = 1;
    iter=0;
    
else  
    
    % Iterate over sigma
    convergenceFlag=0; iter = 0;    
    while convergenceFlag==0 && iter<=maxIter
        
        % Randomly pick one of the elements in the difference set
        randomSetDifference = setDifference(randperm(length(setDifference)));
        x = randomSetDifference(1)';
        
        % Restriction 1: Menus where x is an alternative
        idx1 = menuID( domainTab(:,x)==1 );
        
        % Restriction 2: Chosen alternative is different from x
        idx2 = alternativeID(  alternativeID ~= x );
        
        % Find the value of sigma
        sigmaOPT = fzero( @(sig) fLuce(sig,x,u0,idx1,idx2),[0,1]);
        
        % Update the utility function
        oneX = zeros(1,nAlt);
        oneX(x) = 1;
        u1 = sigmaOPT.*oneX + (1-sigmaOPT).*u0;
        
        % Compute the implied consistency value lambda_LUCE and associated minimizers
        deltaU1 = deltaUfun(u1);
        objRatio = rhoTab./deltaU1;
        objRatio(isnan(objRatio))=inf;
        lambdaLUCE_1 = min(objRatio(:));
        minimizerIdx = find( abs(objRatio(:)-lambdaLUCE_1)<tolX );
        [menuA1idx,alternativeA1idx]=ind2sub([nMenu,nAlt],minimizerIdx);
        
        % Compute union of the alternatives that belong to the set of minimizers
        unionAlternatives = [];
        for k = 1:length(alternativeA1idx)
            alternativeK = alternativeA1idx(k);
            unionAlternatives = union(unionAlternatives,alternativeK);
        end
        
        % Compute the union of the menus that belong to the set of minimizers
        unionMenus = [];
        for k = 1:length(menuA1idx)
            menuKidx = domainTab(menuA1idx(k),:);
            menuK    = menuID(menuKidx==1);
            unionMenus = union(unionMenus,menuK);
        end
        
        % Check if the difference between the union of sets is empty
        if length(unionMenus)>length(unionAlternatives)
            setDifference = setdiff(unionMenus,unionAlternatives);
        else
            setDifference = setdiff(unionAlternatives,unionMenus);
        end
        
        % Update
        convergenceFlag=isempty(setDifference);
        u0 =  u1;
        iter  = iter+1;
        
        % Display iteration
        if displayIter==1
            if mod(iter,1)==0
                fprintf('iter = %d;  lambda = %g; #setDiff=%d\n',iter,lambdaLUCE_1,length(setDifference));
            end
            
        end        
        
    end
    
end

% Store last iteration as output
lambdaLUCE = lambdaLUCE_1;
u_hat = u1;
deltaLUCE = deltaU1;
epsilonLUCE = (rhoTab-lambdaLUCE.*deltaLUCE)./(1-lambdaLUCE);

if convergenceFlag==1
    disp('Maximal Separation Found');
end

if iter>maxIter
    disp('Algorithm stopped prematurely');
    disp('Maximum number of iterations exceeded');
end

end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% In this section, some of the auxiliary functions used above are defined

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function deltaU = deltaUfun(u_vec)
% This function computes the matrix of choice probabilities associated to u_vec:
% Each element of deltaU is u(x)/sum(u(y in the menu))

global nMenu nAlt domainTab

bigU = repmat(u_vec,nMenu,1);
bigU(domainTab==0)=0;
sumUtilityMenu = sum(bigU,2);
deltaU = bigU./repmat(sumUtilityMenu,1,nAlt);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function res = fLuce(sigma,x,u0,D_1,D_2)
% This function that defines implicitly the value of sigma
% It is used to find the new candidate utility function in each iteration

global nAlt rhoTab

% Direction of improvement
oneX    = zeros(1,nAlt);
oneX(x) = 1;

% Candidate utility function
uPrime = sigma.*oneX + (1-sigma).*u0;

% Associated matrix of choice probabilities: Each element of deltaUp is u(x)/sum(u(y in the menu))
deltaUprime = deltaUfun(uPrime);

% Compute LHS of the equation
LHS_OBJ = rhoTab(D_1,D_2)./deltaUprime(D_1,D_2);
LHS_OBJ(isnan(LHS_OBJ))=1;
minLHS  = min(LHS_OBJ(:));

% Compute RHS of the equation
RHS_OBJ = rhoTab(D_1,x)./deltaUprime(D_1,x);
RHS_OBJ(isnan(RHS_OBJ))=1;
minRHS  = min(RHS_OBJ(:));

% Compute residual of the equation
res = minRHS - minLHS;

end

