function quick_plot_bar(ymatrix1,LossName)

% Create figure
figure1 = figure('Name',LossName);

% Create axes
axes1 = axes('Parent',figure1);
hold(axes1,'on');

% Create multiple lines using matrix input to bar
bar1 = bar(ymatrix1,'Parent',axes1);
set(bar1(1),'DisplayName','MDS Estimation');
set(bar1(2),'DisplayName','LS Estimation');
set(bar1(3),'DisplayName','ML Estimation');


% Create ylabel
ylabel(LossName);

% Create xlabel
xlabel('Menu');

% Create title
title('Loss for each Menu');

box(axes1,'on');
% Create legend
legend1 = legend(axes1,'show');
set(legend1,'Location','best');

end
