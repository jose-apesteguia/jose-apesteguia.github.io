function [lambdaSCRUM,deltaSCRUM,epsilonSCRUM,muSCRUM] = MDS_BXSCRUM(rhoTab,domainTab,pathP)
% Function to compute maximal Delta-separations and maximal fraction of a dataset explained by
% a Single-Crossing Random Utility Model (SCRUM) on a given path "pathP"
%
% Follows the algorithm described in:
% Apesteguia & Ballester (2017), "Separating Predicted Randomness From Noise"
%
% Written by Angelo Gutierrez
% October 2017
%
% INPUT:
%
% rhoTab: Matrix with M rows and N columns, where N is the number of alternatives under consideration
% and each row represents a menu of alternatives in S in the domain set D. Each element of the matrix
% represents the probability of choosing an alternative in the corresponding menu, similar to table 1 in the paper
%
% domainTab: Matrix with M rows and N columns, where each row corresponds to a menu S and each column
% contains a binary number that takes value 0 if the alternative is not present in the menu and 1 otherwise
%
% pathP: (MxN) matrix describing the peference path. Each row represents a ordering of the preference relation i
% in the path. As an example, with three alternatives a1, a2 and a3; pathP(i,:) = [2,3,1] implies a2 > a3 > a1 for preference i
%
% OUTPUT:
%
% lambdaSCRUM: Scalar with maximal fraction of data explained by a model SCRUM
%
% deltaSCRUM: (MxN) SCF of the maximal Delta-separation describing randomness consistent with SCRUM
%
% epsilonSCRUM: (MxN) SCF of the maximal Delta-separation describing randomness inconsistent with SCRUM
%
% muSCRUM: Vector with probability distribution on pathP implied by deltaSCRUM
%
% Tested using Matlab 2017b

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Step 0: Compute some objects that will be required in the algorithm

% Number of menus and alternatives
[nMenu,nAlt] = size(domainTab);

% Number of preferences in path
nPath = size(pathP,1);

% Identifier for each menu and alternative
menuID = [1:nMenu]';
alternativeID = [1:nAlt]';

% Build matrix with collection of all strict preference relations on X
matP = perms(pathP(nPath,:));
nP = size(matP,1);

% Compute matrix of utilities consistent with the rankings implied by each preference
matU = nan(nP,nAlt);
auxVec = 10 + [nAlt:-1:1]';
for jPreference = 1:nP
    preferenceRank = nan(nAlt,1);
    Pj = matP(jPreference,:)';
    for iAlt = 1:nAlt
        preferenceRank(iAlt) = find(Pj==iAlt);
    end
    matU(jPreference,:) =  auxVec(preferenceRank);
end

% Compute matrix with alternative chosen from each menu, for each preference in preference ordering
% and the data associated to the observation
mP = nan(nP,nMenu);
rho_mP = nan(nP,nMenu);
for iMenu = 1:nMenu
    aInA = alternativeID(domainTab(iMenu,:)==1);
    [~,argMax] = max(matU(:, aInA ),[],2);
    mP(:,iMenu) = aInA(argMax);
    rho_mP(:,iMenu) = rhoTab(iMenu,mP(:,iMenu));
end

% Compute matrix with alternatives in binary sets
binarySet = nan(nMenu,2);
for iMenu = 1:nMenu
    binarySet(iMenu,:) = sort(alternativeID(domainTab(iMenu,:)==1));
end

% Position in matP of the preferences in pathP
[isP,idxP] = ismember(pathP,matP,'rows');
pathIdx = idxP(isP);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Step 1: Construct SCRUM stochastic choice functions for each preference P in matP, using only
% preferences less aligned than P and compute the corresponding maximal fraction of data they explain

% Preallocate some memory
lambda  = zeros(nP,1);

% Start with the first preference in pathP
lambda(pathIdx(1)) = min( rho_mP(pathIdx(1),:)  );
P_mu{1} = [pathIdx(1)];

% Now, consider every preference in pathP
for jPreference = 2:nPath
    
    % Pick the next preference on the list
    idx_P = pathIdx(jPreference);
    
    % Check which preferences are in the support of the SCRUM muSCRUM(P_prime) of the predecessor
    idx_P_mu_Pprime = P_mu{jPreference-1};
    
    % Now check which preferences in the support choose alternatives different from P in each menu A
    P_2prime = mP(idx_P,:) ~= mP(idx_P_mu_Pprime,:);
    lambdaTemp = lambda(idx_P_mu_Pprime);
    
    % Identify the maximal fraction of data explained by one of these preferences for each menu A
    maxList = nan(1,nMenu);
    for iMenu = 1:nMenu
        lambda_2prime = lambdaTemp(P_2prime(:,iMenu));
        if isempty(lambda_2prime)
            maxList(iMenu) = 0;
        else
            maxList(iMenu) = max(lambda_2prime);
        end
    end
    
    % And compute the fraction of data explained by this predecessor
    lambda(idx_P) = min( rho_mP(idx_P,:) + maxList );
    P_mu{jPreference} = [P_mu{jPreference-1},idx_P];
    
end

% Compute the maximal fraction of the data explained by SCRUM
lambda = lambda(pathIdx);
lambdaSCRUM = lambda(end);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%% Step 2: Compute auxiliary objects to get SCRUM probabilities



%%% Begin by computing the sets B_i sets with pairs of alternatives that are swapped between P(i) and P(i+1)

Bi = cell(2,1);
for jP = 1:(nPath-1)
    
    % Find swaped alternatives
    P1 = pathP(jP,:);
    P2 = pathP(jP+1,:);
    swapAlt = findSwaps(P1,P2);
    
    % Find position of corresponding menus
    [isMenu,idxSwap] = ismember(swapAlt,binarySet,'rows');
    swapAltIdx = idxSwap(isMenu);
    
    % Store this menu as Bi
    Bi{jP} = swapAltIdx';
    
end

% Compute r,s and t recursively
r = nan(nPath-1,1);
s = nan(nPath-1,1);
t = nan(nPath-1,1);

% Define domain
domainB = 1:nMenu;

% Find menu xy that minimizes rho(x,xy)
rhoPrec = rho_mP(pathIdx(1),:);
min_r = min(rhoPrec(domainB));
r(1) = min_r;

% Compute s1 and t1
max_s = max(rhoPrec(Bi{1}));
if isempty(max_s)
    s(1) = 0;
else
    s(1) = max_s;
end
t(1) = r(1)/( r(1)+1-s(1) );

% Now, find remaining r,s and t recursively
BiUnion = []; nPi = nPath-1;
for i = 2:(nPath-1)
    
    % Compute domain for optimization
    BiUnion = union(Bi{i-1},BiUnion);
    domainB = setdiff(1:nMenu,BiUnion);
    
    % Find menu xy that minimizes rho(x,xy)
    min_r = min(rhoPrec(domainB));
    max_s = max(rhoPrec(Bi{i}));
    
    if isempty(min_r)
        nPi = i-1;
        break;
    else
        
        if isempty(max_s)
            s(i) = 0;
        else
            s(i) = max_s;
        end
        
        r(i) = min_r;
        t(i) = max( t(i-1) , r(i)/( 1-s(i)+r(i) ) );
    end
    
end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %%%% Step 3: Compute the maximal Delta-separation <delta,epsilon>

% Start by computing the probability distribution mu on matP of the SCRUM implied by the MDS

% Compute the SCRUM probabilities recursively
nPi = min(nPi,nPath-1);
muSCRUM = zeros(nPath,1);

muSCRUM(1) = t(1);
for jP=2:nPi
    muSCRUM(jP) = t(jP) - t(jP-1);
end
muSCRUM(end) = 1 - t(nPi);

% Next, compute the choice function "deltaSCRUM" implied by muSCRUM
deltaSCRUM = zeros(nMenu,nAlt);
mP = mP(pathIdx,:);
for iMenu=1:nMenu
    for jAlt = 1:nAlt
        idx_mp_A = mP(:,iMenu) == jAlt ;  % Position of the alternatives that choose jAlt in iMenu
        pSCRUM = sum( muSCRUM(idx_mp_A) ); % Compute the probability implied by the SCRUM
        deltaSCRUM(iMenu,jAlt) = pSCRUM;
    end
end

% To conclude, compute the residual noise "epsilonSCRUM"
epsilonSCRUM = (rhoTab-lambdaSCRUM.*deltaSCRUM)./(1-lambdaSCRUM);

end


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% In this section, some of the auxiliary functions used above are defined

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function swapAlt = findSwaps(P1,P2)
% This function finds alternatives that need to be swapped to get from P1 to P2

% Find alternatives that differ between P1 and P2
altDiff = P1 - P2;
switched = altDiff~=0;

% Get initial and final lists
p1 = P1(switched);
p2 = P2(switched);

% Count swapped alternatives and swaps that must be done
nSwitched = length(p2);

% Create auxiliary labels for each alternative in p1 and p2
u1 = nan(1,nSwitched);
u2 = 1:nSwitched;
for iAlt = 1:nSwitched
    u1( p1 == p2(iAlt) ) = u2(iAlt);
end

% Find position swaps to get from u1 to u2
swapIdx = bubblesort(u1);

% Get list of swapped alternatives
swapAlt = nan(nSwitched-1,2);
for jP = 1:size(swapIdx,1)
    swapAlt(jP,:) = sort(p1(swapIdx(jP,:)));
end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function swapList = bubblesort(x)
%--------------------------------------------------------------------------
% Syntax:       sx = bubblesort(x);
%
% Inputs:       x is a vector of length n
%
% Outputs:      sx is the sorted (ascending) version of x
%
% Description:  This function sorts the input array x in ascending order
%               using the bubble sort algorithm
%
% Complexity:   O(n)      best-case performance
%               O(n^2)    average-case performance
%               O(n^2)    worst-case performance
%               O(1)      auxiliary space
%
% Author:       Brian Moore
%               brimoor@umich.edu
%
% Date:         January 5, 2014
%--------------------------------------------------------------------------

% Modified by �ngelo Guti�rrez to store list of swaps

% Bubble sort
n = length(x);
k=1;
swapList = nan(1,2);
I = 1:n;
while (n > 0)
    % Iterate through x
    nnew = 0;
    for i = 2:n
        % Swap elements in wrong order
        if (x(i) < x(i - 1))
            
            swapList(k,:) = [I(i),I(i-1)];
            I = swap(I,i,i - 1);
            k = k+1;
            
            x = swap(x,i,i - 1);
            nnew = i;
            
        end
    end
    n = nnew;
end

end

function x = swap(x,i,j)
% Swap x(i) and x(j)
% Note: In practice, x xhould be passed by reference

val = x(i);
x(i) = x(j);
x(j) = val;

end
