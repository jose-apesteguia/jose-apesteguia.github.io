function [lambdaTREMBLE,deltaTREMBLE,epsilonTREMBLE,P_hat,gammaOPT] = MDS_TREMBLE(rhoTab,domainTab)
% Function to compute maximal Delta-separations and maximal fraction of a dataset explained by
% a tremble model (TREMBLE)
%
% Follows the algorithm described in:
% Apesteguia & Ballester (2017), "Separating Predicted Randomness From Noise"
%
% Written by Angelo Gutierrez
% October 2017
%
% INPUT:
%
% rhoTab: Matrix with M rows and N columns, where N is the number of alternatives under consideration 
% and each row represents a menu of alternatives in S in the domain set D. Each element of the matrix 
% represents the probability of choosing an alternative in the corresponding menu, similar to table 1 in the paper
%
% domainTab: Matrix with M rows and N columns, where each row corresponds to a menu S and each column
% contains a binary number that takes value 0 if the alternative is not present in the menu and 1
% otherwise
%
% OUTPUT:
%
% lambdaTREMBLE: Scalar with maximal fraction of data explained by a model TREMBLE
%
% deltaTREMBLE: (MxN) SCF of the maximal Delta-separation describing randomness consistent with TREMBLE
%
% epsilonTREMBLE: (MxN) SCF of the maximal Delta-separation describing randomness inconsistent with TREMBLE
%
% P_hat: (1xN) vector describing the ordering of the preference relation implied by deltaTREMBLE
% As an example, with three alternatives a1, a2 and a3; P_hat = [2,3,1] implies a2 > a3 > a1
%
% gamma_hat: Scalar with the tremble probability implied by deltaTREMBLE
% As an example, with three alternatives a1, a2 and a3; P_hat = [2,3,1] implies a2 > a3 > a1
%
% Tested using Matlab 2017b
% Requires Matlab's Optimization Toolbox

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Step 0: Compute some objects that will be required in the algorithm

global nMenu nAlt nAltInMenu rho X idxX powerSetX alternativeID thereIsData isProperSubset isSubset mapNAlt

% Number of menus and alternatives in the dataset
[nMenuInD,nAlt] = size(domainTab);

% Create an indicator matrix with all possible menus formed with nAlt alternatives
X = 1:nAlt;
powerSetX = powerset(X);

% Drop the empty set an singletons from powersetX
powerSetX(sum(powerSetX,2)<=1,:) = [];

% Count alternatives in each menu of both the dataset and the powersetX
nAltInDomain = sum(domainTab,2);
nAltInMenu   = sum(powerSetX ,2);

% Count the number of menus in dataset and the power set
nMenu = size(powerSetX,1);

% Find the position of the set X with all menus
idxX = (nAltInMenu == nAlt);

% Since the domain is potentially a subset of the powersetX,
% we need to reorganize the data to match positions of the powersetX
rho = nan(nMenu,nAlt);
[thereIsData,whereIsData] = ismember(powerSetX,domainTab,'rows');
whereIsData(~thereIsData)=[];
rho(thereIsData,:) = rhoTab(whereIsData,:);% rho is the data organized to match the positions of powerSetX

% Create identifier for each menu and alternative
menuID = [1:nMenu]';
alternativeID = [1:nAlt]';

% Rank menus in the powersetX by the number of alternatives
rankByNumberAlt = [menuID, nAltInMenu];
rankByNumberAlt = sortrows(rankByNumberAlt,2);

% Create a map between old order of menus and sorted order
mapNAlt = [menuID,rankByNumberAlt(:,1)];

% Create a indicator matrix that identifies the menus that are subsets of a given menu

% WARNING: The approach used here is fast but takes a lot of memory, making the code unsuited for
% analysis with more than 15 alternatives
isSubset   = sparse(nMenu,nMenu);
for jCol = 1:nMenu
    yTemp = powerSetX(jCol,:);
    XsubsetY  = all( powerSetX <= yTemp, 2);
    isSubset(:,jCol) = XsubsetY;
end

% Build matrix identifying proper-subsets
isProperSubset = isSubset;
isProperSubset(1:nMenu+1:end) = 0; % Here I use Matlab's linear indexing to identify elements in the diagonal

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Step 1: Compute the maximal fraction of the data explained by TREMBLE
% Note: Check function "consistency_TREMBLE_gamma" defined at the end of this file

% Find the value of gamma that maximizes the fraction of data explained by a Tremble model
% Note: This is multiplied by a -1 because we use a minimization routine
options  = optimset('TolX',1e-6);

% Check interior solutions
[gammaInt,lambdaInt] = fminbnd( @(gam) -1.*consistency_TREMBLE_gamma(gam),0,1,options);
lambdaInt=-lambdaInt;

% Check corner solutions
lambda1=consistency_TREMBLE_gamma(1);
lambda0=consistency_TREMBLE_gamma(0);

% Find maximum
lambdaMax = max([lambda0,lambda1,lambdaInt]);

% Compute the maximal fraction of the data explained by a model with tremble probability gammaOPT
if lambdaMax == lambda0 && gammaInt ~= 0
    gammaOPT = 0;
elseif lambdaMax == lambda1 && gammaInt ~= 1
    gammaOPT = 1;
else
    gammaOPT = gammaInt;
end

[lambdaTREMBLE,mP] = consistency_TREMBLE_gamma(gammaOPT);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Step 2: Compute the maximal Delta-separation <delta,epsilon> using the value of gammaOPT found

% Compute the preference relation P_hat implied by the maximal Delta-separation
P_hat = nan(1,nAlt);
idxMenu = idxX;
for iMenu = 1:(nAlt-1)
    % Find the corresponding menu
    oldMenu = powerSetX(idxMenu,:);
    % k-most preferred alternative is the one chosen in the corresponding menu
    if isnan(mP(idxMenu))
        break;
    else
        P_hat(iMenu) = mP(idxMenu);
    end
    % Now, remove this alternative from the menu
    newMenu = oldMenu;
    newMenu(mP(idxMenu))=0;
    % Find position of the new menu and repeat
    [~,idxMenu]=ismember(newMenu,powerSetX,'rows');
end

% The least preferred alternative is the one that is left
if sum(isnan(P_hat))==1
    P_hat(end) = setdiff(alternativeID,P_hat(1:end-1));
end

% Next, compute an auxiliary vector of utilities consistent with the rankings implied by the preference
auxVec  = [nAlt:-1:1]'+10;
utility = nan(nAlt,1);
for iAlt = 1:nAlt
    if sum(P_hat==iAlt)==1
        utility(iAlt) = auxVec( P_hat==iAlt );
    else
        utility(iAlt) = 0;
    end
end

% Compute vector with the maximal alternative under P_hat for each menu in the domain D
mP_hat = nan(nMenuInD,1);
for iMenu = 1:nMenuInD
    S = domainTab(iMenu,:)==1;
    aInS = alternativeID(S);
    [~,idx_mP] = max( utility(aInS) );
    mP_hat(iMenu) = aInS(idx_mP);
end

% Compute the choice function "deltaTREMBLE" implied by P_hat and gammaOPT
deltaTREMBLE = zeros(nMenuInD,nAlt);
for iMenu=1:nMenuInD
    S = domainTab(iMenu,:)==1;  % Pick the menu S
    aInS = alternativeID(S);    % Check what alternatives are available in that menu
    nAltInS = length(aInS);     % Count number of alternatives in the menu
    mP_S = mP_hat(iMenu);       % Find the most preferred alternative in that menu, according to P_hat
    % Compute the probability of choosing each alternative in the menu:
    % - When the alternative is the most preferred
    deltaTREMBLE(iMenu,mP_S) = 1-gammaOPT*(nAltInS-1)/nAltInS;
    % - When its not
    not_mP_S = setdiff(aInS,mP_S);
    deltaTREMBLE(iMenu,not_mP_S) = gammaOPT/nAltInS;
end

% To conclude, compute the residual noise "epsilonTREMBLE"
epsilonTREMBLE = (rhoTab-lambdaTREMBLE.*deltaTREMBLE)./(1-lambdaTREMBLE);


end


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% In this section, some of the auxiliary functions used above are defined

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [lambda_hat,mP] = consistency_TREMBLE_gamma(gamma_hat)
% This function computes the maximal fraction of the data explained by a tremble model, for a given
% probability of tremble gamma_hat

global nMenu nAlt nAltInMenu rho X idxX powerSetX alternativeID thereIsData isProperSubset isSubset mapNAlt

%%%% Step A: Compute lambda values lambda(rho,A) for each menu that has no proper subsets

% Initialize
lambda = nan(nMenu,1); % Vector of maximal fractions for each menu
mP = nan(nMenu,1); % Vector of the chosen alternative in the menu, under P

% Start by identifying menus with no proper subsets
hasNoProperSubset = full( sum(isProperSubset,1)==0 )';

% Next, compute consistency for those menus with no proper subsets
for iMenu = 1:nMenu
    
    if hasNoProperSubset(iMenu)==1
        if thereIsData(iMenu)==1 % If there is data for that menu, compute the corresponding value of lambda
            S = powerSetX(iMenu,:)==1;  % Pick the menu S
            aInS = alternativeID(S);    % Check what alternatives are available in that menu
            nAltInS = length(aInS);     % Count number of alternatives in the menu
            % Now consider the consequences of placing each alternative in the menu as the maximal alternative
            GammaS  = nan(nAltInS,1);
            for jAlt = 1:nAltInS
                a = aInS(jAlt);      % Alternative a
                b = setdiff(aInS,a); % Alternatives in menu S different from a
                gamma1 = rho(iMenu,a)*nAltInS./( (1-gamma_hat)*nAltInS+gamma_hat);
                gamma2 = rho(iMenu,b)*nAltInS./gamma_hat;
                GammaS(jAlt) = min([gamma1,gamma2]);
            end
            % Compute maximal fraction for this set
            [lambda(iMenu),aArgMax] = max(GammaS);
            mP(iMenu) = aInS(aArgMax);
        else % Otherwise, set lambda and mP to zero
            lambda(iMenu) = nan;
            mP(iMenu) = nan;
        end
        
    end
    
end

%%%% Step B: Compute lambda values lambda(rho,A) for each menu with proper subsets

auxMat_nAltInMenu = repmat(nAltInMenu,nMenu,nAlt);
for iMenu = 1:nMenu % Loop across menus
    
    % Use the previous mapping to star with the menus that have fewer alternatives
    S = mapNAlt(iMenu,2);
    
    if hasNoProperSubset(S)==0
        
        % Create a list with alternatives in this menu
        aInS = alternativeID(powerSetX(S,:)==1);
        
        % Now consider the consequences of placing each alternative in the menu as the maximal alternative
        minList = nan(nAltInMenu(S),1);
        for jAlt = 1:nAltInMenu(S)
            
            % Pick alternative a
            a = aInS(jAlt);
            
            % Index of the subsets of "S" in domain set "D" that contain alternative "a"
            subDomain1 = (isSubset(:,S)==1) & (powerSetX(:,a)==1);
            
            % Index of the subsets of "S" in power set where alternative "a" is not present
            subDomain2 = (isSubset(:,S)==1) & (powerSetX(:,a)==0);
            
            %%% Now create a list of arguments to minimize
            
            % First list of arguments
            nAltInS = nAltInMenu(subDomain1); % Number of alternatives of each of the menus in subDomain1
            arg1 = rho(subDomain1,a).*nAltInS./( (1-gamma_hat).*nAltInS+gamma_hat) ;
            
            % Second list of arguments
            nAltInA = auxMat_nAltInMenu(subDomain1 & powerSetX & X~=a);
            rhoOtherAlt = rho( subDomain1 & powerSetX & X~=a );
            arg2 = rhoOtherAlt.*nAltInA./gamma_hat;
            
            % Third list of arguments
            arg3 = lambda(subDomain2);
            
            % Concatenate and find maximal fraction lambda for set S
            theList = [arg1;arg2;arg3];
            minList(jAlt) = min(theList);
            
        end
        
        % Compute maximal fraction for set S
        [lambda(S), argMax ] = max(minList);
        mP(S) = aInS(argMax);
        
    end
    
end

% Return the value of lambda corresponding to X
lambda_hat = lambda(idxX);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [Ipset, pset,setStr] = powerset(theSet)
% This function generates the an index matrix describing menus in the powerset of "theSet"

pset   = cell(size(theSet))      ; % Preallocate memory: Cell array describing alternatives in each menu
setStr = cell(size(theSet))      ; % Preallocate memory: Cell array describing alternatives in each menu
Ipset  = zeros(1,length(theSet)) ; % Preallocate memory: Indicator matrix describing alternatives in each menu

%Generate all numbers from 0 to 2^(num elements of the set)-1
for i = ( 0:(2^numel(theSet))-1 )
    
    %Convert i into binary, convert each digit in binary to a boolean
    %and store that array of booleans
    indices = logical(bitget( i,(1:numel(theSet)) ));
    
    %Use the array of booleans to extract the members of the original
    %set, and store the set containing these members in the powerset
    pset(i+1)             = {theSet(indices)};
    setStr{i+1}           = num2str(pset{i+1});
    Ipset(i+1,pset{i+1})  = 1;
    
end

end

