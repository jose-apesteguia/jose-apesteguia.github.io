function [delta_LS,P_hat_LS] = LS_DET(rhoTab,domainTab)
% Function to estimate the a model of deterministic rational choice (DET)
% from a dataset by minimizing the follosing loss function:
% LOSS = sum( (rho - delta).^2   ) [Least Squares]
%
% Follows the algorithm described in:
% Apesteguia & Ballester (2017), "Separating Predicted Randomness From Noise"
%
% Written by Angelo Gutierrez
% October 2017
%
% INPUT:
%
% rhoTab: Matrix with M rows and N columns, where N is the number of alternatives under consideration
% and each row represents a menu of alternatives in S in the domain set D. Each element of the matrix
% represents the probability of choosing an alternative in the corresponding menu, similar to table 1 in the paper
%
% domainTab: Matrix with M rows and N columns, where each row corresponds to a menu S and each column
% contains a binary number that takes value 0 if the alternative is not present in the menu and 1
% otherwise
%
% OUTPUT:
%
% delta_LS: Best specification of the model under least squares loss function
%
% P_hat_LS: (1xN) vector describing the ordering of the preference relation implied by delta_LS
% As an example, with three alternatives a1, a2 and a3; P_hat = [2,3,1] implies a2 > a3 > a1
%
% Tested using Matlab 2017b

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Compute some objects that will be required in the algorithm

% Number of menus and alternatives in the dataset
[nMenu,nAlt] = size(domainTab);

% Create an indicator matrix with all possible menus formed with nAlt alternatives
X = 1:nAlt;

% Create identifier for each menu and alternative
menuID = [1:nMenu]';
alternativeID = [1:nAlt]';

% Create the collection of all possible linear orderings of X
matP = perms(X);
nP   = size(matP,1);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Compute choice function delta implied by each P in matP and calculate the corresponding loss

% Initialize
LossFunction = nan(nP,3);

for jPreference = 1:nP
    
    % Pick a preference from the list
    P_hat = matP(jPreference,:);
    
    % Compute an auxiliary vector of utilities consistent with the rankings implied by the preference
    auxVec  = [nAlt:-1:1]'+10;
    utility = nan(nAlt,1);
    for iAlt = 1:nAlt
        if sum(P_hat==iAlt)==1
            utility(iAlt) = auxVec( P_hat==iAlt );
        else
            utility(iAlt) = 0;
        end
    end
    
    % Compute vector with the maximal alternative under P_hat for each menu in the domain D
    mP_hat = nan(nMenu,1);
    for iMenu = 1:nMenu
        S = domainTab(iMenu,:)==1;
        aInS = alternativeID(S);
        [~,idx_mP] = max( utility(aInS) );
        mP_hat(iMenu) = aInS(idx_mP);
    end
    
    % Compute the choice function delta_P implied by P_hat
    delta_P = zeros(size(rhoTab));
    delta_P(sub2ind(size(rhoTab),1:nMenu,mP_hat')) = 1;
    
    % Compute loss function
    LossFunction(jPreference) =  sum( sum( (delta_P-rhoTab).^2  ) ) ;
    
end


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Find the preferences that minimize each loss function and compute the corresponding choice functions
minLoss = min(LossFunction);

idx_P_opt = find(minLoss==LossFunction,1,'last');

P_hat =  matP(idx_P_opt,:);

% Compute an auxiliary vector of utilities consistent with the rankings implied by the preference
auxVec  = [nAlt:-1:1]'+10;
utility = nan(nAlt,1);
for iAlt = 1:nAlt
    if sum(P_hat==iAlt)==1
        utility(iAlt) = auxVec( P_hat==iAlt );
    else
        utility(iAlt) = 0;
    end
end

% Compute vector with the maximal alternative under P_hat for each menu in the domain D
mP_hat = nan(nMenu,1);
for iMenu = 1:nMenu
    S = domainTab(iMenu,:)==1;
    aInS = alternativeID(S);
    [~,idx_mP] = max( utility(aInS) );
    mP_hat(iMenu) = aInS(idx_mP);
end

% Compute the choice function "deltaDET" implied by P_hat
delta_P = zeros(size(rhoTab));
delta_P(sub2ind(size(rhoTab),1:nMenu,mP_hat')) = 1;

% Objects returned
delta_LS = delta_P;
P_hat_LS = P_hat;


end
