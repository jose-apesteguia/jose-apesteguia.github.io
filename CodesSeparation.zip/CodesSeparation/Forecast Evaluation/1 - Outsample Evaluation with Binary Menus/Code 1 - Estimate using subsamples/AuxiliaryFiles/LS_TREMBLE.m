function [delta_LS,P_hat_LS,gamma_hat_LS] = LS_TREMBLE_OLD(rhoTab1,domainTab1)
% Function to estimate the Tremble model (TREMBLE)
% from a dataset by minimizing the follosing loss function:
% LOSS = sum( (rho - delta).^2   ) [Least Squares]
%
% Follows the algorithm described in:
% Apesteguia & Ballester (2017), "Separating Predicted Randomness From Noise"
%
% Written by Angelo Gutierrez
% October 2017
%
% INPUT:
%
% rhoTab: Matrix with M rows and N columns, where N is the number of alternatives under consideration
% and each row represents a menu of alternatives in S in the domain set D. Each element of the matrix
% represents the probability of choosing an alternative in the corresponding menu, similar to table 1 in the paper
%
% domainTab: Matrix with M rows and N columns, where each row corresponds to a menu S and each column
% contains a binary number that takes value 0 if the alternative is not present in the menu and 1
% otherwise
%
% OUTPUT:
%
% delta_LS: Best specification of the model under least squares loss function
%
% P_hat_LS: (1xN) vector describing the ordering of the preference relation implied by delta_LS
% As an example, with three alternatives a1, a2 and a3; P_hat = [2,3,1] implies a2 > a3 > a1
% gamma_hat_LS: Scalar with the tremble probability implied by delta_LS
% As an example, with three alternatives a1, a2 and a3; P_hat = [2,3,1] implies a2 > a3 > a1
%
% Tested using Matlab 2017b
% Requires Matlab's Optimization Toolbox

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


global nMenu nAlt rhoTab domainTab menuID alternativeID nP matP

% Small step to make this variable global without issues
rhoTab = rhoTab1;
domainTab = domainTab1;

%%%% Compute some objects that will be required in the algorithm

% Number of menus and alternatives in the dataset
[nMenu,nAlt] = size(domainTab);

% Create an indicator matrix with all possible menus formed with nAlt alternatives
X = 1:nAlt;

% Create identifier for each menu and alternative
menuID = [1:nMenu]';
alternativeID = [1:nAlt]';

% Create the collection of all possible linear orderings of X
matP = perms(X);
nP   = size(matP,1);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Estimate gamma_hat

% Find the value of gamma that minimizes the log-likelihood
gamma_hat_LS = fminbnd( @(x) LossPfun(x) ,0,1);

% Use the estimated value of gamma to compute implied choice function and preference order
[~,delta_LS,P_hat_LS] = LossPfun(gamma_hat_LS);

end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% In this section, some of the auxiliary functions used above are defined

function [minLoss,delta_P,P_hat] = LossPfun(gammaOPT)

global nMenu nAlt rhoTab domainTab alternativeID nP matP

%%%% Compute choice function delta implied by each P in matP and calculate the corresponding loss

% Initialize
LossFunction = nan(nP,1);

for jPreference = 1:nP
    
    % Pick a preference from the list
    P_hat = matP(jPreference,:);
    
    % Compute an auxiliary vector of utilities consistent with the rankings implied by the preference
    auxVec  = [nAlt:-1:1]'+10;
    utility = nan(nAlt,1);
    for iAlt = 1:nAlt
        if sum(P_hat==iAlt)==1
            utility(iAlt) = auxVec( P_hat==iAlt );
        else
            utility(iAlt) = 0;
        end
    end
    
    % Compute vector with the maximal alternative under P_hat for each menu in the domain D
    mP_hat = nan(nMenu,1);
    for iMenu = 1:nMenu
        S = domainTab(iMenu,:)==1;
        aInS = alternativeID(S);
        [~,idx_mP] = max( utility(aInS) );
        mP_hat(iMenu) = aInS(idx_mP);
    end
    
    % Compute the choice function delta_P implied by P_hat and gammaOPT
    delta_P = zeros(nMenu,nAlt);
    
    for iMenu=1:nMenu
        S = domainTab(iMenu,:)==1;  % Pick the menu S
        aInS = alternativeID(S);    % Check what alternatives are available in that menu
        nAltInS = length(aInS);     % Count number of alternatives in the menu
        mP_S = mP_hat(iMenu);       % Find the most preferred alternative in that menu, according to P_hat
        % Compute the probability of choosing each alternative in the menu:
        % - When the alternative is the most preferred
        delta_P(iMenu,mP_S) = 1-gammaOPT*(nAltInS-1)/nAltInS;
        % - When its not
        not_mP_S = setdiff(aInS,mP_S);
        delta_P(iMenu,not_mP_S) = gammaOPT/nAltInS;
        
    end
    
    % Compute loss function
    LossFunction(jPreference) =  sum( sum( (delta_P-rhoTab).^2  ) ) ;
    
end

% Find the preferences that minimize each loss function and compute the corresponding choice functions
minLoss = min(LossFunction);
idx_P_opt = find(minLoss==LossFunction,1,'last');
P_hat =  matP(idx_P_opt,:);


end
