function [Loss_1,Loss_2,Loss_3] = Loss_Compute(deltaForecasted,deltaObserved)
% Function to compute distance between forecasted and observed probabilities

% Auxiliary objects
ratio_delta_rho = deltaForecasted./deltaObserved;
ratio_delta_rho(isnan(ratio_delta_rho))=1;
ratio_delta_rho(ratio_delta_rho==0) = 1e-4;
log_ratio_delta_rho = log(ratio_delta_rho);
log_ratio_rho_delta = -log_ratio_delta_rho;

% Loss functions
Loss_1 = max( log_ratio_delta_rho ) ; 
Loss_2 = sum( (deltaForecasted-deltaObserved).^2 ) ;
Loss_3 = sum( deltaObserved.*log_ratio_rho_delta );

end
