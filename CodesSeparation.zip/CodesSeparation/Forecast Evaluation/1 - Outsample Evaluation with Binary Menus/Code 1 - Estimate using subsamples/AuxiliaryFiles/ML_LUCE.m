function [delta_ML,u_hat_ML] = ML_LUCE(rhoTab1,domainTab1)
% Function to estimate the a Luce model (LUCE)
% from a dataset by minimizing the follosing loss function:
% LOSS = sum( rho.*(log(rho) - log(delta)) ) [Maximum Likelihood]
%
% Follows the algorithm described in:
% Apesteguia & Ballester (2017), "Separating Predicted Randomness From Noise"
%
% Written by Angelo Gutierrez
% October 2017
%
% INPUT:
%
% rhoTab: Matrix with M rows and N columns, where N is the number of alternatives under consideration
% and each row represents a menu of alternatives in S in the domain set D. Each element of the matrix
% represents the probability of choosing an alternative in the corresponding menu, similar to table 1 in the paper
%
% domainTab: Matrix with M rows and N columns, where each row corresponds to a menu S and each column
% contains a binary number that takes value 0 if the alternative is not present in the menu and 1
% otherwise
%
% OUTPUT:
%
% delta_ML: Best specification of the model under least squares loss function
%
% u_hat_ML: Utility vector of the model implied by the maximal Delta-separation
%
% Tested using Matlab 2017b
% Requires Matlab's Optimization Toolbox

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Compute some objects that will be required in the algorithm

global nMenu nAlt rhoTab domainTab u0 menuID alternativeID

% Small step to make this variable global without issues
rhoTab = rhoTab1;
domainTab = domainTab1;

% Number of menus and alternatives
[nMenu,nAlt] = size(domainTab);

% Identifier for each menu and alternative
menuID = [1:nMenu]';
alternativeID = [1:nAlt]';

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Estimate u_hat

% Initial value for estimation
u0 = ones(nAlt,1)./sum(ones(nAlt,1));

% Estimate u_hat by minimizing the loss function
option_vec = optimset('Display','iter','MaxFunEvals',100000,'MaxIter',1000, 'TolX',1e-9, 'TolFun',1e-9,'TolCon',1e-9);
[u_hat_ML,LossFunction]=fmincon(@(x) LossFun(x), u0,[],[],ones(1,nAlt),1,zeros(nAlt,1),ones(nAlt,1),[],option_vec);

% Get the implied choice function
delta_ML = deltaFun(u_hat_ML);

% Transpose and return
u_hat_ML = u_hat_ML';

end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% In this section, some of the auxiliary functions used above are defined

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Loss = LossFun(u_vec)
% This function computes the loss associated to a given utility vector u_vec

global rhoTab

% Compute the implied choice function
deltaLUCE = deltaFun(u_vec);

% Auxiliary objects
ratio_delta_rho = deltaLUCE./rhoTab;
ratio_delta_rho(isnan(ratio_delta_rho))=1;
ratio_delta_rho(ratio_delta_rho==0) = 1e-8;
log_ratio_delta_rho = log(ratio_delta_rho);
log_ratio_rho_delta = -log_ratio_delta_rho;

% Compute implied loss
Loss = sum( sum( rhoTab.*log_ratio_rho_delta ) ) ;
%Loss =  - prod(prod(deltaLUCE.^rhoTab )) ;

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function deltaLUCE = deltaFun(u_vec)
% This function computes the matrix of choice probabilities associated to u_vec:
% Each element of deltaU is u(x)/sum(u(y in the menu))

global nMenu nAlt domainTab

bigU = repmat(u_vec',nMenu,1);
bigU(domainTab==0)=0;
sumUtilityMenu = sum(bigU,2);
deltaLUCE = bigU./repmat(sumUtilityMenu,1,nAlt);

end
