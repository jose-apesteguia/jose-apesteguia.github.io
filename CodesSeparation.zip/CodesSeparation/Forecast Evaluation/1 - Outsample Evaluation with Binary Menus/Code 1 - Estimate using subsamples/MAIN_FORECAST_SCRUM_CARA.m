% SEPARATING PREDICTED RANDOMNESS FROM NOISE
% by Jose Apesteguia and Miguel A. Ballester
%
% Out-of-sample forecasts of the estimated models
% This file: SCRUM Model with CARA preferences
% Written by Angelo Gutierrez
% October 2017
%
% Tested using Matlab 2017b
% Requires Matlab's Optimization, Statistics and Machine Learning Toolbox

close all; clear all; clc;

addpath([pwd,'/AuxiliaryFiles']);

% Load dataset
load experimentDataBinaryMenus.mat

nMenu = size(domainTab,1);

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% Estimate the model using subsamples of N-1 menus and predict delta for the droped menu

tic;

% Preference path analyzed
P_CARA =[
    2   6   3   7   4   8   5   9   1
    2   6   3   7   4   8   5   1   9
    2   3   6   7   4   8   5   1   9
    2   3   6   4   7   8   5   1   9
    2   3   6   4   7   5   8   1   9
    2   3   4   6   7   5   8   1   9
    2   3   4   6   7   5   1   8   9
    2   3   4   6   5   7   1   8   9
    2   3   4   5   6   7   1   8   9
    3   2   4   5   7   6   1   8   9
    3   2   4   5   7   1   6   8   9
    3   2   4   5   1   7   6   8   9
    3   4   2   5   1   7   8   6   9
    4   3   2   5   1   8   7   6   9
    4   3   5   2   1   8   7   9   6
    4   3   5   1   2   8   7   9   6
    4   3   5   1   8   2   7   9   6
    4   3   5   1   8   7   2   9   6
    4   3   5   1   8   7   9   2   6
    4   5   3   1   8   9   7   2   6
    4   5   1   3   8   9   7   2   6
    4   5   1   8   3   9   7   2   6
    4   5   1   8   3   9   7   6   2
    4   5   1   8   9   3   7   6   2
    5   4   1   9   8   3   7   6   2
    5   1   4   9   8   3   7   6   2
    5   1   4   9   8   7   3   6   2
    5   1   9   4   8   7   3   6   2
    1   5   9   4   8   7   3   6   2
    1   5   9   8   4   7   3   6   2
    ];


for iSample = 1:nMenu
    
    %%% Crete sub-sample
    rhoTab_i    = rhoTab    ; rhoTab_i(iSample,:)    = [];
    domainTab_i = domainTab ; domainTab_i(iSample,:) = [];
    
    %%% Estimate model using sub-sample
    [lambdaSCRUM_CARA(iSample), deltaSCRUM_CARA{iSample}, epsilonSCRUM_CARA{iSample},muSCRUM_CARA{iSample}] = MDS_SCRUM(rhoTab_i,domainTab_i,P_CARA);
    [deltaSCRUM_CARA_LS{iSample},muSCRUM_CARA_LS{iSample}] = LS_SCRUM(rhoTab_i,domainTab_i,P_CARA);
    [deltaSCRUM_CARA_ML{iSample},muSCRUM_CARA_ML{iSample}] = ML_SCRUM(rhoTab_i,domainTab_i,P_CARA);

    %%% Predict decision of remaining menu using estimated models
    menu_i = domainTab(iSample,:);
    deltaF_MDS{iSample} = CHOICE_SCRUM(muSCRUM_CARA{iSample},P_CARA,menu_i);
    deltaF_LS{iSample}  = CHOICE_SCRUM(muSCRUM_CARA_LS{iSample},P_CARA,menu_i);
    deltaF_ML{iSample}  = CHOICE_SCRUM(muSCRUM_CARA_ML{iSample},P_CARA,menu_i);
    
    %%% Compute measures of forecast loss from the prediction
    rho_i = rhoTab(iSample,:);
    [Loss_MDS(iSample,1), Loss_MDS(iSample,2), Loss_MDS(iSample,3)] = Loss_Compute(deltaF_MDS{iSample},rho_i);
    [Loss_LS(iSample,1) , Loss_LS(iSample,2) , Loss_LS(iSample,3) ] = Loss_Compute(deltaF_LS{iSample} ,rho_i);
    [Loss_ML(iSample,1) , Loss_ML(iSample,2) , Loss_ML(iSample,3) ] = Loss_Compute(deltaF_ML{iSample} ,rho_i);
    
    % Display iteration
    iSample
    
end

% Time
toc

% Store
save ForecastResults_SCRUM_CARA.mat;

%% Compare the forecast error of the three models
menuVec = [1:nMenu]';

% Loss function implicit in MDS
disp(' ');
disp('Forecast Error: L1 Loss');
disp('          Menu        MDS          LS           ML');
[menuVec,round([Loss_MDS(:,1), Loss_LS(:,1), Loss_ML(:,1)],3)]
quick_plot_bar([Loss_MDS(:,1), Loss_LS(:,1), Loss_ML(:,1)],'L1');


% Loss function implicit in LS
disp(' ');
disp('Forecast Error: L2 Loss');
disp('          Menu        MDS          LS           ML');
[menuVec,round([Loss_MDS(:,2), Loss_LS(:,2), Loss_ML(:,2)],3)]
quick_plot_bar([Loss_MDS(:,2), Loss_LS(:,2), Loss_ML(:,2)],'L2');

% Loss function implicit in ML
disp(' ');
disp('Forecast Error: L3 Loss');
disp('          Menu        MDS          LS           ML');
[menuVec,round([Loss_MDS(:,3), Loss_LS(:,3), Loss_ML(:,3)],3)]
quick_plot_bar([Loss_MDS(:,3), Loss_LS(:,3), Loss_ML(:,3)],'L3');
