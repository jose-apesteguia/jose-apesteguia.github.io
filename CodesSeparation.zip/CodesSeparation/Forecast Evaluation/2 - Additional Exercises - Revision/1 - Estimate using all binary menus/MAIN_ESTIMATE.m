% SEPARATING PREDICTED RANDOMNESS FROM NOISE
% by Jose Apesteguia and Miguel A. Ballester
%
% This file:
%
% 1) Computes the Delta-Maximal Separation and maximal fraction of the 
% experimental dataset explained by each model reported in table 4
% (TREMBLE, LUCE, SCRUM-CRRA) using observations from the binary menus 
% available in the dataset
%
% 2) Computes the corresponding model estimated using Maximum Likelihood
%
% 3) Stores the estimated models in the file "estimatedModels.mat"
%
% Written by Angelo Gutierrez
% September 2019
%
% Tested using Matlab 2019a
% Requires Matlab's Optimization, Statistics and Machine Learning Toolbox

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Initialize
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clear; clc;

addpath([pwd,'/AuxiliaryFiles']);

% Load dataset
load experimentDataBinaryMenus.mat

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Model 1: Deterministic Rationality + Tremble (TREMBLE)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Maximum Delta-Separation

% Compute the maximal Delta-separation and the maximal fraction of data explained by TREMBLE
[lambdaTREMBLE_MS,deltaTREMBLE_MS,epsilonTREMBLE_MS,P_TREMBLE_MS,gammaTREMBLE_MS] = MDS_TREMBLE(rhoTab,domainTab);


%%%% Maximum Likelihood %%%%

% Estimate the model using ML loss function
[deltaTREMBLE_ML,P_TREMBLE_ML,gammaTREMBLE_ML] = ML_TREMBLE(rhoTab,domainTab);

% % Store
% save EstimationResults_TREMBLE.mat;
% 
% clearvars -except domainTab rhoTab;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Model 2: Luce Stochastic Choice Model (LUCE)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Maximum Delta-Separation

%%% Compute the maximal Delta-separation and the maximal fraction of data explained by LUCE
u0 = [1 5 9 8 4 7 3 6 2]; % Initial value for algorithm
fix_rng = 1  ; % Set to 1 to fix seed of rng in the algorithm
[lambdaLUCE_MS, deltaLUCE_MS, epsilonLUCE_MS, u_LUCE_MS] = MDS_LUCE(rhoTab,domainTab,u0,fix_rng);


%%%% Maximum Likelihood %%%%

% Estimate the model using ML loss function
[deltaLUCE_ML,u_LUCE_ML] = ML_LUCE(rhoTab,domainTab);

% % Store
% save EstimationResults_LUCE.mat;
% 
% clearvars -except domainTab rhoTab;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Model 3: Stochastic Choice Random Utility Model (SCRUM), CRRA Preferences
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Preference path analyzed
P_CRRA =[
    2   6   3   7   4   8   5   9   1
    2   6   3   7   4   8   5   1   9
    2   3   6   7   4   8   5   1   9
    2   3   6   4   7   8   5   1   9
    2   3   6   4   7   5   8   1   9
    2   3   4   6   7   5   8   1   9
    2   3   4   6   7   5   1   8   9
    3   2   4   7   6   5   1   8   9
    3   2   4   7   5   6   1   8   9
    3   2   4   7   5   1   6   8   9
    3   2   4   5   7   1   6   8   9
    3   4   2   5   7   1   8   6   9
    3   4   2   5   1   7   8   6   9
    3   4   5   2   1   7   8   9   6
    3   4   5   1   2   7   8   9   6
    3   4   5   1   7   2   8   9   6
    3   4   5   1   7   8   2   9   6
    3   4   5   1   7   8   9   2   6
    4   3   5   1   8   7   9   2   6
    4   3   5   1   8   7   9   6   2
    4   5   3   1   8   9   7   6   2
    4   5   1   3   8   9   7   6   2
    4   5   1   8   3   9   7   6   2
    4   5   1   8   9   3   7   6   2
    5   4   1   9   8   3   7   6   2
    5   1   4   9   8   3   7   6   2
    5   1   4   9   8   7   3   6   2
    5   1   9   4   8   7   3   6   2
    1   5   9   4   8   7   3   6   2
    1   5   9   8   4   7   3   6   2
    ];


%%%% Maximum Delta-Separation

% Compute the maximal Delta-separation and the maximal fraction of data explained by DET
[lambdaSCRUM_CRRA_MS, deltaSCRUM_CRRA_MS, epsilonSCRUM_CRRA_MS,muSCRUM_CRRA_MS] = MDS_SCRUM(rhoTab,domainTab,P_CRRA);

%%%% Maximum Likelihood %%%%

% Estimate the model using ML loss function
[deltaSCRUM_CRRA_ML,muSCRUM_CRRA_ML] = ML_SCRUM(rhoTab,domainTab,P_CRRA);

% Store
% save EstimationResults_SCRUM_CRRA.mat;
% 
% clearvars -except domainTab rhoTab;

clearvars domainTab rhoTab fix_rng;
save estimatedModels.mat;

%% Report

load estimatedModels.mat

writematrix(P_TREMBLE_MS','EstimatedModels.xlsx','Sheet','models','Range','B3');
writematrix(gammaTREMBLE_MS,'EstimatedModels.xlsx','Sheet','models','Range','B13');
writematrix(gammaTREMBLE_ML,'EstimatedModels.xlsx','Sheet','models','Range','C13');
writematrix(P_TREMBLE_ML','EstimatedModels.xlsx','Sheet','models','Range','C3');

writematrix(u_LUCE_MS','EstimatedModels.xlsx','Sheet','models','Range','F3');
writematrix(u_LUCE_ML','EstimatedModels.xlsx','Sheet','models','Range','G3');

writematrix(muSCRUM_CRRA_MS,'EstimatedModels.xlsx','Sheet','models','Range','J3');
writematrix(muSCRUM_CRRA_ML','EstimatedModels.xlsx','Sheet','models','Range','K3');
writematrix(P_CRRA,'EstimatedModels.xlsx','Sheet','models','Range','M3');
