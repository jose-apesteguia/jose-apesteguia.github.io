% SEPARATING PREDICTED RANDOMNESS FROM NOISE
% by Jose Apesteguia and Miguel A. Ballester
%
% This file:
%
% 1) Compares the predicted probability of choosing each alternative with the
% one observed in the data. This is done for menus with 3 and 5 alternatives. 
%
% 2) Results are printed in the Excel sheets "Results_Predictions" with the following sheets:
% - Menus: List of alternatives in each menu
% - Matrix: Matrix indicating probability of choosing each
% alternative in each menu
% - Vector_All: Vectorized version of above matrix, sorted from lowest to
% highest observed probability
% - Vector_Selected: Subsample of the above vector for which both MS and ML overpredict 
%
% Written by Angelo Gutierrez
% September 2019
%
% Tested using Matlab 2019a
% Requires Matlab's Optimization, Statistics and Machine Learning Toolbox

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Initialize
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clear; clc;

% Load estimates
load predictedChoice.mat

% Menu ID
nMenu = size(domainTab,1);
menuID = (1:nMenu)';

% Keep menus with 2 alternatives
nAltsInMenu = sum(domainTab,2);
dropIDX = nAltsInMenu <= 2 ;
rhoTab(dropIDX,:)   = [];
domainTab(dropIDX,:)  = [];
delta_hat_TREMBLE_MS(dropIDX,:) = [];
delta_hat_TREMBLE_ML(dropIDX,:) = [];
delta_hat_LUCE_MS(dropIDX,:)    = [];
delta_hat_LUCE_ML(dropIDX,:)    = [];
delta_hat_SCRUM_MS(dropIDX,:)   = [];
delta_hat_SCRUM_ML(dropIDX,:)   = [];
menuID(dropIDX,:)   = [];

nMenu = size(domainTab,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Compute and report vectorized version
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Auxiliary matrices
menuMat = repmat(menuID,1,9);
altsMat = repmat(1:9,nMenu,1);

% Vectorize
predictionMat = [menuMat(:),altsMat(:),rhoTab(:),delta_hat_TREMBLE_MS(:),delta_hat_TREMBLE_ML(:),...
    delta_hat_LUCE_MS(:),delta_hat_LUCE_ML(:),delta_hat_SCRUM_MS(:),delta_hat_SCRUM_ML(:)];

% Drop observations with zero observed probability of choice because they are not in the menu
dropList = predictionMat(:,3)==0;
predictionMat(dropList,:)=[];

% Sort based on observed probability of choice
predictionMat = sortrows(predictionMat,[3,1,2]);

% Alternatives in each menu
altsInMenu = dataset.dataTab.Row;
altsInMenuVec = altsInMenu(predictionMat(:,1));

% Vectors
menuVec = predictionMat(:,1);
altVec  = predictionMat(:,2);
rhoVec  = predictionMat(:,3);
tremble_MS = predictionMat(:,4);
tremble_ML = predictionMat(:,5);
luce_MS    = predictionMat(:,6);
luce_ML    = predictionMat(:,7);
scrum_MS   = predictionMat(:,8);
scrum_ML   = predictionMat(:,9);

% Compute % of times MS is better up to that observation
indMS_tremble = abs(rhoVec-tremble_MS)<abs(rhoVec-tremble_ML);
indMS_tremble(tremble_MS==tremble_ML)=0.5;
xMS_tremble   = cumsum(indMS_tremble)./cumsum(ones(length(rhoVec),1));
xrMS_tremble  = cumsum(indMS_tremble,'reverse')./cumsum(ones(length(rhoVec),1),'reverse');

indMS_luce = abs(rhoVec-luce_MS)<abs(rhoVec-luce_ML);
indMS_luce(luce_MS==luce_ML)=0.5;
xMS_luce   = cumsum(indMS_luce)./cumsum(ones(length(rhoVec),1));
xrMS_luce  = cumsum(indMS_luce,'reverse')./cumsum(ones(length(rhoVec),1),'reverse');

indMS_scrum = abs(rhoVec-scrum_MS)<abs(rhoVec-scrum_ML);
indMS_scrum(scrum_MS==scrum_ML)=0.5;
xMS_scrum   = cumsum(indMS_scrum)./cumsum(ones(length(rhoVec),1));
xrMS_scrum  = cumsum(indMS_scrum,'reverse')./cumsum(ones(length(rhoVec),1),'reverse');

table_tremble = [rhoVec, tremble_MS, tremble_ML, xMS_tremble , xrMS_tremble ];
table_luce    = [rhoVec, luce_MS   , luce_ML   , xMS_luce    , xrMS_luce    ];
table_scrum   = [rhoVec, scrum_MS  , scrum_ML  , xMS_scrum   , xrMS_scrum   ];

% Print
writematrix(menuVec,'Results_Predictions_3and5.xlsx','Sheet','Vector_ALL','Range','B3');
writecell(altsInMenuVec,'Results_Predictions_3and5.xlsx','Sheet','Vector_ALL','Range','C3');
writematrix(altVec ,'Results_Predictions_3and5.xlsx','Sheet','Vector_ALL','Range','D3');
writematrix(table_tremble,'Results_Predictions_3and5.xlsx','Sheet','Vector_ALL','Range','F3');
writematrix(table_luce,'Results_Predictions_3and5.xlsx','Sheet','Vector_ALL','Range','L3');
writematrix(table_scrum,'Results_Predictions_3and5.xlsx','Sheet','Vector_ALL','Range','R3');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Repeat using only those observations where both methods underpredict or overpredict
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rhoVecALL = rhoVec;

%%% Tremble

chosenObs_TREMBLE = tremble_MS-rhoVecALL>=0 & tremble_ML-rhoVecALL>=0;

% Vectors
menuVec = predictionMat(chosenObs_TREMBLE,1);
altVec  = predictionMat(chosenObs_TREMBLE,2);
rhoVec  = predictionMat(chosenObs_TREMBLE,3);
tremble_MS = predictionMat(chosenObs_TREMBLE,4);
tremble_ML = predictionMat(chosenObs_TREMBLE,5);
altsInMenuVec_TREMBLE = altsInMenu(predictionMat(chosenObs_TREMBLE,1));

% Compute % of times MS is better up to that observation
indMS_tremble = abs(rhoVec-tremble_MS)<abs(rhoVec-tremble_ML);
indMS_tremble(tremble_MS==tremble_ML) = 0.5;
xMS_tremble   = cumsum(indMS_tremble)./cumsum(ones(length(rhoVec),1));
xrMS_tremble  = cumsum(indMS_tremble,'reverse')./cumsum(ones(length(rhoVec),1),'reverse');

table_tremble = [rhoVec, tremble_MS, tremble_ML, xMS_tremble , xrMS_tremble ];

% Print
writematrix((1:length(menuVec))','Results_Predictions_3and5.xlsx','Sheet','Subsample_TREMBLE','Range','A3');
writematrix(menuVec,'Results_Predictions_3and5.xlsx','Sheet','Subsample_TREMBLE','Range','B3');
writecell(altsInMenuVec_TREMBLE,'Results_Predictions_3and5.xlsx','Sheet','Subsample_TREMBLE','Range','C3');
writematrix(altVec ,'Results_Predictions_3and5.xlsx','Sheet','Subsample_TREMBLE','Range','D3');
writematrix(table_tremble,'Results_Predictions_3and5.xlsx','Sheet','Subsample_TREMBLE','Range','F3');


%%% Luce

chosenObs_LUCE = luce_MS-rhoVecALL>=0 & luce_ML-rhoVecALL>=0;

% Vectors
menuVec = predictionMat(chosenObs_LUCE,1);
altVec  = predictionMat(chosenObs_LUCE,2);
rhoVec  = predictionMat(chosenObs_LUCE,3);
luce_MS = predictionMat(chosenObs_LUCE,6);
luce_ML = predictionMat(chosenObs_LUCE,7);
altsInMenuVec_LUCE = altsInMenu(predictionMat(chosenObs_LUCE,1));

% Compute % of times MS is better up to that observation
indMS_luce = abs(rhoVec-luce_MS)<abs(rhoVec-luce_ML);
indMS_luce(luce_MS==luce_ML) = 0.5;
xMS_luce   = cumsum(indMS_luce)./cumsum(ones(length(rhoVec),1));
xrMS_luce  = cumsum(indMS_luce,'reverse')./cumsum(ones(length(rhoVec),1),'reverse');

table_luce = [rhoVec, luce_MS, luce_ML, xMS_luce , xrMS_luce ];

% Print
writematrix((1:length(menuVec))','Results_Predictions_3and5.xlsx','Sheet','Subsample_LUCE','Range','A3');
writematrix(menuVec,'Results_Predictions_3and5.xlsx','Sheet','Subsample_LUCE','Range','B3');
writecell(altsInMenuVec_LUCE,'Results_Predictions_3and5.xlsx','Sheet','Subsample_LUCE','Range','C3');
writematrix(altVec ,'Results_Predictions_3and5.xlsx','Sheet','Subsample_LUCE','Range','D3');
writematrix(table_luce,'Results_Predictions_3and5.xlsx','Sheet','Subsample_LUCE','Range','F3');

%%% SCRUM

chosenObs_SCRUM = scrum_MS-rhoVecALL>=0 & scrum_ML-rhoVecALL>=0;

% Vectors
menuVec = predictionMat(chosenObs_SCRUM,1);
altVec  = predictionMat(chosenObs_SCRUM,2);
rhoVec  = predictionMat(chosenObs_SCRUM,3);
scrum_MS = predictionMat(chosenObs_SCRUM,8);
scrum_ML = predictionMat(chosenObs_SCRUM,9);
altsInMenuVec_SCRUM = altsInMenu(predictionMat(chosenObs_SCRUM,1));

% Compute % of times MS is better up to that observation
indMS_scrum = abs(rhoVec-scrum_MS)<abs(rhoVec-scrum_ML);
indMS_scrum(scrum_MS==scrum_ML) = 0.5;
xMS_scrum   = cumsum(indMS_scrum)./cumsum(ones(length(rhoVec),1));
xrMS_scrum  = cumsum(indMS_scrum,'reverse')./cumsum(ones(length(rhoVec),1),'reverse');

table_scrum = [rhoVec, scrum_MS, scrum_ML, xMS_scrum , xrMS_scrum ];

% Print
writematrix((1:length(menuVec))','Results_Predictions_3and5.xlsx','Sheet','Subsample_SCRUM','Range','A3');
writematrix(menuVec,'Results_Predictions_3and5.xlsx','Sheet','Subsample_SCRUM','Range','B3');
writecell(altsInMenuVec_SCRUM,'Results_Predictions_3and5.xlsx','Sheet','Subsample_SCRUM','Range','C3');
writematrix(altVec ,'Results_Predictions_3and5.xlsx','Sheet','Subsample_SCRUM','Range','D3');
writematrix(table_scrum,'Results_Predictions_3and5.xlsx','Sheet','Subsample_SCRUM','Range','F3');



