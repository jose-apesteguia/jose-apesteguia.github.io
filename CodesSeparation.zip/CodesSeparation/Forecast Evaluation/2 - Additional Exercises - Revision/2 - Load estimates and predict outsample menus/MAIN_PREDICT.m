% SEPARATING PREDICTED RANDOMNESS FROM NOISE
% by Jose Apesteguia and Miguel A. Ballester
%
% This file:
%
% 1) Computes the predicted probability of choosing a lottery in each of the
% menus available in the dataset for each of the estimated models considered 
% in table 4 (TREMBLE, LUCE, SCRUM-CRRA). Predictions are computed for two
% alternative estimation methods (MDS and ML). Estimates are loaded from the 
% file "estimatedModels.mat". 
%
% 2) Stores the predictions in the file "predictedChoice.mat"
%
% Written by Angelo Gutierrez
% September 2019
%
% Tested using Matlab 2019a
% Requires Matlab's Optimization, Statistics and Machine Learning Toolbox

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Initialize
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clear; clc;

addpath([pwd,'/AuxiliaryFiles']);

% Load dataset
load experimentData.mat

% Load estimates
load estimatedModels.mat

% Create datasets for algorithm
dataset   = experimentData.allSubjectsPooled;
rhoTab    = dataset.freqMat;
domainTab = dataset.menuMat;

% Make all alternatives in menu selected with positive probability
rhoTab(domainTab==1 & rhoTab==0) = 1e-2;
rhoTab = max(min(rhoTab,1),0);
rhoTab = rhoTab./repmat(sum(rhoTab,2),1,size(rhoTab,2));

% Keep all alternatives
nAltsInMenu = sum(domainTab,2);
nMenu = size(domainTab,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Predicted probability of choosing each alternative in each menu: TREMBLE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

delta_hat_TREMBLE_MS = nan(size(domainTab));
delta_hat_TREMBLE_ML = nan(size(domainTab));

for iSample = 1:nMenu
    menu_i = domainTab(iSample,:) ;
    delta_hat_TREMBLE_MS(iSample,:) = CHOICE_TREMBLE(P_TREMBLE_MS, gammaTREMBLE_MS, menu_i);    
    delta_hat_TREMBLE_ML(iSample,:) = CHOICE_TREMBLE(P_TREMBLE_ML, gammaTREMBLE_ML, menu_i); 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Predicted probability of choosing each alternative in each menu: LUCE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

delta_hat_LUCE_MS = nan(size(domainTab));
delta_hat_LUCE_ML = nan(size(domainTab));

for iSample = 1:nMenu
    menu_i = domainTab(iSample,:) ;
    delta_hat_LUCE_MS(iSample,:) = CHOICE_LUCE(u_LUCE_MS, menu_i);    
    delta_hat_LUCE_ML(iSample,:) = CHOICE_LUCE(u_LUCE_ML, menu_i); 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Predicted probability of choosing each alternative in each menu: SCRUM-CRRA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

delta_hat_SCRUM_MS = nan(size(domainTab));
delta_hat_SCRUM_ML = nan(size(domainTab));

for iSample = 1:nMenu
    menu_i = domainTab(iSample,:) ;
    delta_hat_SCRUM_MS(iSample,:) = CHOICE_SCRUM(muSCRUM_CRRA_MS,P_CRRA,menu_i);
    delta_hat_SCRUM_ML(iSample,:) = CHOICE_SCRUM(muSCRUM_CRRA_ML,P_CRRA,menu_i);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Store
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

save predictedChoice.mat