function deltaLUCE = CHOICE_LUCE(u_hat,menuList)
% Function to compute the probability of chosing each lottery in a list of menus
% using Luce model (LUCE)
%
% Follows the algorithm described in:
% Apesteguia & Ballester (2017), "Separating Predicted Randomness From Noise"
%
% Written by Angelo Gutierrez
% October 2017
%
% INPUT:
%
% u_hat: Utility vector of the Luce model
%
% menuList: Matrix with M rows and N columns, where each row corresponds to a menu S and each column
% contains a binary number that takes value 0 if the alternative is not present in the menu and 1
% otherwise
%
% OUTPUT:
%
% deltaLUCE: Matrix with M rows and N columns, where N is the number of alternatives under consideration
% and each row represents a menu of alternatives in S in the domain set D. Each element of the matrix
% represents the probability of choosing an alternative in the corresponding menu, similar to table 1 in the paper
%
% Tested using Matlab 2019a

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Number of menus and alternatives in the dataset
[nMenu,nAlt] = size(menuList);

% Auxiliar matrix of utilities of each menu
bigU = repmat(u_hat,nMenu,1);

% Consider only alternatives in the menu
bigU(menuList==0)=0;

% Compute corresponding probabilities
sumUtilityMenu = sum(bigU,2);
deltaLUCE = bigU./repmat(sumUtilityMenu,1,nAlt);

end
