function deltaTREMBLE = CHOICE_TREMBLE(P_hat,gamma_hat,menuList)
% Function to compute the probability of chosing each lottery in a list of menus
% using a model of deterministic rational choice with a tremble probability gamma_hat (TREMBLE)
%
% Follows the algorithm described in:
% Apesteguia & Ballester (2017), "Separating Predicted Randomness From Noise"
%
% Written by Angelo Gutierrez
% October 2017
%
% INPUT:
%
% P_hat: (1xN) vector describing the ordering of the preference relation of the model
% As an example, with three alternatives a1, a2 and a3; P_hat = [2,3,1] implies a2 > a3 > a1
%
% gamma_hat: Scalar with the tremble probability
%
% menuList: Matrix with M rows and N columns, where each row corresponds to a menu S and each column
% contains a binary number that takes value 0 if the alternative is not present in the menu and 1
% otherwise
%
% OUTPUT:
%
% deltaTREMBLE: (MxN) matrix where N is the number of alternatives under consideration
% and each row represents a menu of alternatives in S in the domain set D. Each element of the matrix
% represents the probability of choosing an alternative in the corresponding menu, similar to table 1 in the paper
%
% Tested using Matlab 2019a

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Number of menus and alternatives in the dataset
[nMenu,nAlt] = size(menuList);
alternativeID = [1:nAlt]';

% Compute an auxiliary vector of utilities consistent with the rankings implied by the preference
auxVec  = [nAlt:-1:1]'+10;
utility = nan(nAlt,1);
for iAlt = 1:nAlt
    if sum(P_hat==iAlt)==1
        utility(iAlt) = auxVec( P_hat==iAlt );
    else
        utility(iAlt) = 0;
    end
end

% Compute vector with the maximal alternative under P_hat for each menu in the domain D
mP_hat = nan(nMenu,1);
for iMenu = 1:nMenu
    S = menuList(iMenu,:)==1;
    aInS = alternativeID(S);
    [~,idx_mP] = max( utility(aInS) );
    mP_hat(iMenu) = aInS(idx_mP);
end

% Compute the choice function deltaTREMBLE implied by P_hat and gammaOPT
deltaTREMBLE = zeros(nMenu,nAlt);

for iMenu=1:nMenu
    
    % Pick the menu S
    S = menuList(iMenu,:)==1;
    
    % Check what alternatives are available in that menu
    aInS = alternativeID(S);
    
    % Count number of alternatives in the menu
    nAltInS = length(aInS);
    
    % Find the most preferred alternative in that menu, according to P_hat
    mP_S = mP_hat(iMenu);
    
    % Compute the probability of choosing each alternative in the menu:
    
    % - When the alternative is the most preferred
    deltaTREMBLE(iMenu,mP_S) = 1-gamma_hat*(nAltInS-1)/nAltInS;
    
    % - When its not
    not_mP_S = setdiff(aInS,mP_S);
    deltaTREMBLE(iMenu,not_mP_S) = gamma_hat/nAltInS;
    
end


end
