function deltaSCRUM = CHOICE_SCRUM(mu_hat,pathP,menuList)
% Function to compute the probability of chosing each lottery in a list of menus
% using a Single-Crossing Random Utility Model (SCRUM) on a given path "pathP"
%
% Follows the algorithm described in:
% Apesteguia & Ballester (2017), "Separating Predicted Randomness From Noise"
%
% Written by Angelo Gutierrez
% October 2017
%
% INPUT:
%
% mu_hat: (1xN) Vector with the SCRUM probability distribution on pathP
%
% pathP: (MxN) matrix describing the peference path. Each row represents a ordering of the preference relation i
% in the path. As an example, with three alternatives a1, a2 and a3; pathP(i,:) = [2,3,1] implies a2 > a3 > a1 for preference i
%
% menuList: (MxN) matrix where each row corresponds to a menu S and each column
% contains a binary number that takes value 0 if the alternative is not present in the menu and 1
% otherwise
%
% OUTPUT:
%
% deltaSCRUM: (MxN) matrix where N is the number of alternatives under consideration
% and each row represents a menu of alternatives in S in the domain set D. Each element of the matrix
% represents the probability of choosing an alternative in the corresponding menu according to the model
%
% Tested using Matlab 2019a

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Step 0: Compute some objects that will be required in the algorithm

% Number of menus and alternatives
[nMenu,nAlt] = size(menuList);
alternativeID = [1:nAlt]';

% Number of preferences in path
nP = size(pathP,1);

% Identifier for each menu and alternative
menuID = [1:nMenu]';
alternativeID = [1:nAlt]';

% Compute matrix of utilities consistent with the rankings implied by each preference
matU = nan(nP,nAlt);
auxVec = 10 + [nAlt:-1:1]';
for jPreference = 1:nP
    preferenceRank = nan(nAlt,1);
    Pj = pathP(jPreference,:)';
    for iAlt = 1:nAlt
        preferenceRank(iAlt) = find(Pj==iAlt);
    end
    matU(jPreference,:) =  auxVec(preferenceRank);
end

% Compute matrix with alternative chosen from each menu, for each preference in preference ordering
% and the data associated to the observation
mP = nan(nP,nMenu);
for iMenu = 1:nMenu
    aInA = alternativeID(menuList(iMenu,:)==1);
    [~,argMax] = max(matU(:, aInA ),[],2);
    mP(:,iMenu) = aInA(argMax);
end

% Compute the probabilities implied by mu_vec
deltaSCRUM = zeros(nMenu,nAlt);
for iMenu=1:nMenu
    for jAlt = 1:nAlt
        idx_mp_A = mP(:,iMenu) == jAlt ;  % Position of the preferences that choose jAlt in iMenu
        pSCRUM = sum( mu_hat(idx_mp_A) ); % Compute the probability implied by the SCRUM
        deltaSCRUM(iMenu,jAlt) = pSCRUM;
    end
end

end
