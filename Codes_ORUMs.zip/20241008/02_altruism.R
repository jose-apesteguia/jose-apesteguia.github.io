#---------------------#
# Title: 2. Altruism
# Project: Ordered Logit Empirical Applications
# Author: Carlos Gonzalez
# Date: October 2024
#---------------------#


# Step 1: Generate and Order Menu data #
#-------------------------------------#
# Generate menu data
data_gen_alt = function(J = 20, 
                        pi_vector = c(1/100, 1/10),
                        seed = 12345){
  
  # J: Number of menus
  # pi_vector: min and max in interval where prices are to sampled from
  #            according to Uniform distribution
  # seed for replicability
  
  # Set seed
  set.seed(seed)
  
  # Prices
  menu_data = replicate(2, runif(J, min = min(pi_vector), 
                                 max = max(pi_vector))) |> as_tibble()
  colnames(menu_data) = c("pi_1", "pi_2")
  
  # Order menus according to \pi_j ratios
  menu_data = menu_data |> mutate(pi_j = pi_2 / pi_1) |>
                           arrange(-pi_j) |>
                           mutate(menu = 1:J)
  
  menu_data
}

# LaTeX export function Table XX
export_table_2 = function(df){
  
  # df: An object created via data_gen_alt()
  
  df |> select(menu, pi_j, pi_1, pi_2) |>
        kbl(caption = "Menu Data as in Step 1. Section 7.2.",
            format="latex",
            col.names = c("Menu","\\pi_j", "\\pi_1", "\\pi_2"),
            align="c",
            digits = 3) |>
        kable_minimal(full_width = F,  html_font = "Source Sans Pro")
}

# Step 2: Generate N choices for each menu
#-----------------------------------------#
# (CES utility - Logistic distribution)
choice_data_alt_j = function(j, df, N,
                             tau = 0.2, sigma = 0.2, alpha = 0.4){
  
  # j index for menu
  # df: an object created via data_gen_alt()
  # N: Number of observations per menu (paper considers {20, 80, 160, 480})
  # tau: location parameter in Logit (main specification sets \tau = 0.2)
  # sigma: scale parameter in Logit (main specification sets \sigma = 0.2)
  # alpha: convexity parameter in altruism CES (main specification sets \sigma = 0.4)
  
  # Recover data for menu j \in J
  pi_1 = df$pi_1[j]
  pi_2 = df$pi_2[j]
  
  # Sample N risk_aversion parameters from logistic distribution
  t = rlogis(N, location = tau, scale = sigma)
  
  # Select optimally under CES utility considerations
  # Noting that: If t <= 0 \implies c_2 = 0
  c_1 = ifelse(t <= 0, 1 / pi_1, 1 / (pi_1 + pi_2 * (t * pi_1 / pi_2)^(1 / (1 - alpha))))
  c_2 = ifelse(t <=0, 0, (1 - pi_1 * c_1) / pi_2)
  
  # Bind data
  cbind(menu = rep(j, N),
        t_real = t,
        c_1 = c_1,
        c_2 = c_2)
}

# Generate data for all menus
choice_data_alt_gen = function(df, N = 160,
                           tau = .2, sigma = .2,
                           alpha = .4, seed = 12345){
  
  # df: an object created via data_gen_alt()
  # N: Number of observations per menu (paper considers {20, 80, 160, 480})
  # tau: location parameter in Logit (main specification sets \tau = 0.2)
  # sigma: scale parameter in Logit (main specification sets \sigma = 0.2)
  # alpha: convexity parameter in altruism CES (main specification sets \sigma = 0.4)
  # seed for replicability  
  
  # Set seed
  set.seed(seed)
  
  # Number of menus
  J = nrow(df)
  
  # lapply over choice_data_j
  cons_data = do.call(rbind, 
                      lapply(1:J, function(j) 
                        choice_data_alt_j(j, df, N,
                                          tau = tau, sigma = sigma,
                                          alpha = alpha))) |> as_tibble()
  colnames(cons_data) = c("menu", "t_real", "c_1", "c_2")
  
  # Merge in menu data and recover quantile info based on consumption ratio r (or v)
  cons_data |> left_join(df, by = "menu") |>
               mutate(r = c_2 / c_1,
                      v_j = 1 - exp(-c_2 /c_1),
                      n_obs = N) |>
               group_by(menu) |>
               mutate(quantile = signif(row_number(r) / N * 100)) |>
               ungroup()
  
}


# Plot v-CDF for each menu
plot_cdf_v = function(df_list, menu_selection, n_menus_random = 10, seed = 12345){
  
  # df_list: A list of one or more datasets created via choice_data_alt_gen()
  # menu_selection: one of c("all", "random", "num_vector")
  #   - all: selects all menus in unique(df$menu)
  #   - random: selects n_menus_random at random from unique(df$menu)
  #             if menu_selection != random, n_menus_random is ignored
  #   - num_vector: a vector of menus to be plotted i.e. c(1, 7, 14, 15)
  # seed for replicability (only relevant when menus are sampled at random)
  
  # Bind datasets together
  df = do.call(rbind, df_list)
  
  # Select menus according to user specification
  df = menu_selection_verif(df, menu_selection, n_menus_random)
  
  # Plot
  cdf_plot =
    df |> mutate(menu = as.factor(menu)) |>
    rename(Menu = menu) |>
    ggplot() +
    geom_line(aes(x = v_j, y = quantile, 
                  color = Menu,
                  linetype = Menu,
                  group = interaction(Menu))) +
    labs(group = "Menu", x = TeX(r"($v_j = 1 - e^{-r_j}$)"), 
         y = "Percentile") +
    theme_minimal() +
    #ggtitle("Empirical CDF for each Menu") +
    facet_wrap(~n_obs, nrow = 1) +
    theme(legend.position = "bottom",           
          legend.title = element_text(size = 16),
          legend.text = element_text(size = 16),
          axis.title.x = element_text(size = 16, 
                                      margin = margin(t = 10, r = 0, b = 0, l = 0)),
          axis.title.y = element_text(size = 16),
          strip.text = element_text(size = 16)) +
    guides(color = guide_legend(nrow = 1))
  
  plot(cdf_plot)
  ggsave("output/altruism_step2_cdf.png", cdf_plot, height = 5 , width = 10)
}

# Step 3: WARP for Altruism
#--------------------------#
# Verify WARP property for each pair of menus
altr_warp = function(menu_df, big_df){
  
  # menu_df: An object created via data_gen_alt()
  # big_df: An object created via choice_data_alt_gen()
  
  # Number of menus
  J = nrow(menu_df)
  
  # Find crossing points of budget line to identify x_{j j'}
  menu_df = menu_df |> mutate(y_point = 1 / pi_2,
                              x_point = 1 / pi_1)
  
  # Initialize store matrices
  inter_matrix = matrix(NA, J, J) # Intersection matrix
  viol_matrix = matrix(NA, J, J)  # Violations matrix
  
  # Find x_{j, j'} (NA when budgets lines do not intersect)
  for (i in 1:J){
    for (j in i:J){
      if((menu_df$y_point[i] > menu_df$y_point[j] & 
          menu_df$x_point[i] > menu_df$x_point[j]) |
         (menu_df$y_point[i] < menu_df$y_point[j] &
          menu_df$x_point[i] < menu_df$x_point[j]) | (i == j)) # Also not compare to menu to itself
        {
      } else{
        
        # Coordinates of x_{j j'}
        c_1_cross = (menu_df$y_point[i] - menu_df$y_point[j]) / (1 / menu_df$pi_j[i] - 1 / menu_df$pi_j[j])
        c_2_cross = menu_df$y_point[i] - 1 / menu_df$pi_j[i] * c_1_cross
        
        # Find v_j(x_{j j'})
        v_j = 1 - exp(-c_2_cross / c_1_cross)
        
        if(menu_df$pi_j[i] > menu_df$pi_j[j]){ # ONLY a potential violation when F_j < F_j' given pi_j > pi_j'
          inter_matrix[i,j] = v_j              # Hence, we only assign v(x_{j j'}) when pi_j > pi_j'
        } else{inter_matrix[j,i] = v_j} # One must be bigger than the other provided they intersect
        }
      }
  }
  
  # Check if F_j(v(x_{j,j'})) < F_j'(v(x_{j,j'})) [given pi_j < pi_j']
  for (i in 1:J){
    for (j in 1:J){
      if (!is.na(inter_matrix[i,j])){ # Only check comparable menus
        
        # F_j(v(x_{j,j'}))
        F_j = big_df[(big_df$menu == i & big_df$v_j <= inter_matrix[i,j]), ]$quantile |>
              max()
        # F_j'(v(x_{j,j'}))
        F_j_prime = big_df[(big_df$menu == j & big_df$v_j <= inter_matrix[i,j]), ]$quantile |>
                    max()
        
        if (F_j < F_j_prime){
          viol_matrix[i,j] = 1
        } else{viol_matrix[i,j] = 0}
      }
    }
  }
  
  # Output
  list(viol_matrix = viol_matrix,
       summary = tibble(menu = 1:J,
                        comp_cases = rowSums(!is.na(viol_matrix)),
                        share_viols = ifelse(comp_cases == 0, 0,
                                             rowSums(viol_matrix, na.rm = TRUE) / comp_cases)),
       total_violations = sum(viol_matrix, na.rm = T))
}

# Step 4. Recover Alpha
#--------------------------#
# Recover alpha function
recover_alpha = function(df, n_quantiles_alpha = n_quantiles_alpha_global,
                         seed_alpha = 12345){
  
  # df: an object created via choice_data_alt_gen()
  # n_quantiles_alpha: number of quantiles to be sampled in [40, 100] to estimate alpha
  # seed_alpha for replicability when estimating alpha
  
  # Select quantiles
  # Quantiles are sampled in the interval [40, 100] to guarantee only interior quantiles are sampled
  sel_quantiles = seq(40, 100, length.out = n_quantiles_alpha)
  
  # Select relevant subset of data
  df_alpha =  df |> filter(quantile  %in% sel_quantiles) |>
                    mutate(r = c_2 / c_1) |>
                    select(menu, pi_j, r, quantile)
  
  # Initialize dataset for computing all pairs of menus
  store = tibble(menu_1 = NA, pi_j1 = NA, r1 = NA, quantile_1 = NA, 
                 menu_2 = NA, pi_j2 = NA, r2 = NA, quantile_2 = NA)
  
  # Construct dataset with all pairs of menus
  for (p in sel_quantiles){
    df_p = df_alpha |> filter(quantile == p) |> as.matrix()
    for (i in 1:(nrow(df_p) - 1)){
      for (j in (i+1):nrow(df_p)){
        store = rbind(store, c(df_p[i,], df_p[j,]))
      }
    }
  }
  
  # Compute alpha for each pair of menus (belonging to the same quantile)
  store = store[-1,] |> mutate(alpha_inputed = log(pi_j1/pi_j2) / log(r1 / r2) + 1,
                               n_obs = df$n_obs[1])
  store
}


# Boxplot for inputted alpha distribution
plot_alpha = function(df_list, true_alpha){
  
  # df_list: A list of one or more objects created via recove_alpha()
  
  # Bind datasets together
  df = do.call(rbind, df_list) |> filter(alpha_inputed < 3, alpha_inputed > -3) # For display pursposes
  
  alpha_boxplot = 
  df |> ggplot() +
        geom_boxplot(aes(x = as.factor(n_obs), y = alpha_inputed)) +
        geom_hline(aes(yintercept = true_alpha), 
                   linetype = "dashed", color = "red", linewidth = 1) +
        labs(#title = TeX(r"(Boxplot of $\alpha$ by Number of Observations)"), 
             x = "Number of Observations", 
             y = TeX(r"($\alpha$)"),
             linetype = "", color = "") +
        theme_minimal() +
        theme(axis.text.x = element_text(size = 16),
              axis.title.y = element_text(size = 16),
              axis.title.x = element_text(size = 16, 
                                          margin = margin(t = 10, r = 0, b = 0, l = 0)))
  
  plot(alpha_boxplot)
  ggsave("output/altruism_step4_alpha_boxplot.png", alpha_boxplot, height = 5 , width = 5)
  
  # Output median alpha
  df |> group_by(n_obs) |> summarize(median_alpha = median(alpha_inputed))
  
}

# Step 5. Induced parameters
#---------------------------#

# Recover induced parameters based on consumption, menu data and recovered alpha
altruism_params = function(df, n_quantiles_alpha = n_quantiles_alpha_global,
                           seed_alpha = 12345){
  
  # df: an object created via choice_data_alt_gen()
  # n_quantiles_alpha: number of quantiles to be sampled in [40, 100] to estimate alpha
  # seed for replicability (only relevant for menu_selection = "random")
  
  # We first recover alpha as described in Step 4
  
  # Set seed
  set.seed(seed_alpha)

  # Select quantiles
  # Quantiles are sampled in the interval [40, 100] to guarantee only interior quantiles are sampled
  sel_quantiles = seq(40, 100, length.out = n_quantiles_alpha)
  
  # Initialize dataset for computing all pairs of menus
  store = tibble(menu_1 = NA, pi_j1 = NA, r1 = NA, quantile_1 = NA, n_obs_1 = NA,
                 menu_2 = NA, pi_j2 = NA, r2 = NA, quantile_2 = NA, n_obs_2 = NA)
  
  # Compute alpha for each individual dataset
  for (n in unique(df$n_obs)){
    
    # Select relevant subset of data
    df_alpha =  df |> filter(n_obs == n, quantile  %in% sel_quantiles) |>
                      mutate(r = c_2 / c_1) |>
                      select(menu, pi_j, r, quantile, n_obs)
    
    # Construct dataset with all pairs of menus
    for (p in sel_quantiles){
      df_p = df_alpha |> filter(quantile == p) |> as.matrix()
      for (i in 1:(nrow(df_p) - 1)){
        for (j in (i+1):nrow(df_p)){
          store = rbind(store, c(df_p[i,], df_p[j,]))
        }
      }
    }
  }
  
  # Compute alpha for each pair of menus (belonging to the same quantile and same dataset)
  store = store[-1] |> # Delete initial empty observation
          mutate(alpha_inputed = log(pi_j1/pi_j2) / log(r1 / r2) + 1,
                 n_obs = n_obs_1)
  
  # Recover median alpha
  median_alpha = store |> group_by(n_obs) |> summarize(alpha = median(alpha_inputed))
  
  # Prin inputted alpha
  print(median_alpha)
  
  # Recover induced t parameter and compute quantile
  df |> left_join(median_alpha, by = "n_obs") |>
        mutate(t = pi_j * (c_2 / c_1)^(1-alpha)) |>
        group_by(menu, n_obs) |>
        mutate(quantile_t = signif(row_number(t) / n_obs * 100) ) |>
        ungroup()
}

# Plot induced parameters ECDF for a selection of menus
# Plot induced parameters ECDF
plot_induced_param_alt = function(df_list, menu_selection = "random", n_menus_random = 10, seed = 12345,
                                  recover_params, n_quantiles_alpha = n_quantiles_alpha_global,
                                  seed_alpha = 12345){
  
  # df_list: a list of one or more objects created via choice_data_alt_gen()
  # menu_selection: one of c("all", "random", "num_vector")
  #   - all: selects all menus in unique(df$menu)
  #   - random: selects n_menus_random at random from unique(df$menu)
  #             if menu_selection != random, n_menus_random is ignored
  #   - num_vector: a vector of menus to be selected i.e. c(1, 7, 14, 15)
  # recover_params: a function which outputs an induced parameter t (like altruism_params)
  # n_quantiles_alpha: a number of quantiles to be sampled in [40, 100] to estimate alpha
  # seed_alpha: for replicability when estimating alpha
  # seed for replicability (only relevant for menu_selection = random)
  
  # Bind datasets together
  df = do.call(rbind, df_list)
  
  # Recover t-parameter via recover_params
  df = recover_params(df, n_quantiles_alpha = n_quantiles_alpha, seed_alpha = seed_alpha)
  
  # Set seed
  set.seed(seed)
  
  # Select menus for plotting according to user specification
  df = menu_selection_verif(df, menu_selection, n_menus_random)
  
  # Plot
  plot_cdf_induced_param =
    df |> filter(t < 1.5) |> # For plotting considerations only
    mutate(Menu = as.factor(menu)) |>
    ggplot() +
    geom_line(aes(x = t, y = quantile_t, 
                  color = Menu,
                  linetype = Menu,
                  group = interaction(Menu))) +
    labs(group = "Menu", x = TeX(r"(Induced Altruism Parameter)"), 
         y = "Percentile") +
    theme_minimal() +
    #ggtitle("Empirical Induced Parameter CDF for each Menu") +
    facet_wrap(~n_obs, ncol = 2) +
    theme(strip.text = element_text(size = 16),
          axis.title.y = element_text(size = 16),
          axis.title.x = element_text(size = 16, 
                                      margin = margin(t = 10, r = 0, b = 0, l = 0)))
  
  plot(plot_cdf_induced_param)
  ggsave("output/altruism_step5_cdf_induced_param.png", plot_cdf_induced_param, 
         height = 5 , width = 5)
  
}

# Step 6. Equality of distributions #
#-----------------------------------#

# Non-parametric testing AD and DTS
# Documentation: https://cran.r-project.org/web/packages/twosamples/twosamples.pdf

# So you need to decide on n_menus to recover alpha
# vs number of menus to perform the similarity testing on


# Semi-parametric testing function
similarity_testing_alt = function(df, recover_params,
                                  menu_selection = "all", n_menus_random = 10, seed = 12345,
                                  quant_selection = "percentile",
                                  n_quantiles_alpha = n_quantiles_alpha_global,
                                  seed_alpha = 12345){
  
  # df_list: a list of one or more objects created via choice_data_gen()
  # recover_params: a function which outputs an induced parameter t (like risk_aversion_params)
  # menu_selection: one of c("all", "random", "num_vector")
  #   - all: selects all menus in unique(df$menu)
  #   - random: selects n_menus_random at random from unique(df$menu)
  #             if menu_selection != random, n_menus_random is ignored
  #   - num_vector: a vector of menus to be selected i.e. c(1, 7, 14, 15)
  
  # quant_selection: one of c("percentile", "decile", "num_vector")
  #   - percentile: selects quantiles 1:100. quantiles need to be matched exactly
  #   - decile: selects quantiles 10, 20, ..., 100. quantiles need to be matched exactly
  #   - num_vector: a vector of quantiles to be selected i.e. c(19, 31, 42, 89)
  
  # n_quantiles_alpha: number of quantiles to be sampled in [40, 100] to estimate alpha
  # seed_alpha for replicability when estimating alpha
  # seed for replicability
  
  # Recover t-parameter via recover_params
  df = recover_params(df, n_quantiles_alpha = n_quantiles_alpha, 
                      seed_alpha = seed_alpha)
  
  # Set seed
  set.seed(seed)
  
  # Select menus according to user specification
  df = menu_selection_verif(df, menu_selection, n_menus_random)
  
  # Select quantiles according to user specification
  df = quant_selection_verif(df, quant_selection)
  
  # Auxiliary variables for menu comparison
  menu_list = unique(df$menu)
  J = length(menu_list)
  menu_tibble = tibble(menu_a = numeric(),
                       menu_b = numeric())
  
  # Generate grid of menu pairs
  for (m_1 in 1:J){
    for (m_2 in m_1:J){
      menu_tibble = rbind(menu_tibble, c("menu_a" = menu_list[m_1],
                                         "menu_b" = menu_list[m_2]))
    }
  }
  
  colnames(menu_tibble) = c("menu_a", "menu_b")
  
  # Testing #
  #---------#
  
  # Drop param = Inf values to compute integral
  if(max(df$t) == Inf){
    print("One or more induced parameters have been inputted to be Infinity")
    df = df |> filter(t < Inf)
  }
  
  # DTS
  tests_dts = mapply(dts_wrap, a = menu_tibble$menu_a,
                     b = menu_tibble$menu_b,
                     MoreArgs = list(df = df)) |> t() |>
    as_tibble(.name_repair = "minimal") |>
    mutate(test = "DTS")
  # AD
  tests_ad = mapply(ad_wrap, 
                    a = menu_tibble$menu_a,
                    b = menu_tibble$menu_b,
                    MoreArgs = list(df = df)) |> t() |> 
    as_tibble(.name_repair = "minimal") |>
    mutate(test = "AD")
  
  tests = rbind(tests_dts, tests_ad)
  colnames(tests) = c("t_stat", "p_value", "test")
  tests |> mutate(menu_pair = rep(sapply(1:nrow(menu_tibble), function(m) 
                                  paste0(menu_tibble$menu_a[m], "-",
                                  menu_tibble$menu_b[m])), 2),
                  n_obs = unique(df$n_obs))
}

# Boxplot distribution of test p-values
p_value_distribution_alt = function(df_list){
  
  # df_list a list of objects created via similarity_testing_alt()
  
  # Bind datasets together
  df = do.call(rbind, df_list)
  
  # Plot
  p_value_plot = 
    df |> ggplot() +
    geom_boxplot(aes(x = as.factor(n_obs), y = p_value)) +
    labs(#title = TeX(r"(Boxplot of p-values by Number of Observations)"), 
         x = "Number of Observations", 
         y = TeX(r"(p-values)")) +
    theme_minimal() +
    facet_wrap(~test) +
    theme(strip.text = element_text(size = 16),
          axis.text.x = element_text(size = 16),
          axis.title.y = element_text(size = 16),
          axis.title.x = element_text(size = 16, 
                                      margin = margin(t = 10, r = 0, b = 0, l = 0)))
  
  plot(p_value_plot)
  ggsave("output/altruism_step6a_pvalue_distribution.png", p_value_plot, height = 5 , width = 5)
}


# Step 6b. The aggregate quantile
#--------------------------------#
# Step 6b. Plot aggregated parameters
plot_induced_t_alt = function(df, recover_params, true_params,
                              n_quantiles_alpha = n_quantiles_alpha_global,
                              seed_alpha = 12345){
  
  # df: an object created via choice_data_gen_alt()
  # recover_params: a function which outputs an induced parameter t (like altruism_params)
  # n_quantiles_alpha: number of quantiles to be sampled in [40, 100] to estimate alpha
  # seed_alpha for replicability when estimating alpha
  # true_params: a vector of true parameters to be compared to
  
  # Recover t-parameter via recover_params
  df = recover_params(df, n_quantiles_alpha = n_quantiles_alpha,
                      seed_alpha = seed_alpha)
  
  # Generate auxiliary variable for display
  n_obs_vector = paste0(unique(df$n_obs), " obs")
  df = df |> mutate(value = paste(n_obs, "obs"),
                    quantile_t = row_number(t) / nrow(df) * 100) |> # compute aggregated quantile (not within menu quantile)
    select(t, quantile_t, value)
  
  # Generate fine-grained data from logistic distribution
  seq_log = seq(-2, max(df$t), 0.01)
  true_log_vector = paste0("Log(", true_params[1],", ", true_params[2], ")")
  logistic_data = tibble(t = seq_log,
                         quantile_t = plogis(t, loc = true_params[1],
                                             scale = true_params[2]) * 100,
                         value = true_log_vector)
  
  # Merge both datasets together
  plot_df = rbind(logistic_data, df)
  plot_df$value = factor(plot_df$value, 
                         levels = c(true_log_vector, n_obs_vector))
  
  # Plot induced_t parameter
  plot_aggregate_t =
    plot_df |> arrange(quantile_t) |> ggplot() +
    geom_line(aes(x = t, y = quantile_t, color = value,
                  linetype = value), linewidth = 1) +
    labs(x = "Induced Altruism Parameter", y = "Percentile") +
    scale_color_manual(values = c("red", "black")) +
    theme_minimal() +
    #ggtitle("Empirical CDF for induced t vs True Logistic") +
    theme(legend.title = element_blank(),
          axis.title.y = element_text(size = 16),
          axis.title.x = element_text(size = 16, 
                                      margin = margin(t = 10, r = 0, b = 0, l = 0)))
  
  plot(plot_aggregate_t)
  ggsave("output/altruism_step6b_aggregate_t_cdf.png", plot_aggregate_t, height = 5 , width = 5)
  
}

# Step 7. Mass analysis
#----------------------#
mass_analysis_alt = function(df_list){
  
  # df_list: a list of one or more objects created via choice_data_gen_alt()
  
  # Bind datasets together
  df = do.call(rbind, df_list)
  
  # Mass analysis
  mass_analysis_df =
    df |> mutate(larger_than_0 = ifelse(c_2 == 0, 1, 0)) |>
    group_by(menu, n_obs) |>
    summarize(mass_at_0 = mean(larger_than_0) * 100,
              largest_v = max(v_j),
              pi_j = mean(pi_2 / pi_1)) |>
    pivot_wider(names_from = n_obs, 
                values_from = c("largest_v", "mass_at_0"))
  
  # Output as list  
  list("largest_v_df" = mass_analysis_df |> select(menu, pi_j, starts_with("largest_v")),
       "mass_at_0_df" = mass_analysis_df |> select(menu, pi_j, starts_with("mass_at")))
}

# LaTeX output for mass analysis tables
mass_output_alt = function(df){
  
  # df: a tibble created via mass_analysis_alt()
  
  df |> select(menu, pi_j, ends_with("0")) |>
    kbl(format="latex",
        col.names = c("Menu","\\pi_j", "20 obs", "80 obs", "160 obs", "480 obs"),
        align="c",
        digits = 3) |>
    kable_minimal(full_width = F,  html_font = "Source Sans Pro")
}

# Step 8. CLA Property
#---------------------#

# Recover CLA property relevant data (sum of t and sum of log odds)
cla_data_alt = function(df, recover_params, 
                        choices_per_menu = 5, seed = 12345,
                        n_quantiles_alpha = n_quantiles_alpha_global,
                        seed_alpha = 12345){
  
  # df: an object created via choice_data_gen()
  # choices_per_menu: number of random choices to be selected by menu
  # recover_params: a function which outputs an induced parameter t (like altruism_params)
  # n_quantiles_alpha: number of quantiles to be sampled in [40, 100] to estimate alpha
  # seed_alpha: for replicability when estimating alpha
  
  # seed for replicability
  
  # Recover t-parameter via recover_params
  df = recover_params(df, n_quantiles_alpha = n_quantiles_alpha,
                      seed_alpha = seed_alpha)
  
  # Initialize df
  cla_df = tibble(menu = NA, t = NA, t_prime = NA, 
                  log_odds_t = NA, log_odds_t_prime = NA,
                  sum_t = NA, sum_log_odds = NA)
  
  # Set seed
  set.seed(seed)
  
  # Recover n observations per menu and merge together
  for (j in 1:length(unique(df$menu))){
    
    # Select menu
    df_menu = df |> filter(menu == j)
    
    # Compute ECDF
    ecdf_t = ecdf(df_menu |> pull(t)) # Including 0s
    
    # Sample interior observations
    index = sample(which(df_menu$t > 0 & df_menu$t < max(df_menu$t)), choices_per_menu)
    
    # Compute log_odds by using ecdf_t
    subset_menu_t = df_menu[index,] |> mutate(ecdf = ecdf_t(t),
                                              log_odds_t = log(ecdf / (1 - ecdf))) |>
      select(t, log_odds_t)
    
    # Create a mirror subset to sum across
    subset_menu_t_prime = subset_menu_t |> rename(t_prime = t,
                                                  log_odds_t_prime = log_odds_t)
    
    # Merge both data sets and sum across them 
    grid_t = expand_grid("t" = subset_menu_t$t, "t_prime" = subset_menu_t$t)
    df_t = grid_t |> left_join(subset_menu_t, by = "t") |>
                     left_join(subset_menu_t_prime, by = "t_prime") |>
                     mutate(sum_t = t + t_prime,
                            sum_log_odds = log_odds_t + log_odds_t_prime,
                            menu = j) |>
                    select(menu, t, t_prime, log_odds_t, 
                           log_odds_t_prime, sum_t, sum_log_odds)
    
    # Bind data
    cla_df = rbind(cla_df, df_t)
    
  }
  
  cla_df[-1,] # Exclude initial empty row
  cla_df$n_obs = unique(df$n_obs)
  cla_df
  
}

# Plot CLA property
plot_cla_alt = function(df_list, true_params){
  
  # df_list: a list of objects created via cla_data()
  # true_params: a vector of true parameters to be compared to
  
  # Initialize true_params
  tau = true_params[1]
  sigma = true_params[2]
  
  # Bind datasets together
  df = do.call(rbind, df_list)
  
  # Create segment according to true values
  # y = 1 / sigma * x - 2 * tau / sigma
  
  x_start = 0
  x_end = 2.5
  y_start = 1/sigma *(x_start - 2 * tau)
  y_end = 1/sigma *(x_end - 2 * tau)
  
  # Auxiliary vector with true parameter information
  true_log_vector = paste0("Log(", tau,", ", sigma, ")")
  
  # Plot
  cla_plot =
    df |> ggplot() +
    geom_point(aes(x = sum_t, y = sum_log_odds)) +
    geom_segment(aes(x = x_start, y = y_start, xend = x_end, yend = y_end,
                     color = true_log_vector), linewidth = 1) +
    scale_color_manual(values = "red") +
    theme_minimal() +
    labs(x = "Sum of Altruism Parameter t",
         y = TeX(r"(Sum $\log$ $\frac{F_j(t)}{1-F_j(t)}$)"),
         color = "") +
    #ggtitle("CLA Property") +
    facet_wrap(~n_obs, nrow = 1) +
    theme(legend.position = "bottom",           
          legend.title = element_text(size = 16),
          legend.text = element_text(size = 16),
          axis.title.x = element_text(size = 16, 
                                      margin = margin(t = 10, r = 0, b = 0, l = 0)),
          axis.title.y = element_text(size = 16),
          strip.text = element_text(size = 16))
  
  plot(cla_plot)
  ggsave("output/altruism_step8_cla_property.png", cla_plot, height = 5 , width = 10)
  
  # Regression
  sapply(unique(df$n_obs), cla_regression, df = df) 
  
}


# Step 9. Censored logit test
#----------------------------#

# Parametric estimation
parametric_estimation_alt = function(df, recover_params, 
                                     n_quantiles_alpha = n_quantiles_alpha_global,
                                     seed_alpha = 12345){
  
  # df: an object created via choice_data_gen_alt()
  # recover_params: a function which outputs an induced parameter t (like altruism_params)
  # n_quantiles_alpha: number of quantiles to be sampled (in [40, 100]) to estimate alpha
  # seed_alpha for replicability when estimating alpha
  
  # Recover t-parameter via recover_params
  df = recover_params(df, n_quantiles_alpha = n_quantiles_alpha,
                      seed_alpha = seed_alpha)
  
  # Auxiliary variables (see paper for reference and notation)
  M = nrow(df)
  M_0 = nrow(df[df$t == 0,])
  df_geq0 = df |> filter(t > 0) # Strictly positive observations
  
  # Start values in optimization
  start_values = c(mean(df_geq0$t), sd(df_geq0$t))
  
  # Optimization
  optim_results = optim(par = start_values, # Uses plug-in coefficients as starting values
                        fn = likelihood_function_logit,
                        gr = gradient_function_logit,
                        df_geq0 = df_geq0, # Optimize only c_2 > 0 observations
                        M_0 = M_0,
                        M = M,
                        method = 'Nelder-Mead',
                        control=list(fnscale = -1)) # To maximize (not minimize)  
  
  c("tau" = round(optim_results$par[1], 3),
    "sigma" = round(optim_results$par[2], 3),
    "avg_ll" = round(optim_results$value / unique(df$n_obs), 3))
}

# Step 10. Parametric Testing
#----------------------------#
# Testing ECDF vis-a-vis Logit
param_testing_alt = function(df, optim_params, recover_params,
                             n_quaniles_alpha = 4, seed_alpha = 12345){
  
  # df: an object created via choice_data_gen_alt()
  # optim_params: vector of parameters estimated via parametric_estimation() or parametric_estimation_alt()
  # recover_params: a function which outputs an induced parameter t (like altruism_params)
  # n_quantiles_alpha: number of quantiles to be sampled (in [40, 100]) to estimate alpha
  # seed_alpha for replicability when estimating alpha
  
  # Initialize variables
  tau = optim_params[1]
  sigma = optim_params[2]
  
  # Inputs
  # p_value index
  p_value_vector = c(0.5, 0.25, 0.15, 0.1, 0.05, 0.025, 0.01, 0.005)
  
  # p-value matrices
  #KS P-values according to Table 4.4. in p.112 of Agostino and Stephens
  ks_p_values = matrix(c(.4923, .6465, .7443, .8155, .9268, 1.0282, 1.1505, 1.2361,
                         .5889, .7663, .8784, .9597, 1.0868, 1.2024, 1.3419, 1.4394,
                         .6627, .8544, .9746, 1.0616, 1.1975, 1.3209, 1.4696, 1.5735,
                         .7204, .9196, 1.0438, 1.1334, 1.2731, 1.3997, 1.5520, 1.6583,
                         .7649, .9666, 1.0914, 1.1813, 1.3211, 1.4476, 1.5996, 1.7056,
                         .7975, .9976, 1.1208, 1.2094, 1.3471, 1.4717, 1.6214, 1.7258,
                         .8183, 1.0142, 1.1348, 1.2216, 1.3568, 1.4794, 1.6272, 1.7306,
                         .8270, 1.0190, 1.1379, 1.2238, 1.3581, 1.4802, 1.6276, 1.7308,
                         .8276, 1.0192, 1.1379, 1.2238, 1.3581, 1.4802, 1.6276, 1.7308), 
                       nrow = 9, ncol = 8, byrow = T)
  
  #Cramer-Von Misses P-values according to Table 4.4. in p.112 of Agostino and Stephens
  cvm_p_values = matrix(c(.010, .025, .033, .041, .057, .074, .094, .110,
                          .022, .046, .066, .083, .115, .147, .194, .227,
                          .037, .076, .105, .136, .184, .231, .295, .353,
                          .054, .105, .153, .186, .258, .330, .427, .488,
                          .070, .136, .192, .241, .327, .417, .543, .621,
                          .088, .165, .231, .286, .386, .491, .633, .742,
                          .103, .188, .259, .321, .430, .544, .696, .816,
                          .115, .204, .278, .341, .455, .573, .735, .865,
                          .119, .209, .284, .347, .461, .581, .743, .869),
                        nrow = 9, ncol = 8, byrow = T)
  
  matrices = list(ks_p_values,
                  cvm_p_values)
  
  # Recover parameters via recover_params
  df = recover_params(df, n_quantiles_alpha = n_quantiles_alpha,
                      seed_alpha = seed_alpha)
  
  # Auxiliary variables (See paper for reference)
  M = nrow(df)
  M_0 = nrow(df[df$t == 0,])
  share_available = (1 - M_0 / M) |> round(1)
  
  # Check validity of reference tables
  if (share_available < 0.2){stop("Share of censored values is too high (>0.9) as for current methods to be applicable")}
  
  # Compute additional variables according to notation in Agostino and Stephens
  df_r = df |> arrange(t) |>
    mutate(pred_cdf = 1 / (1 + exp(-(t - tau) / sigma)), # Predicted CDF for logistic
           i_value = 1:nrow(df)) |>
    filter(t > 0) |>
    mutate(M_star = ifelse(t == lead(t), 0, 1), 
           M_star = ifelse(is.na(M_star), 1, M_star)) |> # Assign value to last entry (which (i) does not have a lead by definition, but (ii) is in M^*) 
    filter(M_star == 1)
  
  # KS test
  ks_test = sqrt(M) * max(abs(M_0 / M - 1 / (1 + exp(tau / sigma))), abs(max(df_r$i_value / M - df_r$pred_cdf))) + 0.19 / sqrt(M)
  
  # CVM test
  # Input additional missing observation for cvm testing (see textbook for reference)
  df_r_plus = rbind(df_r[1,], df_r)
  df_r_plus$i_value[1] = min(df_r_plus$i_value) - 1
  df_r_plus$pred_cdf[1] = 1 / (1 + exp(tau / sigma))
  
  # We further delete observations with ECDF = 1
  df_r_plus = df_r_plus |> filter(pred_cdf < 1)
  r = nrow(df_r_plus)
  M = M + 1
  
  # Cramer-Von Misses test
  cvm_test = sum((df_r_plus$pred_cdf - (2*df_r_plus$i_value - 1)/(2*M))^2) + r / (12*M^2) + M/3 * (df_r_plus$pred_cdf[1] - df_r_plus$i_value[1]/M)^3
  
  # Identify closest point in Tables for comparison
  tests = abs(c(ks_test, cvm_test))
  p_values = c()
  
  for(j in 1:length(tests)){
    relevant_row = matrices[[j]][share_available*10 - 1,]
    min_p_value = max(relevant_row[tests[j] - relevant_row > 0])
    if (is.na(min_p_value)){
      p_values_index = min(which(is.na(relevant_row)))
      p_values[j] = p_value_vector[p_values_index]
    } else if(min_p_value == -Inf){
      p_values[j] = "> 0.5"
    } else{
      p_values_index = which(relevant_row == min_p_value)
      p_values[j] = p_value_vector[p_values_index]}
  }
  
  # Query value
  store_tests = tibble(test = c("KS", "CVM"),
                       test_statistic = tests,
                       rounded_share_available = share_available,
                       p_values = p_values)
  
  store_tests
}