#---------------------#
# Title: 1. Risk
# Project: Ordered Logit Empirical Applications
# Author: Carlos Gonzalez
# Date: October 2024
#---------------------#

# Step 1: Generate and Order Menu data #
#-------------------------------------#

# Menu data
data_gen = function(J = 20, 
                    pi_vector = c(1/100, 1/10), 
                    q_vector = c(1/5, 4/5), 
                    seed = 12345){
  
  # J: Number of menus
  # pi_vector: min and max in interval where prices are to sampled from according to Uniform distribution
  # q_vector: min and max in interval where probs are to be sampled from according to Uniform distribution
  # seed for replicability
  
  # Set seed
  set.seed(seed)
  
  # Prices
  pi = replicate(2, runif(J, min = min(pi_vector), 
                              max = max(pi_vector)))
  
  # Probs
  q_1 = runif(J, min = min(q_vector), max = max(q_vector))
  q = cbind(q_1, 1 - q_1)
  
  # cbind data
  menu_data = cbind(pi, q) |> as_tibble()
  colnames(menu_data) = c("pi_1_orig", "pi_2_orig",
                          "q_1_orig", "q_2_orig")
  
  # Compute phi_ratios
  menu_data = menu_data |> mutate(phi_1_orig = pi_1_orig / q_1_orig,
                                  phi_2_orig = pi_2_orig / q_2_orig)
  
  menu_data
  
}

# Order choices such that \phi_1 < \phi_2
# Order menus such that menu 1 : \argmin_j \phi_j = \phi_2 / \phi_1
order_data = function(df){
  
  # df: An object created via data_gen()
  
  # Intuition: If \phi_1 < \phi_2, then keep as it is; else reverse
  # Creade additional metrics
  # Order menus according to \phi_j
  df |> mutate(pi_1 = ifelse(phi_1_orig < phi_2_orig, pi_1_orig, pi_2_orig),
               pi_2 = ifelse(phi_1_orig < phi_2_orig, pi_2_orig, pi_1_orig),
               q_1 = ifelse(phi_1_orig < phi_2_orig, q_1_orig, q_2_orig),
               q_2 = ifelse(phi_1_orig < phi_2_orig, q_2_orig, q_1_orig),
               phi_1 = ifelse(phi_1_orig < phi_2_orig, phi_1_orig, phi_2_orig),
               phi_2 = ifelse(phi_1_orig < phi_2_orig, phi_2_orig, phi_1_orig),
               log_phi_1 = log(phi_1),
               log_phi_2 = log(phi_2),
               phi_j = phi_2 / phi_1)|>
        arrange(phi_j) |>
        mutate(menu = 1:nrow(df)) |>
        select(-ends_with("orig"))
}

# LaTeX export function Table 1
export_table_1 = function(df){
  
  # df: An object created via order_data()
  
  df |> select(menu, pi_1, pi_2, q_1, phi_1, phi_2) |>
        kbl(caption = "Menu Data as in Step 1. Section 6.2.",
            format="latex",
            col.names = c("Menu","\\pi_1", "\\pi_2", "q_1", "\\phi_1", "\\phi_2"),
            align="c",
            digits = 3) |>
        kable_minimal(full_width = F,  html_font = "Source Sans Pro")
}

# Step 2: Generate Choice Data
#-----------------------------#
# (CRRA utility - Logistic distribution)

# Generate data for single menu j
choice_data_j = function(j, df, N,
                         tau, sigma){
  
  # j index for menu
  # df: an object created via order_data()
  # N: Number of observations per menu (paper considers {20, 80, 160, 480})
  # tau: location parameter in Logit (main specification sets \tau = 0.6)
  # sigma: scale parameter in Logit (main specification sets \sigma = 0.3)
  
  # Recover data for menu j \in J
  pi_1 = df$pi_1[j]
  pi_2 = df$pi_2[j]
  phi_1 = df$phi_1[j]
  phi_2 = df$phi_2[j]
  
  # Sample N risk_aversion parameters from logistic distribution
  t = rlogis(N, location = tau, scale = sigma)
  
  # Select optimally under CRRA utility considerations
  # Noting that: If risk aversion <= 0 \implies c_2 = 0
  r = (phi_2 / phi_1)^(-1/t)
  c_2 = ifelse(t <= 0, 0, r / (pi_1 + r * pi_2))
  c_1 = (1 - pi_2 * c_2) / pi_1
  
  # Bind data
  cbind(menu = rep(j, N),
        c_1 = c_1,
        c_2 = c_2,
        t_real = t)
}

# Generate data for all menus
choice_data_gen = function(df, N = 160, tau = 0.6, sigma = 0.3, seed = 1234){
  
  # df: an object created via order_data()
  # N: Number of observations per menu (paper considers {20, 80, 160, 480})
  # tau: location parameter in Logit (main specification sets \tau = 0.6)
  # sigma: scale parameter in Logit (main specification sets \sigma = 0.3)
  
  # Set seed
  set.seed(seed)
  
  # Number of menus
  J = nrow(df)
  
  # lapply over choice_data_j
  cons_data = do.call(rbind, 
                      lapply(1:J, function(j) 
                                    choice_data_j(j, df, N, tau, sigma))) |> as_tibble()
  colnames(cons_data) = c("menu", "c_1", "c_2", "t_real")
  
  # Merge in menu data and recover quantile info based on consumption ratio r
  cons_data |> left_join(df, by = "menu") |>
               mutate(n_obs = N,
                      r = c_2 / c_1) |>
               group_by(menu) |>
               mutate(quantile = signif(row_number(r) / N * 100)) |>
               ungroup()
  
}

# Auxiliary function for menu selectino
menu_selection_verif = function(df, menu_selection, n_menus_random){ 
  
  # df: An object created via choice_data_gen()
  # menu_selection: one of c("all", "random", "num_vector")
  #   - all: selects all menus in unique(df$menu)
  #   - random: selects n_menus_random at random from unique(df$menu)
  #             if menu_selection != random, n_menus_random is ignored
  #   - num_vector: a vector of menus to be selected i.e. c(1, 7, 14, 15)
  
  # Select menus according to user specification
  if (is.character(menu_selection)){
    if(menu_selection == "all"){
    } else if(menu_selection == "random"){
      sel_menus = sample(unique(df$menu), n_menus_random)
      df = df |> filter(menu %in% sel_menus)
    }
  } else{
    df = df |> filter(menu %in% menu_selection)
  }
  
  # Selected menus
  print(paste("The following menus are considered"))
  print(unique(df$menu))
  
  # Return df
  df
  
}

# Plot CDF of consumption ratio for a selection of menus (Figure 1)
plot_cdf = function(df_list, menu_selection, n_menus_random = 10, seed = 12345){
  
  # df_list: A list of one or more datasets created via choice_data_gen()
  # menu_selection: one of c("all", "random", "num_vector")
  #   - all: selects all menus in unique(df$menu)
  #   - random: selects n_menus_random at random from unique(df$menu)
  #             if menu_selection != random, n_menus_random is ignored
  #   - num_vector: a vector of menus to be plotted i.e. c(1, 7, 14, 15)
  # seed for replicability (only relevant when menus are sampled at random)
  
  # Bind datasets together
  df = do.call(rbind, df_list)
  
  # Select menus according to user specification
  df = menu_selection_verif(df, menu_selection, n_menus_random)
  
  # Plot
  cdf_plot =
  df |> mutate(menu = as.factor(menu)) |>
        rename(Menu = menu) |>
        ggplot() +
        geom_line(aes(x = r, y = quantile, 
                      color = Menu,
                      linetype = Menu,
                      group = interaction(Menu))) +
        labs(group = "Menu", x = TeX(r"(Consumption Ratio $r = c^2_j / c^1_j$)"), 
             y = "Percentile") +
        theme_minimal() +
        #ggtitle("Empirical CDF for each Menu") +
        facet_wrap(~n_obs, nrow = 1) +
        theme(legend.position = "bottom",           
              legend.title = element_text(size = 16),
              legend.text = element_text(size = 16),
              axis.title.x = element_text(size = 16, 
                                          margin = margin(t = 10, r = 0, b = 0, l = 0)),
              axis.title.y = element_text(size = 16),
              strip.text = element_text(size = 16)) +
         guides(color = guide_legend(nrow = 1))
  
  plot(cdf_plot)
  ggsave("output/risk_step2_cdf.png", cdf_plot, height = 5 , width = 10)
}

# Step 3: Directed Graph
#-----------------------#

# Auxiliary function for quantile_selection

quant_selection_verif = function(df, quant_selection){ 
  
  # df: an object created via choice_data_gen()
  # quant_selection: one of c("percentile", "decile", "num_vector")
  #   - percentile: selects quantiles 1:100. quantiles need to be matched exactly
  #   - decile: selects quantiles 10, 20, ..., 100. quantiles need to be matched exactly
  #   - num_vector: a vector of quantiles to be selected i.e. c(19, 31, 42, 89)

  # Select quantiles according to user specification
  if (is.character(quant_selection)){
    if(quant_selection == "percentile"){
      df = df |> filter(quantile %in% 1:100)
      print(paste(length(unique(df$quantile)), "percentiles are considered for analysis"))
    } else if(quant_selection == "decile"){
      df = df |> filter(quantile %in% seq(10, 100, by = 10))
      print(paste(length(unique(df$quantile)), "deciles are considered for analysis"))
    }
  } else{
    df = df |> filter(quantile %in% quant_selection) # For numeric vectors
    print(paste(length(unique(df$quantile)), "quantiles are considered for analysis"))
  }
  
  # Return df
  df
  
}


# Generate Matrix

# Matrix function for single coordinate (j,k) in matrix
matrix_function = function(j, k, df){
  
  # j: row coordinate
  # k: column coordinate
  # df: an object created via ordere_data()
  
  # Initialize
  c_1_j = df$c_1[j]
  c_2_j = df$c_2[j]
  c_1_k = df$c_1[k]
  c_2_k = df$c_2[k]
  
  log_phi_1_j = df$log_phi_1[j]
  log_phi_1_k = df$log_phi_1[k]
  log_phi_2_j = df$log_phi_2[j]
  log_phi_2_k = df$log_phi_2[k]
  
  # When sampled at random from a prob distribution with continuous density
  # The only tie with positive probability is c_2_j = c_2_k = 0
  # We break ties in favor of the "cheapest" c_2
    # (i.e. if c_2_j = c_2_k then assign c_2_j > c_2_k \iff phi_j < phi_k)
    # Note that Prob(phi_j = phi_k) = 0
  
  if(c_2_j == c_2_k){ # Break ties
    
    # Compute phi_ratios
    phi_j = df$phi_2[j] / df$phi_1[j]
    phi_k = df$phi_2[k] / df$phi_1[k]
    
    # Break in favor of "cheapest" c_2
    if (phi_j < phi_k){c_2_j = c_2_j + 0.0001} else{c_2_k = c_2_k + 0.0001}
  } 
  
  # Initialize
  int_jk = -Inf
  int_kj = -Inf
  
  # Cases as defined in Table 2 in Section 6.2
  if(c_1_j > c_2_j & c_2_j > c_1_k & c_1_k > c_2_k){ # Case 1
    int_jk = log_phi_1_k - log_phi_1_j
    int_kj = Inf
  } else if(c_1_j > c_1_k & c_1_k > c_2_j & c_2_j >= c_2_k){ # Case 2
    int_jk = max(log_phi_1_k - log_phi_1_j, log_phi_2_k - log_phi_2_j)
    int_kj = log_phi_2_j - log_phi_1_k
  } else if(c_1_j > c_1_k & c_1_k > c_2_k & c_2_k >= c_2_j){ # Case 3
    int_jk = log_phi_1_k - log_phi_1_j
    int_kj = log_phi_2_j - log_phi_2_k
  } else if(c_1_k > c_1_j & c_1_j > c_2_j & c_2_j >= c_2_k){ # Case 4
    int_jk = log_phi_2_k - log_phi_2_j
    int_kj = log_phi_1_j - log_phi_1_k
  } else if(c_1_k > c_1_j & c_1_j > c_2_k & c_2_k >= c_2_j){ # Case 5
    int_jk = log_phi_2_k - log_phi_1_j
    int_kj = max(log_phi_1_j - log_phi_1_k, log_phi_2_j - log_phi_2_k)
  } else if(c_1_k > c_2_k & c_2_k > c_1_j & c_1_j > c_2_j){ # Case 6
    int_jk = Inf
    int_kj = log_phi_1_j - log_phi_1_k
  }
  
  # Export coordinates and results
  rbind(c(j, k , int_jk),
        c(k, j, int_kj))
}

# Weight-matrix generating function (for single quantile) and selection of menus
# It mapplys matrix function for all menu pairs
gen_weight_matrix = function(df, p = 50,
                             menu_selection = "all", n_menus_random = 10,
                             plot = F, weights = F, seed = 12345){
  
  # df: an object created via choice_data_gen()
  # p: quantile to be considered
  # menu_selection: one of c("all", "random", "num_vector")
  #   - all: selects all menus in unique(df$menu)
  #   - random: selects n_menus_random at random from unique(df$menu)
  #             if menu_selection != random, n_menus_random is ignored
  #   - num_vector: a vector of menus to be selected i.e. c(1, 7, 14, 15)
  # plot: logical indicating if plotting weighted matrix
  # weights: logical indicating whether edge width should be proportional to weights
  # seed for replicability (only relevant when menu_selection = random)
  
  # Set seed
  set.seed(seed)
  
  # Select quantile
  df = df |> filter(quantile == p)
  
  # Select menus
  df = menu_selection_verif(df, menu_selection, n_menus_random)
  
  # Generate coords for fast matrix inputation
  coords = expand.grid(j = 1:nrow(df), k = 1:nrow(df)) # k = j' (see paper for notation)
  coords = coords[coords$j > coords$k,] # w[j, j] will be imputed a value of 0
  
  # Mapply matrix function
  matrix_list = mapply(matrix_function, 
                       j = coords$j,
                       k = coords$k,
                       MoreArgs = list(df), 
                       SIMPLIFY = FALSE)
  
  # Recover matrix from list input
  matrix_tibble = do.call(rbind, matrix_list) |> as_tibble(.name_repair = "minimal")
  colnames(matrix_tibble) = c("row", "column", "value")
  mat =  matrix_tibble |>
         pivot_wider(names_from = column, values_from = value) |>
         arrange(row) |>
         column_to_rownames(loc = "row") |>
         as.matrix()
  
  # Set diagonal = 0 [not relevant for computation]
  diag(mat) = 0
  
  # Plotting weighted matrix
  if (plot){
    # Plotting software does not allow for infinite weights
    # Replace infinite weights with expression below
    max_mat = max(mat[mat<Inf]) * 1.1
    mat = ifelse(mat == Inf, max_mat, mat)
    
    # Create graph from matrix
    g = graph_from_adjacency_matrix(mat, mode = "directed", 
                                    weighted = T, diag = F)
    
    # Assign names if relevant
    if (is.numeric(menu_selection)){
      V(g)$name = menu_selection
    } else{V(g)$name = 1:nrow(mat)}
    
    # Plot aesthetics
    
    # Vertex Color
    V(g)$color = "white"
    
    # Edge attributes
    E(g)$color = ifelse(E(g)$weight >= 0, "lightgrey", "black")
    
    # Arrow size
    E(g)$arrow.size = 0.01
    
    # If weights = T, transform weights appropriately
    if (weights){
      E(g)$weight = 5*abs(E(g)$weight) # Thicken weights proportionally for display considerations
    } else{
      E(g)$weight = 1
    }
    
    # Saving plot
    filename = paste0("output/risk_step3_weighted_graph_", unique(df$n_obs),
                      "w_", weights,  ".pdf")
    pdf(filename)
    
    plot(g,layout = layout_with_fr,  # Fruchterman-Reingold layout for display
         vertex.size = 15,            # Adjust vertex size
         vertex.label.color = "black",# Vertex label color
         vertex.label.cex = 1,      # Vertex label size
         edge.curved = 0.2,           # Add slight curvature to edges
         edge.width = E(g)$weight)    # Use weight as width
    
    dev.off()
    
    # Plotting plot
    plot(g,layout = layout_with_fr,  # Fruchterman-Reingold layout for display
         vertex.size = 15,            # Adjust vertex size
         vertex.label.color = "black",# Vertex label color
         vertex.label.cex = 1,      # Vertex label size
         edge.curved = 0.2,           # Add slight curvature to edges
         edge.width = E(g)$weight)    # Use weight as width
    }
  
  # Export matrix
  mat
}

# Step 4. Bellman Ford
#----------------------#

# Note: To avoid overwriting temporal objects while vectorizing
# this program creates external files in your device
# These files are deleted upong completion of the task

# BF for single quantile
bellman = function(mat, p){
  
  # mat: a matrix object created via gen_weight_matrix
  # : quantile to be considered
  
  # Create graph
  g = graph_from_adjacency_matrix(mat, mode = "directed", 
                                  weighted = T, diag = F)
  
  # Run Bellman-Ford Algorithm
  # It is a fully connected graph hence it suffices to look for paths between any two vertices
  suppressWarnings(b <<- try(
    bellmanFord(g, from = V(g)[1], to = V(g)[2]), silent = T))
  
  # Stores error in outside folder to avoid in-console displays
  if(inherits(b, "try-error")){
    export = c("quantile" = p) |> t()
    write.table(export, file = "output/errors.csv", sep = ",",
                col.names = F, row.names = F, append = T)
  }
}

# Full BF routine for single quantile
full_rout_bell = function(df, p, menu_selection,
                          n_menus_random, seed){
  
  # df: an object created via choice_data_gen()
  # p: quantile to be considered
  # menu_selection: one of c("all", "random", "num_vector")
  #   - all: selects all menus in unique(df$menu)
  #   - random: selects n_menus_random at random from unique(df$menu)
  #             if menu_selection != random, n_menus_random is ignored
  #   - num_vector: a vector of menus to be selected i.e. c(1, 7, 14, 15)
  
  # seed for replicability (only relevant when menu_selection = random)
  
  # Generate matrix (plotting is not allowed within full_rout_bell)
  mat = gen_weight_matrix(df, p = p, 
                          menu_selection = menu_selection, n_menus_random,
                          seed = seed)
  # Run BF
  bellman(mat, p)
}

# Workers function for multiprocessing
n_workers_function = function(workers = n_workers){return(workers)}

# Parallel process over quantiles
lapply_routine_bell = function(df, quant_selection = "percentile",
                               menu_selection = "all", n_menus_random = 10, seed = 12345){
  
  # df: an object created via choice_data_gen()
  # quant_selection: one of c("percentile", "decile", "num_vector")
  #   - percentile: selects quantiles 1:100. quantiles need to be matched exactly
  #   - decile: selects quantiles 10, 20, ..., 100. quantiles need to be matched exactly
  #   - num_vector: a vector of quantiles to be selected i.e. c(19, 31, 42, 89)
  
  # menu_selection: one of c("all", "random", "num_vector")
  #   - all: selects all menus in unique(df$menu)
  #   - random: selects n_menus_random at random from unique(df$menu)
  #             if menu_selection != random, n_menus_random is ignored
  #   - num_vector: a vector of menus to be selected i.e. c(1, 7, 14, 15)
  
  # seed for replicability (only relevant for menu_selection = "random")
  
  # Select quantiles according to user specification
  df = quant_selection_verif(df, quant_selection)
  
  # Initialize directory for storing errors while vectorizing
  if (file.exists("output/errors.csv")){unlink("output/errors.csv")}
  
  # Plan multi-session
  plan(multisession(workers = n_workers_function()))
  
  # Vectorize full_routine bell
  future_lapply(sort(unique(df$quantile)), 
                full_rout_bell, df = df,
                menu_selection = menu_selection,
                n_menus_random = n_menus_random,
                seed = seed,
                future.seed = T)
  
  if (file.exists("output/errors.csv")){
    
    # Recover errors for analysis and display
    summary_tab = read.csv("output/errors.csv", header = FALSE) |> as_tibble()
    colnames(summary_tab) = "quantile"
    
    # Delete external file
    unlink("output/errors.csv")
    
    # Display
    return(summary_tab |> arrange(quantile))
  } else{print("Your dataset satisfies SAREU for all considered quantiles")}
}

# Choose representative data
# We observed some variation in the number of non-rationalizable quantiles
# To provide a representative view of the number of mistakes, we iterated the code above across different seeds
# And selected a seed which reports a number of violations close to this 10-fold average

seed_iteration_bellman = function(seed){
  
  # Generate Choice data
  n20_data = choice_data_gen(menu_data, 20, seed = seed)
  n80_data = choice_data_gen(menu_data, 80, seed = seed)
  n160_data = choice_data_gen(menu_data, 160, seed = seed)
  n480_data = choice_data_gen(menu_data, 480, seed = seed)
  
  # Apply algorithm across datasets
  viols_n20_data = lapply_routine_bell(n20_data, quant_selection = quantile_vector)
  viols_n80_data = lapply_routine_bell(n80_data, quant_selection = quantile_vector)
  viols_n160_data = lapply_routine_bell(n160_data, quant_selection = quantile_vector)
  viols_n480_data = lapply_routine_bell(n480_data, quant_selection = quantile_vector)
  
  # Bind data together
  viols = rbind(viols_n20_data, viols_n80_data, viols_n160_data, viols_n480_data) |>
          mutate(iter = seed)
  
}

# Sapply seed_iteration_bellman 10 times and output
seed_iteration_wrap = function(){
  
  # Iterate across different seeds
  sapply(1:10, seed_iteration_bellman)
  
  # Initialize output tibble
  store_viols = tibble(quantile = NA, iter = NA, dataset = NA)
  
  # Output tibble formatting
  for (i in 1:ncol(viols_iter)){
    viol_inter = do.call(cbind, viols_iter[,i])
    viol_inter = viol_inter |> as_tibble() |> 
                               mutate(dataset = ifelse(quantile < lag(quantile), 1, 0),
                                      dataset = ifelse(is.na(dataset), 1, dataset),
                                      dataset = cumsum(dataset))
    store_viols = rbind(store_viols, viol_inter)
  }
  store_viols = store_viols[-1,]
  
  # Disaggregated table
  dis_table =
  store_viols |> mutate(dataset = case_when(dataset == 1 ~ "020 obs",
                                            dataset == 2 ~ "080 obs",
                                            dataset == 3 ~ "160 obs",
                                            dataset == 4 ~ "480 obs",)) |>
    group_by(iter, dataset) |> summarize(n_errors = n()) 
  
  # Summary table
  sum_table = dis_table |> group_by(dataset) |> 
                           summarize(mean_errors = mean(n_errors),
                                     min_errors = min(n_errors),
                                     max_errors = max(n_errors))
  
  list(dis_table = dis_table,
       sum_table = sum_table)
  
}

# Step 5. Induced parameters
#---------------------------#

# Recover induced parameters based on consumption and menu data
risk_aversion_params = function(df){
  
  # df: an object created via choice_data_gen()
  
  # Number of menus
  J = length(unique(df$menu))

  # Recover t and compute quantile 
  df |> mutate(t = ifelse(c_2 == 0, 0,
                              -log(phi_j) / log(r))) |>
        group_by(menu, n_obs) |>
        arrange(t) |>
        mutate(quantile_t = signif(row_number(t) / n_obs * 100) ) |>
        ungroup()
}

# Plot induced parameters ECDF
plot_induced_param = function(df_list, menu_selection = "random", n_menus_random = 10,
                              recover_params, seed = 12345){
  
  # df_list: a list of one or more objects created via choice_data_gen()
  # menu_selection: one of c("all", "random", "num_vector")
  #   - all: selects all menus in unique(df$menu)
  #   - random: selects n_menus_random at random from unique(df$menu)
  #             if menu_selection != random, n_menus_random is ignored
  #   - num_vector: a vector of menus to be selected i.e. c(1, 7, 14, 15)
  # recover_params: a function which outputs an induced parameter t (like risk_aversion_params)
  # seed for replicability (only relevant for menu_selection = random)
  
  # Set seed
  set.seed(seed)
  
  # Bind datasets together
  df = do.call(rbind, df_list)
  
  # Select menus according to user specification
  df = menu_selection_verif(df, menu_selection, n_menus_random)
  
  # Recover t-parameter via recover_params
  df = recover_params(df)
  
  # Plot
  plot_cdf_induced_param =
  df |> filter(t < 2) |> # For plotting considerations only
        mutate(Menu = as.factor(menu)) |>
        ggplot() +
        geom_line(aes(x = t, y = quantile_t, 
                      color = Menu,
                      linetype = Menu,
                      group = interaction(Menu))) +
        labs(group = "Menu", x = "Induced Risk Aversion Parameter", 
             y = "Percentile") +
        theme_minimal() +
        #ggtitle("Empirical Induced Parameter CDF for each Menu") +
        facet_wrap(~n_obs, nrow = 1) +
        theme(legend.position = "bottom",           
              legend.title = element_text(size = 16),
              legend.text = element_text(size = 16),
              axis.title.x = element_text(size = 16, 
                                          margin = margin(t = 10, r = 0, b = 0, l = 0)),
              axis.title.y = element_text(size = 16),
              strip.text = element_text(size = 16)) +
        guides(color = guide_legend(nrow = 1))
  
  plot(plot_cdf_induced_param)
  ggsave("output/risk_step5_cdf_induced_param.png", plot_cdf_induced_param, 
         height = 5 , width = 10)
    
} 

# Step 6. Equality of distributions #
#-----------------------------------#

# 6a. Semi-parametric Testing

# Non-parametric testing AD and DTS
# Documentation: https://cran.r-project.org/web/packages/twosamples/twosamples.pdf

# Auxiliary DTS-test function
dts_wrap = function(a, b, df){
  a_menu = df |> filter(menu == a) |> pull(t)
  b_menu = df |> filter(menu == b) |> pull(t)
  dts_test(a = a_menu, b = b_menu)
}

# Auxiliary AD-test function
ad_wrap = function(a, b, df){
  a_menu = df |> filter(menu == a) |> pull(t)
  b_menu = df |> filter(menu == b) |> pull(t)
  ad_test(a = a_menu, b = b_menu)
}

# Semi-parametric testing function
similarity_testing = function(df, recover_params,
                              menu_selection = "all", n_menus_random = 10,
                              quant_selection = "percentile"){
  
  # df_list: a list of one or more objects created via choice_data_gen()
  # recover_params: a function which outputs an induced parameter t (like risk_aversion_params)
  # menu_selection: one of c("all", "random", "num_vector")
  #   - all: selects all menus in unique(df$menu)
  #   - random: selects n_menus_random at random from unique(df$menu)
  #             if menu_selection != random, n_menus_random is ignored
  #   - num_vector: a vector of menus to be selected i.e. c(1, 7, 14, 15)
  
  # quant_selection: one of c("percentile", "decile", "num_vector")
  #   - percentile: selects quantiles 1:100. quantiles need to be matched exactly
  #   - decile: selects quantiles 10, 20, ..., 100. quantiles need to be matched exactly
  #   - num_vector: a vector of quantiles to be selected i.e. c(19, 31, 42, 89)
  
  # Check and Select relevant menus according to user specification
  df = menu_selection_verif(df, menu_selection, n_menus_random)
  
  # Select quantiles according to user specification
  df = quant_selection_verif(df, quant_selection)
  
  # Recover t-parameter via recover_params
  df = recover_params(df)
  
  # Auxiliary variables for menu comparison
  menu_list = unique(df$menu)
  J = length(menu_list)
  menu_tibble = tibble(menu_a = numeric(),
                       menu_b = numeric())
  
  # Generate grid of menu pairs
  for (m_1 in 1:J){
    for (m_2 in m_1:J){
      menu_tibble = rbind(menu_tibble, c("menu_a" = menu_list[m_1],
                                         "menu_b" = menu_list[m_2]))
    }
  }
  
  colnames(menu_tibble) = c("menu_a", "menu_b")
  
  # Testing #
  #---------#
  
  # Drop param = Inf values to compute integral
  if(max(df$t) == Inf){
    print("One or more induced parameters have been inputted to be Infinity")
    df = df |> filter(t < Inf)
  }
  
  # DTS
  tests_dts = mapply(dts_wrap, a = menu_tibble$menu_a,
                 b = menu_tibble$menu_b,
                 MoreArgs = list(df = df)) |> t() |>
              as_tibble(.name_repair = "minimal") |>
              mutate(test = "DTS")
  # AD
  tests_ad = mapply(ad_wrap, 
                    a = menu_tibble$menu_a,
                    b = menu_tibble$menu_b,
                    MoreArgs = list(df = df)) |> t() |> 
              as_tibble(.name_repair = "minimal") |>
              mutate(test = "AD")
  
  tests = rbind(tests_dts, tests_ad)
  colnames(tests) = c("t_stat", "p_value", "test")
  tests |> mutate(menu_pair = rep(sapply(1:nrow(menu_tibble), function(m) 
                                      paste0(menu_tibble$menu_a[m], "-",
                                      menu_tibble$menu_b[m])), 2),
                  n_obs = unique(df$n_obs))
}

# Boxplot distribution of test p-values
p_value_distribution = function(df_list){
  
  # df_list a list of objects created via similarity_testing
  
  # Bind datasets together
  df = do.call(rbind, df_list)
  
  # Plot
  p_value_plot = 
    df |> ggplot() +
    geom_boxplot(aes(x = as.factor(n_obs), y = p_value)) +
    labs(#title = TeX(r"(Boxplot of p-values by Number of Observations)"), 
         x = "Number of Observations", 
         y = TeX(r"(p-values)")) +
    theme_minimal() +
    facet_wrap(~test) +
    theme(strip.text = element_text(size = 16),
          axis.text.x = element_text(size = 16),
          axis.title.x = element_text(size = 16, 
                                      margin = margin(t = 10, r = 0, b = 0, l = 0)),
          axis.title.y = element_text(size = 16))
  
  plot(p_value_plot)
  ggsave("output/risk_step6a_pvalue_distribution.png", p_value_plot, height = 5 , width = 5)
}

# Step 6b. Plot aggregated parameters
plot_induced_t = function(df, recover_params, true_params){
  
  # df: an object created via choice_data_gen()
  # recover_params: a function which outputs an induced parameter t (like risk_aversion_params)
  # true_params: a vector of true parameters to be compared to
  
  # Recover t-parameter via recover_params
  df = recover_params(df)
  
  # Generate auxiliary variable for display
  n_obs_vector = paste0(unique(df$n_obs), " obs")
  df = df |> mutate(value = paste(n_obs, "obs"),
                    quantile_t = row_number(t) / nrow(df) * 100) |> # compute aggregated quantile (not within menu quantile)
             select(t, quantile_t, value)
  
  # Generate fine-grained data from logistic distribution
  seq_log = seq(-2, max(df$t), 0.01)
  true_log_vector = paste0("Log(", true_params[1],", ", true_params[2], ")")
  logistic_data = tibble(t = seq_log,
                         quantile_t = plogis(t, loc = true_params[1],
                                             scale = true_params[2]) * 100,
                         value = true_log_vector)
  
  # Merge both datasets together
  plot_df = rbind(logistic_data, df)
  plot_df$value = factor(plot_df$value, 
                         levels = c(true_log_vector, n_obs_vector))
  
  # Plot induced_t parameter
  plot_aggregate_t =
  plot_df |> arrange(quantile_t) |> ggplot() +
             geom_line(aes(x = t, y = quantile_t, color = value,
                           linetype = value), linewidth = 1) +
             labs(x = "Induced Risk Parameter", y = "Percentile") +
             scale_color_manual(values = c("red", "black")) +
             theme_minimal() +
             #ggtitle("Empirical CDF for induced t vs True Logistic") +
             theme(legend.title = element_blank(),
                   axis.title.x = element_text(size = 16, 
                                               margin = margin(t = 10, r = 0, b = 0, l = 0)),
                   axis.title.y = element_text(size = 16))
  
  plot(plot_aggregate_t)
  ggsave("output/risk_step6b_aggregate_t_cdf.png", plot_aggregate_t, height = 5 , width = 5)
  
}

# Step 7. Mass analysis
#----------------------#
mass_analysis = function(df_list){
  
  # df_list: a list of one or more objects created via choice_data_gen()
  
  # Bind datasets together
  df = do.call(rbind, df_list)
  
  # Mass analysis
  mass_analysis_df =
    df |> mutate(larger_than_0 = ifelse(c_2 == 0, 1, 0)) |>
          group_by(menu, n_obs) |>
          summarize(mass_at_0 = mean(larger_than_0) * 100,
                    largest_r = max(r),
                    phi_j = mean(phi_2 / phi_1)) |>
          pivot_wider(names_from = n_obs, 
                      values_from = c("largest_r", "mass_at_0"))
  
  # Output as list  
  list("largest_r_df" = mass_analysis_df |> select(menu, phi_j, starts_with("largest_r")),
       "mass_at_0_df" = mass_analysis_df |> select(menu, phi_j, starts_with("mass_at")))
}

# LaTeX output for mass analysis tables
mass_output = function(df){

  # df: a tibble created via mass_analysis()
  
  df |> select(menu, phi_j, ends_with("0")) |>
        kbl(format="latex",
            col.names = c("Menu","\\Phi_j", "20 obs", "80 obs", "160 obs", "480 obs"),
            align="c",
            digits = 3) |>
        kable_minimal(full_width = F,  html_font = "Source Sans Pro")
}

# Step 8. CLA Property
#---------------------#

# Recover CLA property relevant data (sum of t and sum of log odds)
cla_data = function(df, recover_params, 
                    choices_per_menu = 5, seed = 1234){
  
  # df: an object created via choice_data_gen()
  # choices_per_menu: number of random choices to be selected by menu
  # recover_params: a function which outputs an induced parameter t (like risk_aversion_params)
  # seed for replicability
  
  # Set seed
  set.seed(seed)
  
  # Recover t-parameter via recover_params
    df = recover_params(df)
  
  # Initialize df
  cla_df = tibble(menu = NA, t = NA, t_prime = NA, 
                  log_odds_t = NA, log_odds_t_prime = NA,
                  sum_t = NA, sum_log_odds = NA)
  
  # Recover n observations per menu and merge together
  for (j in 1:length(unique(df$menu))){
    
    # Select menu
    df_menu = df |> filter(menu == j)
    
    # Compute ECDF
    ecdf_t = ecdf(df_menu |> pull(t)) # Including 0s
    
    # Sample interior observations
    index = sample(which(df_menu$t > 0 & df_menu$t < max(df_menu$t)), choices_per_menu)
    
    # Compute log_odds by using ecdf_t
    subset_menu_t = df_menu[index,] |> mutate(ecdf = ecdf_t(t),
                                              log_odds_t = log(ecdf / (1 - ecdf))) |>
                                       select(t, log_odds_t)
    
    # Create a mirror subset to sum across
    subset_menu_t_prime = subset_menu_t |> rename(t_prime = t,
                                                  log_odds_t_prime = log_odds_t)
   
    # Merge both data sets and sum across them 
    grid_t = expand_grid("t" = subset_menu_t$t, "t_prime" = subset_menu_t$t)
    df_t = grid_t |> left_join(subset_menu_t, by = "t") |>
                     left_join(subset_menu_t_prime, by = "t_prime") |>
                     mutate(sum_t = t + t_prime,
                            sum_log_odds = log_odds_t + log_odds_t_prime,
                            menu = j) |>
                     select(menu, t, t_prime, log_odds_t, 
                            log_odds_t_prime, sum_t, sum_log_odds)
    
    # Bind data
    cla_df = rbind(cla_df, df_t)
              
  }
  
  cla_df[-1,] # Exclude initial empty row
  cla_df$n_obs = unique(df$n_obs)
  cla_df
      
}

# Auxiliary function for using regression as estimation method
cla_regression = function(n, df){
  
  # df: an object (or merge of objects) created via cla_data()
  # n: n_obs to be considered (one dataset at a time)
  
  # Select dataset
  df_n = df |> filter(n_obs == n)
  
  # Run regression
  model = lm(sum_log_odds ~ sum_t, df_n)
  
  # Recover estimates from regression output
  sigma = 1 / model$coefficients[2]
  tau = - model$coefficients[1]*sigma / 2
  
  # Output
  round(c("tau" = tau, "sigma" = sigma), 3)
  
}

# Plot CLA property
plot_cla = function(df_list, true_params){
  
  # df_list: a list of objects created via cla_data()
  # true_params: a vector of true parameters to be compared to
  
  # Initialize true_params
  tau = true_params[1]
  sigma = true_params[2]
  
  # Bind datasets together
  df = do.call(rbind, df_list)
  
  # Create segment according to true values
  # y = 1 / sigma * x - 2 * tau / sigma
  
  x_start = 0
  x_end = 4
  y_start = 1/sigma *(x_start - 2 * tau)
  y_end = 1/sigma *(x_end - 2 * tau)
  
  # Auxiliary vector with true parameter information
  true_log_vector = paste0("Log(", tau,", ", sigma, ")")
  
  # Plot
  cla_plot =
    df |> ggplot() +
          geom_point(aes(x = sum_t, y = sum_log_odds)) +
          geom_segment(aes(x = x_start, y = y_start, xend = x_end, yend = y_end,
                           color = true_log_vector), linewidth = 1) +
          scale_color_manual(values = "red") +
          theme_minimal() +
          labs(x = "Sum Risk Aversion Parameter",
               y = TeX(r"(Sum $\log$ $\frac{F_j(t)}{1-F_j(t)}$)"),
               color = "") +
          #ggtitle("CLA Property") +
          facet_wrap(~n_obs, nrow = 1) +
          theme(legend.position = "bottom",           
                legend.title = element_text(size = 16),
                legend.text = element_text(size = 16),
                axis.title.x = element_text(size = 16, 
                                            margin = margin(t = 10, r = 0, b = 0, l = 0)),
                axis.title.y = element_text(size = 16),
                strip.text = element_text(size = 16))
  
  plot(cla_plot)
  ggsave("output/risk_step8_cla_property.png", cla_plot, height = 5 , width = 10)
  
  # Regression
  sapply(unique(df$n_obs), cla_regression, df = df) 
  
}

# Step 9. Censored logit parametric MLE
#--------------------------------------#

# Logistic density
likelihood_function_logit = function(logis_params, df_geq0, M_0, M){
  
  # logis_params: a vector of parameters to evaluate likelihood function at
  # df_geq0: an object created via recover_params() containing only non-0 observations
  # M_0: number of zero observations in original dataset
  # M: number of observations in original dataset
  
  # Initialize parameters
  tau = logis_params[1]
  sigma = logis_params[2]
  
  # Likelihood function as in Step 9 of Section 6.2
  - M_0*log(1 + exp(tau/sigma)) - sum((df_geq0$t - tau)/sigma + log(sigma) + 
                                       2*log(1 + exp(-(df_geq0$t - tau)/sigma)))
}

# Gradient of logistic density
gradient_function_logit = function(logis_params, df_geq0, M_0, M){
  
  # logis_params: a vector of parameters to evaluate likelihood function at
  # df_geq0: an object created via recover_params() containing only non-0 observations
  # M_0: number of zero observations in original dataset
  # M: number of observations in original dataset
  
  # Initialize parameters
  tau = logis_params[1]
  sigma = logis_params[2]
  
  # Gradient wrt to \tau and \sigma of likelihood function logit
  c(1 / sigma * (- M_0 * exp(tau/sigma) / (1 + exp(tau / sigma)) + 
                    (M - M_0) - sum( 2*exp(-(df_geq0$t - tau) / sigma) / (1 + exp(-(df_geq0$t - tau) / sigma)))),
     1 / sigma *(tau / sigma * M_0 * exp(tau/sigma) / (1 + exp(tau / sigma)) + 
                  - (M - M_0) - sum( 2*(df_geq0$t - tau) / sigma * (exp(-(df_geq0$t - tau) / sigma)) / (1 + exp(-(df_geq0$t - tau) / sigma)) +
                                      + (df_geq0$t - tau)/ sigma )))
  
}

# Parametric estimation
parametric_estimation = function(df, recover_params){
  
  # df: an object created via choice_data_gen()
  # recover_params: a function which outputs an induced parameter t (like risk_aversion_params)

  # Recover t-parameter via recover_params
  df = recover_params(df)
  
  # Auxiliary variables (see paper for reference and notation)
  M = nrow(df)
  M_0 = nrow(df[df$t == 0,])
  df_geq0 = df |> filter(t > 0) # Strictly positive observations
  
  # Start values in optimization
  start_values = c(mean(df_geq0$t), sd(df_geq0$t))
  
  # Optimization
  optim_results = optim(par = start_values, # Uses plug-in coefficients as starting values
                        fn = likelihood_function_logit,
                        gr = gradient_function_logit,
                        df_geq0 = df_geq0, # Optimize only c_2 > 0 observations
                        M_0 = M_0,
                        M = M,
                        method = 'Nelder-Mead',
                        control=list(fnscale = -1, # To maximize (not minimize)
                                     n_dep = 0.0001))  
  
  c("tau" = round(optim_results$par[1], 3),
    "sigma" = round(optim_results$par[2], 3),
    "avg_ll" = round(optim_results$value / unique(df$n_obs), 3))
  
}

# Step 10. Parametric Testing
#----------------------------#
# Testing ECDF vis-a-vis Logit
param_testing = function(df, optim_params, recover_params){
  
  # df: an object created via choice_data_gen_alt()
  # optim_params: vector of parameters estimated via parametric_estimation() or parametric_estimation_alt()
  # recover_params: a function which outputs an induced parameter t (like altruism_params)
  # n_quantiles_alpha: number of quantiles to be sampled (in [40, 100]) to estimate alpha
  # n_menus_alpha: number of menus to be sampled to estimate alpha
  # seed_alpha for replicability when estimating alpha
  
  # Initialize variables
  tau = optim_params[1]
  sigma = optim_params[2]
  
  # Inputs
  # p_value index
  p_value_vector = c(0.5, 0.25, 0.15, 0.1, 0.05, 0.025, 0.01, 0.005)
  
  # p-value matrices
  #KS P-values according to Table 4.4. in p.112 of Agostino and Stephens
  ks_p_values = matrix(c(.4923, .6465, .7443, .8155, .9268, 1.0282, 1.1505, 1.2361,
                         .5889, .7663, .8784, .9597, 1.0868, 1.2024, 1.3419, 1.4394,
                         .6627, .8544, .9746, 1.0616, 1.1975, 1.3209, 1.4696, 1.5735,
                         .7204, .9196, 1.0438, 1.1334, 1.2731, 1.3997, 1.5520, 1.6583,
                         .7649, .9666, 1.0914, 1.1813, 1.3211, 1.4476, 1.5996, 1.7056,
                         .7975, .9976, 1.1208, 1.2094, 1.3471, 1.4717, 1.6214, 1.7258,
                         .8183, 1.0142, 1.1348, 1.2216, 1.3568, 1.4794, 1.6272, 1.7306,
                         .8270, 1.0190, 1.1379, 1.2238, 1.3581, 1.4802, 1.6276, 1.7308,
                         .8276, 1.0192, 1.1379, 1.2238, 1.3581, 1.4802, 1.6276, 1.7308), 
                       nrow = 9, ncol = 8, byrow = T)
  
  #Cramer-Von Misses P-values according to Table 4.4. in p.112 of Agostino and Stephens
  cvm_p_values = matrix(c(.010, .025, .033, .041, .057, .074, .094, .110,
                          .022, .046, .066, .083, .115, .147, .194, .227,
                          .037, .076, .105, .136, .184, .231, .295, .353,
                          .054, .105, .153, .186, .258, .330, .427, .488,
                          .070, .136, .192, .241, .327, .417, .543, .621,
                          .088, .165, .231, .286, .386, .491, .633, .742,
                          .103, .188, .259, .321, .430, .544, .696, .816,
                          .115, .204, .278, .341, .455, .573, .735, .865,
                          .119, .209, .284, .347, .461, .581, .743, .869),
                        nrow = 9, ncol = 8, byrow = T)
  
  matrices = list(ks_p_values,
                  cvm_p_values)
  
  # Recover parameters via recover_params
  df = recover_params(df)
  
  # Auxiliary variables (See paper for reference)
  M = nrow(df)
  M_0 = nrow(df[df$t == 0,])
  share_available = (1 - M_0 / M) |> round(1)
  
  # Check validity of reference tables
  if (share_available < 0.2){stop("Share of censored values is too high (>0.9) as for current methods to be applicable")}
  
  # Compute additional variables according to notation in Agostino and Stephens
  df_r = df |> arrange(t) |>
               mutate(pred_cdf = 1 / (1 + exp(-(t - tau) / sigma)), # Predicted CDF for logistic
               i_value = 1:nrow(df)) |>
               filter(t > 0) |>
               mutate(M_star = ifelse(t == lead(t), 0, 1), 
                      M_star = ifelse(is.na(M_star), 1, M_star)) |> # Assign value to last entry (which (i) does not have a lead by definition, but (ii) is in M^*) 
               filter(M_star == 1)
  
  # KS test
  ks_test = sqrt(M) * max(abs(M_0 / M - 1 / (1 + exp(tau / sigma))), abs(max(df_r$i_value / M - df_r$pred_cdf))) + 0.19 / sqrt(M)
  
  # CVM test
  # Input additional missing observation for cvm testing (see textbook for reference)
  df_r_plus = rbind(df_r[1,], df_r)
  df_r_plus$i_value[1] = min(df_r_plus$i_value) - 1
  df_r_plus$pred_cdf[1] = 1 / (1 + exp(tau / sigma))
  
  # We further delete observations with ECDF = 1
  df_r_plus = df_r_plus |> filter(pred_cdf < 1)
  r = nrow(df_r_plus)
  M = M + 1
  
  # Cramer-Von Misses test
  cvm_test = sum((df_r_plus$pred_cdf - (2*df_r_plus$i_value - 1)/(2*M))^2) + r / (12*M^2) + M/3 * (df_r_plus$pred_cdf[1] - df_r_plus$i_value[1]/M)^3
  
  # Identify closest point in Tables for comparison
  tests = abs(c(ks_test, cvm_test))
  p_values = c()
  
  for(j in 1:length(tests)){
    relevant_row = matrices[[j]][share_available*10 - 1,]
    min_p_value = max(relevant_row[tests[j] - relevant_row > 0])
    if (is.na(min_p_value)){
      p_values_index = min(which(is.na(relevant_row)))
      p_values[j] = p_value_vector[p_values_index]
    } else if(min_p_value == -Inf){
      p_values[j] = "> 0.5"
    } else{
      p_values_index = which(relevant_row == min_p_value)
      p_values[j] = p_value_vector[p_values_index]}
  }
  
  # Query value
  store_tests = tibble(test = c("KS", "CVM"),
                       test_statistic = tests,
                       rounded_share_available = share_available,
                       p_values = p_values)
  
  store_tests
}