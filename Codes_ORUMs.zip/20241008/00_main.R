#---------------------#
# Title: 0. Main
# Project: Ordered Logit Empirical Applications
# Author: Carlos Gonzalez
# Date: October 2024
#---------------------#

rm(list = ls())

# 0a. Libraries
# -------------#
# Package description
# dplyr                   syntax and readability
# ggplot2                 plotting
# stringr                 regex functions
# tidyr                   data managing functions
# igraph                  graph manipulation
# future                  parallel computing
# future.apply            user-friendly parallel computing
# remotes                 install repository based algorithms
# gridExtra               grid in ggplot
# DescTools               class management
# twosamples              fast non-parametric testing of two-samples distributions
# tictoc                  time-management (development use only)
# kableExtra              R to LaTex Tables
# latex2exp               LaTex Annotations in ggplot
# textshape               column_to_rownames() function
# huoston/shortestpath    access to bellman-ford algorithm

# Installing packages routine
package_list = c("dplyr", "ggplot2", "stringr", "tidyr",
                 "igraph", "future", "future.apply", "remotes",
                 "gridExtra", "twosamples", "tictoc", "kableExtra",
                 "latex2exp", "textshape")
package_list_repo = c("huoston/shortestpath")

missing_packages = package_list[!(package_list %in% 
                                    installed.packages()[,"Package"])]
missing_packages_repo = package_list_repo[!(package_list_repo %in% 
                                              installed.packages()[,"Package"])]
if (length(missing_packages)){
  install.packages(missing_packages)
  warning("The following packages ", missing_packages, 
          " will be installed in your device")}

if (length(missing_packages_repo)){
  remotes::install_github(missing_packages_repo)
  warning("The following packages ", missing_packages_repo, 
          " will be installed in your device from External Sources")}

library(stringr)
package_list_repo = sapply(package_list_repo, str_replace,
                           pattern = ".*\\/", replacement = "")

# Load libraries
for (package in c(package_list, package_list_repo))
{eval(bquote(library(.(package))))}

# 0b. Directory and folders
# -------------------------#
# Set main directory
dir = dirname(rstudioapi::getActiveDocumentContext()$path)
main_dir = str_replace(dir, "/[^/]*$", "")
setwd(main_dir) # Replace manually with main directory if needed

# Output directory (for tables, graphs and auxiliary files)
if (!dir.exists("output")){dir.create("output")}

# 0c. Globals
#------------#
n_workers = 4 # Number of CPUs to be used in parallel computing
J_global = 20 # Number of menus
pi_vector_global = c(1/100, 1/10) # Price boundaries
n_quantiles_alpha_global = 4 # Number of quantiles to be used to estimate alpha

# 0d. Import functions
#---------------------#
source("code/01_risk.R")     # 01. Risk Application (and general functions)
source("code/02_altruism.R") # 02. Altruism Application

#---------------------#
# 1. Risk Application #
#---------------------#
# Section 6.2. in Apesteguia and Ballester

# Step 1: Generate and Order Menu data
#-------------------------------------#
# Menu data unordered
menu_data = data_gen()

# Menu data ordered
menu_data = order_data(menu_data)

# Export Table 1
export_table_1(menu_data) 

# Step 2: Generate Choice Data
#-----------------------------#
# Generate Choice data
# See 01_risk.R for discussion on seed selection
n20_data = choice_data_gen(menu_data, 20, seed = 2)
n80_data = choice_data_gen(menu_data, 80, seed = 2)
n160_data = choice_data_gen(menu_data, 160, seed = 2)
n480_data = choice_data_gen(menu_data, 480, seed = 2)

# Plot CDF of consumption ratio for a selection of menus (Figure 1)
plot_cdf(list(n20_data, n80_data, 
              n160_data, n480_data), "random", 10)

# Step 3: Directed Graph
#-----------------------#
# Generate weight matrix for some menu and quantile selection (quantile = 50)
weight_matrix_n20 = gen_weight_matrix(df = n20_data, plot = T)
weight_matrix_n80 = gen_weight_matrix(n80_data, plot = T)
weight_matrix_n160 = gen_weight_matrix(n160_data, plot = T)
weight_matrix_n480 = gen_weight_matrix(n480_data, plot = T)
weight_matrix_n160_mini = gen_weight_matrix(n160_data, 
                                            menu_selection = c(3, 8, 11, 16, 20),
                                            plot = T, weights = T)

# Step 4: Bellman-Ford
#---------------------#
# We consider the same 20 quantiles per menu to make fair comparisons in number of violations
quantile_vector = n20_data |> pull(quantile) |> unique() |> sort()
quantile_vector

# Bellman-Ford (5 mins)
viols_n20_data = lapply_routine_bell(n20_data, quant_selection = quantile_vector)
viols_n80_data = lapply_routine_bell(n80_data, quant_selection = quantile_vector)
viols_n160_data = lapply_routine_bell(n160_data, quant_selection = quantile_vector)
viols_n480_data = lapply_routine_bell(n480_data, quant_selection = quantile_vector)

# Inspect violations
viols_n20_data
viols_n80_data
viols_n160_data
viols_n480_data

# Step 5. Induced parameters
#---------------------------#
plot_induced_param(list(n20_data, n80_data, n160_data, n480_data), 
                   menu_selection = "random", n_menus_random = 10,
                   recover_params = risk_aversion_params)

# Step 6. Equality of distributions #
#-----------------------------------#

# 6a. Testing

# Computes AD and DTS test on a selection of menus and quantiles
n20_data_test = similarity_testing(n20_data, recover_params = risk_aversion_params,
                                   quant_selection = quantile_vector)
n80_data_test = similarity_testing(n80_data, recover_params = risk_aversion_params,
                                   quant_selection = quantile_vector)
n160_data_test = similarity_testing(n160_data, recover_params = risk_aversion_params,
                                    quant_selection = quantile_vector)
n480_data_test = similarity_testing(n480_data, recover_params = risk_aversion_params,
                                    quant_selection = quantile_vector)

# Plot distribution of p-values across n_obs and test %in% c("AD", "DTS")
p_value_distribution(list(n20_data_test, n80_data_test,
                          n160_data_test, n480_data_test))

# 6b. Aggregate t-parameters vs True Logistic
plot_induced_t(n160_data, risk_aversion_params, 
               true_params = c(0.6, 0.3))

# Step 7. Mass analysis of r
#----------------------------#
mass_analysis_tables = mass_analysis(list(n20_data, n80_data, n160_data, n480_data))
lapply(mass_analysis_tables, mass_output)

# Step 8. CLA Property
#---------------------#
# Generate CLA datasets for plot and regression
cla_20 = cla_data(n20_data, recover_params = risk_aversion_params)
cla_80 = cla_data(n80_data, recover_params = risk_aversion_params)
cla_160 = cla_data(n160_data, recover_params = risk_aversion_params)
cla_480 = cla_data(n480_data, recover_params = risk_aversion_params)

# Plot and regression
plot_cla(list(cla_20, cla_80, cla_160, cla_480), true_params = c(0.6, 0.3))

# Step 9. Censored logit parametric MLE
#--------------------------------------#
# Parametric estimation
param_results = sapply(list(n20_data, n80_data, n160_data, n480_data), 
                       parametric_estimation, recover_params = risk_aversion_params)
param_results

# Step 10. Parametric Testing
#----------------------------#
# We observe a decrease in the t-statistic associated to an increase in p-value
# as N grows
param_testing(n20_data, param_results[-3, 1], risk_aversion_params)
param_testing(n80_data, param_results[-3, 2], risk_aversion_params)
param_testing(n160_data, param_results[-3, 3], risk_aversion_params) 
param_testing(n480_data, param_results[-3, 4], risk_aversion_params)

#-------------------------#
# 2. Altruism Application #
#-------------------------#
# Section 6.3. in Apesteguia and Ballester

# Step 1: Generate and Order Menu data
#-------------------------------------#
# Menu data ordered
menu_alt_data = data_gen_alt()

# Export Table XX
export_table_2(menu_alt_data)

# Step 2: Generate Choice Data
#-----------------------------#
# Generate Choice data
n20_alt_data = choice_data_alt_gen(menu_alt_data, 20)
n80_alt_data = choice_data_alt_gen(menu_alt_data, 80)
n160_alt_data = choice_data_alt_gen(menu_alt_data, 160)
n480_alt_data = choice_data_alt_gen(menu_alt_data, 480)

# Plot v-CDF for a selection of menus
plot_cdf_v(list(n20_alt_data, n80_alt_data, 
                n160_alt_data, n480_alt_data), "random", 10)

# Step 3: WARP for Altruism
#--------------------------#
# Verify WARP property for each pair of menus
warp20 = altr_warp(menu_alt_data, n20_alt_data)
warp80 = altr_warp(menu_alt_data, n80_alt_data)
warp160 = altr_warp(menu_alt_data, n160_alt_data)
warp480 = altr_warp(menu_alt_data, n480_alt_data)

warp20
warp80
warp160
warp480

# Step 4. Recover Alpha
#--------------------------#
# Recover alpha for a subset of menus and quantiles
alpha20 = recover_alpha(n20_alt_data, n_quantiles_alpha = 4,
                        seed_alpha = 12345)
alpha80 = recover_alpha(n80_alt_data, n_quantiles_alpha = 4,
                        seed_alpha = 12345)
alpha160 = recover_alpha(n160_alt_data, n_quantiles_alpha = 4,
                         seed_alpha = 12345)
alpha480 = recover_alpha(n480_alt_data, n_quantiles_alpha = 4,
                         seed_alpha = 12345)

# Recover median alpha and plot alpha distribution
alpha_values = plot_alpha(list(alpha20, alpha80, alpha160, alpha480), 
                          true_alpha = .4)
alpha_values

# Step 5. Induced parameters
#---------------------------#
# Recover alpha according to Step 4 and then
# Recover induced parameters based on consumption, menu data and alpha
# Finally plot distribution
plot_induced_param_alt(list(n20_alt_data, n80_alt_data, n160_alt_data, n480_alt_data),
                       recover_params = altruism_params)

# Step 6. Equality of distributions #
#-----------------------------------#

# 6a. Testing

# Computes AD and DTS test on a selection of menus and quantiles
n20_alt_data_test = similarity_testing_alt(n20_alt_data, recover_params = altruism_params,
                                           quant_selection = quantile_vector)
n80_alt_data_test = similarity_testing_alt(n80_alt_data, recover_params = altruism_params,
                                           quant_selection = quantile_vector)
n160_alt_data_test = similarity_testing_alt(n160_alt_data, recover_params = altruism_params,
                                            quant_selection = quantile_vector)
n480_alt_data_test = similarity_testing_alt(n480_alt_data, recover_params = altruism_params,
                                            quant_selection = quantile_vector)

# Plot distribution of p-values across n_obs and test %in% c("AD", "DTS")
p_value_distribution_alt(list(n20_alt_data_test, n80_alt_data_test,
                              n160_data_test, n480_data_test))

# 6b. Aggregate t-parameters vs True Logistic
plot_induced_t_alt(n160_alt_data, recover_params = altruism_params,
                   true_params = c(0.2, 0.2))

# Step 7. Mass Analysis of v
#----------------------------#
mass_analysis_tables_alt = mass_analysis_alt(list(n20_alt_data, n80_alt_data, n160_alt_data, n480_alt_data))
lapply(mass_analysis_tables_alt, mass_output_alt)

# Step 8. CLA Property
#---------------------#
# Generate CLA datasets for plot and regression
cla_20_alt = cla_data_alt(n20_alt_data, recover_params = altruism_params)
cla_80_alt = cla_data_alt(n80_alt_data, recover_params = altruism_params)
cla_160_alt = cla_data_alt(n160_alt_data, recover_params = altruism_params)
cla_480_alt = cla_data_alt(n480_alt_data, recover_params = altruism_params)

# Plot and regression
plot_cla_alt(list(cla_20_alt, cla_80_alt, cla_160_alt, cla_480_alt), true_params = c(0.2, 0.2))

# Step 9. Censored logit parametric MLE
#--------------------------------------#
# Parametric estimation
param_results = sapply(list(n20_alt_data, n80_alt_data, n160_alt_data, n480_alt_data), 
                       parametric_estimation_alt, recover_params = altruism_params)
param_results

# Step 10. Parametric Testing
#----------------------------#
# We observe a decrease in the t-statistic associated to an increase in p-value
# as N grows
param_testing(n20_alt_data, param_results[-3, 1], altruism_params)
param_testing(n80_alt_data, param_results[-3, 2], altruism_params)
param_testing(n160_alt_data, param_results[-3, 3], altruism_params) 
param_testing(n480_alt_data, param_results[-3, 4], altruism_params)