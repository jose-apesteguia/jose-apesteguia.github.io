#-----------------------------------------------#
# Title: 00_main
#-----------------------------------------------#
# Project: Replication package for
#   Apesteguia and Ballester,
#   "Testable Implications of Parametric Assumptions
#    in Ordered Random Utility Models"
# Code author: Carlos Gonzalez-Perez
# Date: November 2025 (replication package: August 2026)
#-----------------------------------------------#
# Description:
# - System prep: library installation and loading,
#   directory creation, globals definition, code sourcing
# - Executes 01_risk.R and 02_altruism.R to replicate all
#   tables and figures in the paper (Appendix D)
# - Saves all exhibits in output_final/ and all simulated
#   datasets in data_simulated/
#
# IMPORTANT: Run this file from top to bottom in a fresh R
# session. Although randomness is fixed explicitly via seeds, 
# some exhibits may depend on the state of the random
# number generator, which is only guaranteed to be reproduced
# in a complete, sequential run.
#----------------------------------------------#

rm(list = ls())
time_start = Sys.time()

# 0a. Directory and folders
# -------------------------#
# The working directory must be the root of the replication package
# (the folder containing the subfolder "code_final").
# The root is detected automatically below; if automatic detection
# fails, set it manually with setwd("<path to replication package>").

detect_root = function(){
  is_root = function(p) nzchar(p) && dir.exists(file.path(p, "code_final"))
  # (i) RStudio: location of this script
  if (requireNamespace("rstudioapi", quietly = TRUE) &&
      rstudioapi::isAvailable()){
    p = tryCatch(rstudioapi::getActiveDocumentContext()$path,
                 error = function(e) "")
    if (nzchar(p) && is_root(dirname(dirname(p)))) return(dirname(dirname(p)))
  }
  # (ii) Rscript: location of this script from the command line
  args = commandArgs(trailingOnly = FALSE)
  fl = grep("^--file=", args, value = TRUE)
  if (length(fl) == 1){
    p = normalizePath(sub("^--file=", "", fl))
    if (is_root(dirname(dirname(p)))) return(dirname(dirname(p)))
  }
  # (iii) Fallback: current working directory
  getwd()
}

main_dir = detect_root()
setwd(main_dir) # Replace manually with the package root if needed

if (!dir.exists("code_final")){
  stop("Working directory is not the root of the replication package. ",
       "Please setwd() to the folder that contains 'code_final'.")
}

# Output directory (tables, graphs and auxiliary files)
if (!dir.exists("output_final")){dir.create("output_final")}
# Simulated datasets directory (CSV copies of all simulated data)
if (!dir.exists("data_simulated")){dir.create("data_simulated")}

# 0b. Libraries
# -------------#
# Package description
# dplyr                   syntax and readability
# ggplot2                 plotting
# stringr                 regex functions
# tidyr                   data managing functions
# igraph                  graph manipulation (Figure 2)
# future                  parallel computing
# future.apply            user-friendly parallel computing
# kableExtra              R to LaTeX tables
# latex2exp               LaTeX annotations in ggplot
# textshape               column_to_rownames() function
# kSamples                J-sample Anderson-Darling test

# Note: the Bellman-Ford negative-cycle detection is implemented
# natively in 01_risk.R (function bellman()) and requires no
# external package (previous code iterations relied on external packages
# such as mhils/shortestpath). All external dependencies are now removed

# Installing packages routine (CRAN)
package_list = c("dplyr", "ggplot2", "stringr", "tidyr",
                 "igraph", "future", "future.apply", "kableExtra",
                 "latex2exp", "textshape", "kSamples")

missing_packages = package_list[!(package_list %in%
                                    installed.packages()[,"Package"])]
if (length(missing_packages)){
  message("The following packages will be installed on your device: ",
          paste(missing_packages, collapse = ", "))
  install.packages(missing_packages, repos = "https://cloud.r-project.org")
}

# Load libraries
for (package in package_list)
{eval(bquote(library(.(package))))}

# 0c. System Globals
#-------------------#
# Number of CPUs to be used in parallel computing (default 4, capped at
# the number of cores available on the machine - 1)
n_workers = max(1, min(4, future::availableCores() - 1))
# NOTE: all randomized results are invariant to n_workers because
# parallel random numbers use pre-assigned L'Ecuyer-CMRG streams
# (future.seed = TRUE).

# 0d. Paper Globals
#-------------------#
J_global = 20 # Number of menus
pi_vector_global = c(1/100, 1/10) # Price boundaries

# 0e. Output helpers
#-------------------#
# Save a kableExtra/LaTeX table to output_final/<name>.tex
save_tex = function(x, name){
  writeLines(as.character(x), file.path("output_final", paste0(name, ".tex")))
  x
}
# Save a data frame (or coercible object) to output_final/<name>.csv
save_csv = function(x, name){
  write.csv(as.data.frame(x), file.path("output_final", paste0(name, ".csv")),
            row.names = FALSE)
  x
}
# Save a simulated dataset to data_simulated/<name>.csv
save_data = function(x, name){
  write.csv(as.data.frame(x), file.path("data_simulated", paste0(name, ".csv")),
            row.names = FALSE)
  x
}
# Simple run log
log_time = function(msg){
  line = paste0(format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "  ", msg)
  print(line)
  cat(line, "\n", file = file.path("output_final", "run_log.txt"), append = TRUE)
}
if (file.exists("output_final/run_log.txt")){unlink("output_final/run_log.txt")}
log_time("Run started")

# 0f. Import functions
#---------------------#
source("code_final/01_risk.R")     # 01. Risk Application (and general functions)
source("code_final/02_altruism.R") # 02. Altruism Application

#---------------------#
#---------------------#
# 1. Risk Application #
#---------------------#
#---------------------#
# Section 6.1 and Appendix D in Apesteguia and Ballester

#---------------------#
# 1.A. Simulated data #
#---------------------#
# Menu data unordered
menu_data = data_gen()

# Menu data ordered
menu_data = order_data(menu_data)
save_data(menu_data, "risk_menu_data")

# Table 1 (A) #
#-------------#
export_table_1a(menu_data) |> save_tex("table1a_risk_menus") |> print()
save_csv(menu_data |> select(menu, phi_j, pi_1, pi_2, q_1, phi_1, phi_2),
         "table1a_risk_menus")

# Generate Choice data
n20_data = choice_data_gen(menu_data, 20, seed = 2)
n80_data = choice_data_gen(menu_data, 80, seed = 2)
n160_data = choice_data_gen(menu_data, 160, seed = 2)
n480_data = choice_data_gen(menu_data, 480, seed = 2)

# See seed discussion in 01_risk (Step 3)
# quantile_vector = n20_data |> pull(quantile) |> unique() |> sort()
# seed_iteration = seed_iteration_wrap() # Uncomment to run
# seed_iteration

save_data(n20_data,  "risk_choice_data_n20")
save_data(n80_data,  "risk_choice_data_n80")
save_data(n160_data, "risk_choice_data_n160")
save_data(n480_data, "risk_choice_data_n480")
log_time("Risk data simulated")

# Figure 1 (A) #
#--------------#
# Plot CDF of consumption ratio for a fixed set of menus
# [saved as output_final/figure1a_risk.png]
plot_cdf(list(n20_data, n80_data,
              n160_data, n480_data),
         c(8, 9, 10, 11, 12, 14, 15, 17, 19, 20), 10)

#-----------------------------#
# 1.B. Nonparametric Analysis #
#-----------------------------#

# Figure 2 #
#----------#
# Generate weight matrix for some menu and quantile selection (quantile = 50)
# [saved as output_final/figure2_risk_n<N>.pdf]
weight_matrix_n20 = gen_weight_matrix(n20_data, plot = T)
weight_matrix_n80 = gen_weight_matrix(n80_data, plot = T)
weight_matrix_n160 = gen_weight_matrix(n160_data, plot = T)
weight_matrix_n480 = gen_weight_matrix(n480_data, plot = T)

# Table 3 #
#---------#
# We consider the same 20 quantiles per menu to make fair comparisons in number of violations
quantile_vector = n20_data |> pull(quantile) |> unique() |> sort()
quantile_vector

# Bellman-Ford (a few seconds; native negative-cycle detection)
log_time("Risk Bellman-Ford routine started")
viols_n20_data = lapply_routine_bell(n20_data, quant_selection = quantile_vector)
viols_n80_data = lapply_routine_bell(n80_data, quant_selection = quantile_vector)
viols_n160_data = lapply_routine_bell(n160_data, quant_selection = quantile_vector)
viols_n480_data = lapply_routine_bell(n480_data, quant_selection = quantile_vector)
log_time("Risk Bellman-Ford routine completed")

# Inspect violations
viols_n20_data
viols_n80_data
viols_n160_data
viols_n480_data

# Format and save Table 3
viols_to_row = function(v){
  if (is.data.frame(v)){
    c(n_violations = nrow(v),
      non_rationalizable_quantiles = paste(sort(v$quantile), collapse = ", "))
  } else{c(n_violations = 0, non_rationalizable_quantiles = "-")}
}
table3 = cbind(dataset = c("20 obs", "80 obs", "160 obs", "480 obs"),
               rbind(viols_to_row(viols_n20_data),
                     viols_to_row(viols_n80_data),
                     viols_to_row(viols_n160_data),
                     viols_to_row(viols_n480_data))) |> as_tibble()
save_csv(table3, "table3_risk_nonrationalizable_quantiles")
print(table3)

#-------------------------------#
# 1.C. Semi-parametric Analysis #
#-------------------------------#

# Figure 3 (A) #
#--------------#
# [saved as output_final/figure3a_risk.png]
plot_induced_param(list(n20_data, n80_data, n160_data, n480_data),
                   menu_selection = "random", n_menus_random = 10,
                   recover_params = risk_aversion_params)

# Table 6 (risk columns) #
#------------------------#
# J-Samples AD test

# Computes AD test on the full sample of induced parameters
# (every observation is a quantile; no quantile filtering)
similarity_testing_wrap(list(n20_data, n80_data, n160_data, n480_data),
                        recover_params = risk_aversion_params,
                        quant_selection = "all") |>
  save_tex("table6_risk_ad_test") |> print()
log_time("Risk semi-parametric analysis completed")

#--------------------------#
# 1.D. Parametric Analysis #
#--------------------------#

# Tables 7 and 8 #
#----------------#
# Mass analysis of r
mass_analysis_tables = mass_analysis(list(n20_data, n80_data, n160_data, n480_data))
lapply(mass_analysis_tables, mass_output)

# Save Table 7 (share of observations with r = 0) and Table 8 (largest r)
mass_output(mass_analysis_tables$mass_at_0_df) |> save_tex("table7_risk_mass_at0")
mass_output(mass_analysis_tables$largest_r_df) |> save_tex("table8_risk_largest_r")
save_csv(mass_analysis_tables$mass_at_0_df,  "table7_risk_mass_at0")
save_csv(mass_analysis_tables$largest_r_df,  "table8_risk_largest_r")

# Figure 4 (A) #
#--------------#
# CLA property

# Generate CLA datasets for plot
cla_20 = cla_data(n20_data, recover_params = risk_aversion_params)
cla_80 = cla_data(n80_data, recover_params = risk_aversion_params)
cla_160 = cla_data(n160_data, recover_params = risk_aversion_params)
cla_480 = cla_data(n480_data, recover_params = risk_aversion_params)

# Plot CLA
# [saved as output_final/figure4a_risk.png]
plot_cla(list(cla_20, cla_80, cla_160, cla_480), true_params = c(0.6, 0.3))

# Table 11 (left, risk columns) #
#-------------------------------#
# MLE Parametric estimation of Censored Logit
param_results = sapply(list(n20_data, n80_data, n160_data, n480_data),
                       parametric_estimation, recover_params = risk_aversion_params)
param_results
save_csv(cbind(statistic = rownames(param_results),
               as.data.frame(param_results) |>
                 setNames(c("n20", "n80", "n160", "n480"))),
         "table11_risk_mle")

# Table 11 (right, risk columns) #
#--------------------------------#
# AD test via Parametric Bootstrap (approx. 1 min)
log_time("Risk parametric bootstrap started")
boot_risk = rbind(bootstrap_ad_test(n20_data, risk_aversion_params),
                  bootstrap_ad_test(n80_data, risk_aversion_params),
                  bootstrap_ad_test(n160_data, risk_aversion_params),
                  bootstrap_ad_test(n480_data, risk_aversion_params))
boot_risk = cbind(dataset = c("20 obs", "80 obs", "160 obs", "480 obs"),
                  as.data.frame(boot_risk))
print(boot_risk)
save_csv(boot_risk, "table11_risk_bootstrap_ad_test")
log_time("Risk parametric bootstrap completed")

#-------------------------#
#-------------------------#
# 2. Altruism Application #
#-------------------------#
#-------------------------#
# Section 6.2 and Appendix D in Apesteguia and Ballester

#---------------------#
# 2.A. Simulated Data #
#---------------------#

# Menu data ordered
menu_alt_data = data_gen_alt()
save_data(menu_alt_data, "altruism_menu_data")

# Table 1 (B) #
#-------------#
export_table_1b(menu_alt_data) |> save_tex("table1b_altruism_menus") |> print()
save_csv(menu_alt_data |> select(menu, pi_j, pi_1, pi_2),
         "table1b_altruism_menus")

# Generate Choice data
n20_alt_data = choice_data_alt_gen(menu_alt_data, 20)
n80_alt_data = choice_data_alt_gen(menu_alt_data, 80)
n160_alt_data = choice_data_alt_gen(menu_alt_data, 160)
n480_alt_data = choice_data_alt_gen(menu_alt_data, 480)

save_data(n20_alt_data,  "altruism_choice_data_n20")
save_data(n80_alt_data,  "altruism_choice_data_n80")
save_data(n160_alt_data, "altruism_choice_data_n160")
save_data(n480_alt_data, "altruism_choice_data_n480")
log_time("Altruism data simulated")

# Figure 1 (B) #
#--------------#
# Plot v-CDF for a selection of menus
# [saved as output_final/figure1b_altruism.png]
plot_cdf_v(list(n20_alt_data, n80_alt_data,
                n160_alt_data, n480_alt_data), 
           c(2, 3, 4, 9, 12, 14, 15, 16, 17, 18), 10)

#-----------------------------#
# 2.B. Nonparametric Analysis #
#-----------------------------#

# Table 4 #
#---------#
# Verify WARP property for each pair of menus
warp20 = altr_warp(menu_alt_data, n20_alt_data)
warp80 = altr_warp(menu_alt_data, n80_alt_data)
warp160 = altr_warp(menu_alt_data, n160_alt_data)
warp480 = altr_warp(menu_alt_data, n480_alt_data)

warp20
warp80
warp160
warp480

# Format and save Table 4
warp_to_row = function(w){
  viol_menus = w$summary |> filter(share_viols > 0) |> pull(menu)
  c(n_violations = w$total_violations,
    menus_with_positive_share_of_violations =
      ifelse(length(viol_menus) == 0, "-", paste(viol_menus, collapse = ", ")))
}
table4 = cbind(dataset = c("20 obs", "80 obs", "160 obs", "480 obs"),
               rbind(warp_to_row(warp20), warp_to_row(warp80),
                     warp_to_row(warp160), warp_to_row(warp480))) |> as_tibble()
save_csv(table4, "table4_altruism_warp_violations")
print(table4)
log_time("Altruism nonparametric analysis completed")

#-------------------------------#
# 2.C. Semi-parametric Analysis #
#-------------------------------#

# Recover alpha for each quantile pair (approx. 2 mins)
alpha20 = recover_alpha(n20_alt_data)
alpha80 = recover_alpha(n80_alt_data)
alpha160 = recover_alpha(n160_alt_data)
alpha480 = recover_alpha(n480_alt_data)
log_time("Altruism alpha recovery completed")

# Table 5 #
#---------#
# Recover median alpha
med_alpha = median_alpha(list(alpha20, alpha80, alpha160, alpha480),
                          true_alpha = .4)
med_alpha
save_csv(med_alpha, "table5_altruism_median_alpha")

# All results below use the median alpha computed above (med_alpha).
# The November 2025 draft of the paper reported alpha = (0.445, 0.409,
# 0.387, 0.397), obtained with a pre-cleaning version of the median-alpha
# selection; the cleaned code yields (0.445, 0.410, 0.384, 0.398). The
# published tables use the values computed by this code.

# Figure 3 (B) #
#--------------#
# [saved as output_final/figure3b_altruism.png]
plot_induced_param_alt(list(n20_alt_data, n80_alt_data, n160_alt_data, n480_alt_data),
                       recover_params = altruism_params, median_alpha = med_alpha)

# Table 6 (altruism columns) #
#----------------------------#
# J-Samples AD test

# Computes AD test on the full sample of induced parameters
# (every observation is a quantile; no quantile filtering)
similarity_testing_alt_wrap(df_list = list(n20_alt_data, n80_alt_data,
                                           n160_alt_data, n480_alt_data),
                            recover_params = altruism_params, menu_selection = "all",
                            n_menus_random = 10, quant_selection = "all", median_alpha = med_alpha) |>
  save_tex("table6_altruism_ad_test") |> print()
log_time("Altruism semi-parametric analysis completed")

#--------------------------#
# 2.D. Parametric Analysis #
#--------------------------#

# Tables 9 and 10 #
#-----------------#
# Mass analysis of r
mass_analysis_tables_alt = mass_analysis_alt(list(n20_alt_data, n80_alt_data,
                                                  n160_alt_data, n480_alt_data))
lapply(mass_analysis_tables_alt, mass_output_alt)

# Save Table 9 (share of observations with v = 0) and Table 10 (largest v)
mass_output_alt(mass_analysis_tables_alt$mass_at_0_df) |> save_tex("table9_altruism_mass_at0")
mass_output_alt(mass_analysis_tables_alt$largest_v_df) |> save_tex("table10_altruism_largest_v")
save_csv(mass_analysis_tables_alt$mass_at_0_df, "table9_altruism_mass_at0")
save_csv(mass_analysis_tables_alt$largest_v_df, "table10_altruism_largest_v")

# Figure 4 (B) #
#--------------#
# CLA property

# Generate CLA datasets for plotting
cla_20_alt = cla_data_alt(n20_alt_data, recover_params = altruism_params, median_alpha = med_alpha)
cla_80_alt = cla_data_alt(n80_alt_data, recover_params = altruism_params, median_alpha = med_alpha)
cla_160_alt = cla_data_alt(n160_alt_data, recover_params = altruism_params, median_alpha = med_alpha)
cla_480_alt = cla_data_alt(n480_alt_data, recover_params = altruism_params, median_alpha = med_alpha)

# Plot CLA
# [saved as output_final/figure4b_altruism.png]
plot_cla_alt(list(cla_20_alt, cla_80_alt, cla_160_alt, cla_480_alt),
             true_params = c(0.2, 0.2))

# Table 11 (left, altruism columns) #
#-----------------------------------#
# MLE Parametric estimation of Censored Logit
param_results_alt = sapply(list(n20_alt_data, n80_alt_data, n160_alt_data, n480_alt_data),
                       parametric_estimation_alt, recover_params = altruism_params,
                       median_alpha = med_alpha)
param_results_alt
save_csv(cbind(statistic = rownames(param_results_alt),
               as.data.frame(param_results_alt) |>
                 setNames(c("n20", "n80", "n160", "n480"))),
         "table11_altruism_mle")

# Table 11 (right, altruism columns) #
#------------------------------------#
# AD test via Parametric Bootstrap (approx. 1 min)
log_time("Altruism parametric bootstrap started")
boot_alt = rbind(bootstrap_ad_test_alt(n20_alt_data, altruism_params, median_alpha = med_alpha),
                 bootstrap_ad_test_alt(n80_alt_data, altruism_params, median_alpha = med_alpha),
                 bootstrap_ad_test_alt(n160_alt_data, altruism_params, median_alpha = med_alpha),
                 bootstrap_ad_test_alt(n480_alt_data, altruism_params, median_alpha = med_alpha))
boot_alt = cbind(dataset = c("20 obs", "80 obs", "160 obs", "480 obs"),
                 as.data.frame(boot_alt))
print(boot_alt)
save_csv(boot_alt, "table11_altruism_bootstrap_ad_test")
log_time("Altruism parametric bootstrap completed")

#-------------------------#
# 3. Session information  #
#-------------------------#
writeLines(capture.output(sessionInfo()),
           file.path("output_final", "session_info.txt"))
log_time(paste0("Run completed. Total elapsed: ",
                round(difftime(Sys.time(), time_start, units = "mins"), 1),
                " minutes"))
